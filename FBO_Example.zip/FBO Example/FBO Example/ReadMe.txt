========================================================================
    FBO Example Project Overview
    by
    Rob 'phantom' Jones	
========================================================================

This is an example project demonstrating how to use the Framebuffer 
Object extension in OpenGL.

It uses GLee by Ben Woodhouse for extension setup and requires some form
of the GLUT library to be compiled and run.

The program was developed using FreeGLUT avaible from 
http://freeglut.sourceforge.net/

Extension Spec : 
http://www.opengl.org/registry/specs/EXT/framebuffer_object.txt
=========================================================================

All Example code is (c)2006 Rob Jones
Feel free to reuse as you see fit, just don't claim credit :)

Thanks goto Rick Appleton for assitance in debugging this example on
NVIDIA Hardware, cheers dude :)