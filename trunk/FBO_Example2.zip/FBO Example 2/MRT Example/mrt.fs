#version 110

void main(void)
{
	gl_FragData[0] = vec4(gl_Color.r, gl_Color.g,gl_Color.b,1.0);
	gl_FragData[1] = vec4(gl_Color.r/2.0, gl_Color.g/2.0,gl_Color.b/2.0,1.0);
}