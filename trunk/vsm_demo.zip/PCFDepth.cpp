//-----------------------------------------------------------------------------
#include "PCFDepth.hpp"
using namespace SH;

namespace Sheen {
//-----------------------------------------------------------------------------
PCFDepthShader::PCFDepthShader(const Args &args)
  : FwUnlitShader(args)
{
  SH_NAME(light_atten);
  
  m_vertex_shader = SH_BEGIN_VERTEX_PROGRAM {
    ShInputPosition4f  SH_DECL(position);
    ShOutputPosition4f SH_DECL(position_screen);
    ShOutputVector3f   SH_DECL(light_vec);

    position_screen = (world_view_projection_matrix() | position);
    light_vec       = (world_view_matrix()            | position)(0,1,2);
  } SH_END_PROGRAM;

  m_fragment_shader = SH_BEGIN_FRAGMENT_PROGRAM {
    ShInputPosition4f  SH_DECL(position_screen);
    ShInputVector3f    SH_DECL(light_vec);
    ShOutputAttrib1f   SH_DECL(output);

    // Compute the distance and rescale to -1 -> 1
    ShAttrib1f distance = length(light_vec);    
    ShAttrib1f rescaled_distance = mad(2.0f / light_atten(1), distance, ShConstAttrib1f(-1.0f));

    // Shadow map bias (in the spirit of glPolygonOffset)
    ShAttrib1f biased_distance = rescaled_distance + 0.05f;// + 0.008f * slope;

    output = biased_distance;
  } SH_END_PROGRAM;

  //m_fragment_shader.node()->code()->print(std::cerr);
}
//-----------------------------------------------------------------------------
} // namespace Sheen
