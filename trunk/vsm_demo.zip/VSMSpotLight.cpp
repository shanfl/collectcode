//-----------------------------------------------------------------------------
#include "VSMSpotLight.hpp"
#include "VSMDepth.hpp"
using namespace SH;

namespace Sheen {
//-----------------------------------------------------------------------------
VSMSpotLightShader::VSMSpotLightShader(const Args &args,
                                       const InstanceIDType &instance_id)
  : SpotLightShader(args, instance_id)
{
  /// Uniform parameter names
  SH_NAME(light_view_projection);
  SH_NAME(light_vsm_epsilon);
  SH_NAME(light_shadow_map);
  
  ShProgram new_light_shader = SH_BEGIN_PROGRAM("") {
    // Common interface for all light shaders
    ShInputPoint3f   SH_DECL(surf_position);
    ShInputNormal3f  SH_DECL(surf_normal);
    ShOutputColor3f  SH_DECL(light_contrib);
    ShOutputVector3f SH_DECL(dir_to_light);
    ShOutputAttrib1f SH_DECL(dist_to_light);
    ShOutputAttrib1f SH_DECL(n_dot_l);

    // Call the old light shader
    light_contrib & dir_to_light & dist_to_light & n_dot_l =
      m_light_shader(surf_position, surf_normal);

    // Transform the surface into light space and project
    ShPoint4f surf_world  = ShPoint4f(0, 0, 0, 1);
    surf_world(0,1,2) = surf_position;
    ShAttrib4f surf_tex  = light_view_projection | surf_world;
    surf_tex /= surf_tex(3);
    
    // Rescale viewport to be [0,1] (texture coordinate space)
    ShTexCoord2f shadow_tex = surf_tex(0,1) * 0.5f + 0.5f;

    // Emulate bilinear filtering?
    ShAttrib4f moments;
    if (args.shader_bilinear) {
      moments = bilinear_lookup(light_shadow_map, shadow_tex);
    } else {
      moments = light_shadow_map(shadow_tex);
    }
    
    // Recombine the four components into two high-precision ones
    if (VSMDepthShader::distribute_outputs) {
      moments(0,1) += moments(2,3) / VSMDepthShader::distribute_factor;
    }

    // Rescale light distance
    ShAttrib1f rescaled_dist_to_light;
    if (args.use_neg) {
      // Rescale to [-1, 1]
      rescaled_dist_to_light =
        mad(2.0f / light_atten(1), dist_to_light, ShConstAttrib1f(-1.0f));
    } else {
      // Rescale to [0, 1]
      rescaled_dist_to_light = dist_to_light / light_atten(1);
    }

    // Standard shadow map comparison
    ShAttrib1f lit_factor = (rescaled_dist_to_light <= moments(0));
    
    // Variance shadow mapping
    ShAttrib1f E_x2 = moments(1);
    ShAttrib1f Ex_2 = moments(0) * moments(0);
    ShAttrib1f variance = min(max(E_x2 - Ex_2, 0) + light_vsm_epsilon, 1);
    ShAttrib1f m_d = (moments(0) - rescaled_dist_to_light);
    ShAttrib1f p_max = variance / (variance + m_d * m_d);
    
    // Adjust the light color based on the shadow attenuation
    light_contrib *= max(lit_factor, p_max);
  } SH_END_PROGRAM;

  // Use our new light shader
  m_light_shader = new_light_shader;
}
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
void VSMSpotLight::defaults()
{
  set_param("light_vsm_epsilon", 0.00001f);

  // Default shadow map settings
  m_shadow_map_settings.width = 512;
  m_shadow_map_settings.height = 512;
  m_shadow_map_settings.mip_mapped = true;
  m_shadow_map_settings.depth_buffer = true;
  m_shadow_map_settings.gl_texture_target = GL_TEXTURE_2D;
  m_shadow_map_settings.gl_texture_format = GL_RGBA16F_ARB;
  m_shadow_map_settings.gl_texture_min_filter = GL_LINEAR;
  m_shadow_map_settings.gl_texture_mag_filter = GL_LINEAR;
  m_shadow_map_settings.gl_texture_max_aniso = 1.0f;
}
//-----------------------------------------------------------------------------
} // namespace Sheen
