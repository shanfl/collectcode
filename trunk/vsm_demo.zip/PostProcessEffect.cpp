//-----------------------------------------------------------------------------
#include "PostProcessEffect.hpp"

namespace Sheen {
//-----------------------------------------------------------------------------
PostProcessShader::PostProcessShader(const Args &args)
  : NamedParamsShader(args)
{
  /// Create the vertex shader
  m_vertex_shader = SH_BEGIN_VERTEX_PROGRAM {
    SH::ShInOutPosition4f SH_DECL(position);
    SH::ShInOutTexCoord2f SH_DECL(tex_coord);
  } SH_END_PROGRAM;
}
//-----------------------------------------------------------------------------
void PostProcessShader::prepare_shader()
{
  // Name the shader programs (because we can)
  SH_NAME(m_vertex_shader);
  SH_NAME(m_fragment_shader);

  // Align vertex shader outputs with fragment shader inputs (by name)
  m_vertex_shader = SH::namedAlign(m_vertex_shader, m_fragment_shader);
  m_shaders = new SH::ShProgramSet(m_vertex_shader, m_fragment_shader);

  // Now make sure that our shaders have been prepared by the renderer
  render_device->prepare_shader(m_vertex_shader);
  render_device->prepare_shader(m_fragment_shader);

  // Add uniforms and textures from the user shader to our sets
  add_parameters(m_fragment_shader);
  add_textures(m_fragment_shader);

  // Call the parent
  NamedParamsShader::prepare_shader();
}
//-----------------------------------------------------------------------------
void PostProcessShader::bind()
{
  verify_shader_prepared();
  render_device->shaders(*m_shaders);
}
//-----------------------------------------------------------------------------
} // namespace Sheen
