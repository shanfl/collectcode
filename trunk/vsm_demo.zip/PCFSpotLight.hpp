#ifndef FWPCFSPOTLIGHT_HPP
#define FWPCFSPOTLIGHT_HPP
//-----------------------------------------------------------------------------
#include <sheen/SpotLight.hpp>
#include "GlFBOCache.hpp"

namespace Sheen {
//-----------------------------------------------------------------------------
/** A spot light shader with variance shadow mapping.
 */
class PCFSpotLightShader : public SpotLightShader
{
public:
  struct Args : public SpotLightShader::Args
  {
    typedef SpotLightShader::Args Super;
    bool bilinear;           ///< Bilinear filter result of depth compare
    int kernel_size;         ///< Delta in each of 4 directions
    float sigma;             ///< StdDev of distribution in pixels. >0

    Args(bool bil = false, int kernel = 1, float sig = 3)
      : bilinear(bil), kernel_size(kernel), sigma(sig) {}
    bool operator<(const Args &p) const
    {
      // Call the parent
      if      (static_cast<const Super &>(*this) < p    ) return true;
      else if (static_cast<const Super &>(p)     < *this) return false;
      if      (  bilinear < p.bilinear)                   return true;
      else if (p.bilinear <   bilinear)                   return false;
      if      (  kernel_size < p.kernel_size)             return true;
      else if (p.kernel_size <   kernel_size)             return false;
      if      (  sigma < p.sigma)                         return true;
      //else if (p.sigma <   sigma)                         return false;
      return false;
    }
  };

protected:
  // Uniform parameters
  SH::ShMatrix4x4f light_view_projection;

  SH::ShWrapClampToEdge< SH::ShInterp<0, SH::ShNoMIPFilter<
    SH::ShTexture2D<SH::ShAttrib1f> > > > light_shadow_map;

public:
  PCFSpotLightShader(const Args &args, const InstanceIDType &instance_id);
};
//-----------------------------------------------------------------------------
class PCFSpotLight;
typedef SH::ShPointer<PCFSpotLight> PCFSpotLightPtr;
typedef SH::ShPointer<const PCFSpotLight> PCFSpotLightCPtr;

class PCFSpotLight
  : public LightTemplate<PCFSpotLightShader, SpotLight>
{
private:
  typedef LightTemplate<PCFSpotLightShader, SpotLight> Super;
  
  /// The requested settings for the shadow map
  /// TODO: Abstract to API-independent representation
  GlFBOSettings m_shadow_map_settings;

  void defaults();

protected:
  /// Passthrough an already-constructed shader
  /// Optional constructor for passing through an already-created shader.
  PCFSpotLight(const LightShaderPtr &shader)
    : Super(shader)
  {
    defaults();
  }

public:
  /// Create a new point light and associated shader.
  PCFSpotLight(bool bilinear = false, int kernel_size = 1, float sigma = 3)
    : Super(ShaderArgs(bilinear, kernel_size, sigma))
  {
    defaults();
  }

  SHEEN_FWLIGHT_CLONE(PCFSpotLight);

  /// Get the requested shadow map settings, read/write.
  GlFBOSettings & shadow_map_settings()
  {
    return m_shadow_map_settings;
  }
  /// Get the requested shadow map settings, read only.
  const GlFBOSettings & shadow_map_settings() const
  {
    return m_shadow_map_settings;
  }
};
//-----------------------------------------------------------------------------
} // namespace Sheen
#endif
