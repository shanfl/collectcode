#ifndef GLFBOCACHE_HPP
#define GLFBOCACHE_HPP
//-----------------------------------------------------------------------------
#include "PostProcessEffect.hpp"
#include "GlFramebufferObject.hpp"

namespace Sheen {
//-----------------------------------------------------------------------------
/** Implement a cache of FBO's.
 * Also provides convenience functionality for applying post-processing effects
 * to buffers. This makes sense to put in here since it involves swapping FBOs
 * around and creating temporaries.
 */
class GlFBOCacheBase
{
public:
  typedef SH::ShTexture2D<SH::ShColor4f> ShTextureType;

private:
  typedef std::multimap<GlFBOSettings, GlFramebufferObjectPtr> FBOMap;
  /// FBO's, organized by settings
  FBOMap m_fbo_map;

  /// Post-processing variables
  Sheen::GeoPrimChunkPtr m_screen_aligned_quad;
  ShTextureType m_source_texture;

public:
  GlFBOCacheBase();
  virtual ~GlFBOCacheBase() {}

  /// Get an FBO with the given settings, creating a new one if necessary.
  GlFramebufferObjectPtr get(const GlFBOSettings &settings);

  /// Return an FBO to the available set.
  /// After this point the caller should destroy all references to the FBO.
  void done_with(const GlFramebufferObjectPtr &fbo);

  /// Clear the cache
  /// Only works for available FBO's, not ones that are currently being used!
  void clear()
  {
    m_fbo_map.clear();
  }

  /// Apply the given post processing effect to the given buffer, returning
  /// the new buffer and putting the old one back in the available set.
  GlFramebufferObjectPtr apply_pp_effect(const GlFramebufferObjectPtr &fbo,
                                         const PostProcessEffectPtr &effect);
};
//-----------------------------------------------------------------------------
/// Create a singleton for it
typedef AutoSingleton<GlFBOCacheBase> GlFBOCache;
//-----------------------------------------------------------------------------
} // namespace Sheen
#endif
