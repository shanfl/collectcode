//-----------------------------------------------------------------------------
#include "VSM.hpp"
using namespace std;
using namespace Sheen;
//-----------------------------------------------------------------------------
VSMApp::VSMApp()
  : Sheen::Framework()
{
  // Initiailze any pointers, etc.
  m_scene = 0;
  m_renderer = 0;
  m_paused = false;
  m_use_light2 = false;
}
//-----------------------------------------------------------------------------
VSMApp::~VSMApp()
{
  show_cursor();
  delete m_scene;
  delete m_renderer;
}
//-----------------------------------------------------------------------------
void VSMApp::init()
{
  Framework::init("Variance Shadow Maps Demo");
}
//-----------------------------------------------------------------------------
void VSMApp::run()
{
  init_after_video();
  frame_time.reset();
  m_time_passed = 0;
  Framework::run();
}
//-----------------------------------------------------------------------------
void VSMApp::init_after_video()
{
  SH::shSetBackend("glsl");

  // ARB_texture_float is indicative of GF6/7 here
  m_supports_fp16_filtering = GLEW_ARB_texture_float ? true : false;

  // ATI supports fixed point blending, NV doesn't
  m_supports_rgba16_filtering = !m_supports_fp16_filtering;

  m_shadow_type = ST_VSM16;
  m_shadow_map_dim = 512;
  m_blur_preset = 0;

  if (m_supports_fp16_filtering) {
    std::cout << "Hardware supports fp16 filtering." << std::endl;
  } else {
    std::cout << "Hardware does NOT support fp16 filtering." << std::endl;
  }
  if (m_supports_rgba16_filtering) {
    std::cout << "Hardware supports 16-bit fixed point filtering." << std::endl;
  } else {
    std::cout << "Hardware does NOT 16-bit fixed point filtering." << std::endl;
  }

  // Renderer must be initialized before the scene since it affects material
  // creation and setup.
  init_renderer();
  init_scene("media/");
  init_materials("media/");
  init_lights();
}
//-----------------------------------------------------------------------------
void VSMApp::init_renderer()
{
  delete m_renderer;
  m_renderer = new FwRenderer();
  m_materials = new FwRenderer::SceneMaterials();

  m_default_material = new FwSolidColor();
  m_default_material->set_param("solid_color", Attrib3f(1, 0, 1));

  m_materials->add_global_lighting_config(LightList());
}
//-----------------------------------------------------------------------------
void VSMApp::init_scene(const std::string &media_dir)
{
  delete m_scene;
  m_scene = new SceneGraph();

  // Load models
  SGTraAffinePtr object_model = Loader::FF3DS::load(media_dir+"Beast.3ds");
  SGTraAffinePtr ground_model = Loader::FF3DS::load(media_dir+"GroundPlane.3ds");
  SGTraAffinePtr spot_light_model = Loader::FF3DS::load(media_dir+"SpotLight.3ds");

  // Setup models
  SGTraAffinePtr models = new SGTraAffine("Models");
  models->add_child(object_model);
  models->add_child(ground_model);
  models->add_child(spot_light_model);
  // Above group is purely for convenience in traversing all models
  for_each<SGTraGeoInst>(models,
                         GeoSetHardwareStorages(HBU_STATIC, HBU_STATIC));

  // Create a basic scene
  {
    // Ground
    m_scene->tra_root()->add_child(ground_model->clone("Ground"));

    // Feature object
    SGTraAffinePtr object_1 = object_model->clone("Object1");    
    object_1->translation(Vec3(30, 0, -100));
    m_scene->tra_root()->add_child(object_1);

    // Second feature object
    SGTraAffinePtr object_2 = object_model->clone("Object2");
    object_2->translation(Vec3(-30, 0, 100));
    m_scene->tra_root()->add_child(object_2);
    
    // Animated light looks at object 1
    m_light1_tra = new SGTraLookAt("SceneLight");
    m_scene->tra_root()->add_child(m_light1_tra);
    object_1->add_child(m_light1_tra->target());

    // Extra (static) light looks at object 2
    m_light2_tra = new SGTraLookAt("ExtraLight");
    m_light2_tra->translation(Vec3(0, 200, 500));
    m_scene->tra_root()->add_child(m_light2_tra);
    object_2->add_child(m_light2_tra->target());

    // Geometry for the light (used when a light is enabled)
    m_light_icon = spot_light_model->clone("Icon");
    m_light_icon->translation(Vec3(-10, 0, 0));
  }

  // Setup a camera
  {
    m_camera = new SGTraLookAt("SceneCamera");
    m_camera_target = new SGTraAffine("SceneCameraLookAt");
    m_camera_target->add_child(m_camera->target());
    m_camera_node = new SGTraPerspectiveCamera("Camera");
    m_camera->add_child(m_camera_node);

    m_scene->tra_root()->add_child(m_camera);
    m_scene->tra_root()->add_child(m_camera_target);

    // Camera properties
    m_camera_node->aspect(static_cast<Scalar>(width()) /
                          static_cast<Scalar>(height()));
    m_camera_node->fov_y(PI/4);
    m_camera_node->z_range(Vec2(10, 10000));

    // Initial transforms
    m_camera->translation(Vec3(750, 540, 750));
    m_camera_target->translation(Vec3(0, 50, 0));
  }
}
//-----------------------------------------------------------------------------
void VSMApp::init_lights()
{
  bool vsm = (m_shadow_type == ST_VSM16 ||
              m_shadow_type == ST_VSM16F ||
              m_shadow_type == ST_VSM32F);

  // Presets
  static const int kernels[]  = {   0,    1,    2,    3,    5,    6};
  static const float sigmas[] = {1.0f, 0.8f, 1.6f, 3.0f, 5.0f, 6.0f};

  // Non-vsm cannot use larger kernels  
  if (vsm) {
    m_blur_preset = min(5, max(0, m_blur_preset));
  } else {
    m_blur_preset = min(2, max(0, m_blur_preset));
  }  

  // Check for support of extensions
  if (!GLEW_EXT_framebuffer_object)
    throw GlException("EXT_framebuffer_object is required!");
  if (!GLEW_ARB_texture_float && !GLEW_ATI_texture_float)
    throw Sheen::GlException("ARB_texture_float is required!");
  if (!GLEW_EXT_texture_filter_anisotropic)
    throw Sheen::GlException("EXT_texture_filter_anisotropic is required!");

  // Recreate lights
  m_light1_tra->remove_all_children();
  m_light2_tra->remove_all_children();

  // Release any FBO's... they'll get recreated with the new types.
  // This isn't strictly necessary but it saves some VRAM by getting rid of
  // the extra FBO's produced by different parameters.
  GlFBOCache::instance()->clear();

  // Prepare strings
  ostringstream shadow_map_oss;
  ostringstream technique_oss;

  shadow_map_oss << m_shadow_map_dim << "x" << m_shadow_map_dim;

  SGTraSpotLightPtr scene_light;
  if (vsm) {
    technique_oss << "VSM";

    bool hardware_filtering =
      (m_supports_fp16_filtering && m_shadow_type == ST_VSM16F) ||
      (m_supports_rgba16_filtering && m_shadow_type == ST_VSM16);

    // Use negative values for float textures for increased precision
    bool use_neg = (m_shadow_type != ST_VSM16);

    // Create the light (do bilinear in shader if unsupported in hardware)
    SGTraVSMSpotLightPtr light =
      new SGTraVSMSpotLight("Light1", !hardware_filtering, use_neg);
    scene_light = light;

    // FBO parameters
    GlFBOSettings &fbo = light->light()->shadow_map_settings();
    fbo.width = fbo.height    = m_shadow_map_dim;

    // Use the requested texture format and associated parameters
    switch (m_shadow_type) {
      case ST_VSM16:
        shadow_map_oss << " RGBA16";
        fbo.gl_texture_format     = GL_RGBA16_EXT;
        fbo.mip_mapped            = true;
        light->light()->set_param("light_vsm_epsilon", 0.000005f);
        break;
      case ST_VSM16F:
        shadow_map_oss << " RGBA16F";
        fbo.gl_texture_format     = GL_RGBA16F_ARB;        
        fbo.mip_mapped            = m_supports_fp16_filtering;
        light->light()->set_param("light_vsm_epsilon", 0.00001f);
        break;
      case ST_VSM32F:
        shadow_map_oss << " RGBA32F";
        fbo.gl_texture_format     = GL_RGBA32F_ARB;
        fbo.mip_mapped            = false;    // TODO: True on NVIDIA?
        light->light()->set_param("light_vsm_epsilon", 0.000005f);
        break;
    };

    // Setup hardware filtering (if supported)
    if (hardware_filtering) {
      fbo.gl_texture_min_filter = fbo.mip_mapped ? GL_LINEAR_MIPMAP_LINEAR : GL_LINEAR;
      fbo.gl_texture_mag_filter = GL_LINEAR;
      fbo.gl_texture_max_aniso  = 16.0f;
    } else {
      fbo.gl_texture_min_filter = fbo.mip_mapped ? GL_NEAREST_MIPMAP_NEAREST : GL_NEAREST;
      fbo.gl_texture_mag_filter = GL_NEAREST;
      fbo.gl_texture_max_aniso  = 1.0f;
    }

    // Setup blurring
    light->blur(kernels[m_blur_preset], sigmas[m_blur_preset]);

    int dim = kernels[m_blur_preset] * 2 + 1;
    if (dim > 1) {
      technique_oss << " + " << dim << "x" << dim << " Blur";
    }

    // Make sure our scene materials are set up to use these lights
    LightList lights;
    lights.push_back(new VSMSpotLight(!hardware_filtering, use_neg));
    if (m_use_light2) {
      lights.push_back(new VSMSpotLight(!hardware_filtering, use_neg));
    }
    m_materials->add_global_lighting_config(lights);

  } else {
    bool bilinear = (m_shadow_type == ST_PCF_B);

    technique_oss << (bilinear ? "Bil PCF" : "PCF");

    // Create the light
    SGTraPCFSpotLightPtr light = new SGTraPCFSpotLight("Light1",
      bilinear, kernels[m_blur_preset], sigmas[m_blur_preset]);
    scene_light = light;

    int dim = kernels[m_blur_preset] * 2 + 1;
    if (dim > 1) {
      technique_oss << " " << dim << "x" << dim;
    }

    // FBO parameters
    GlFBOSettings &fbo = light->light()->shadow_map_settings();
    fbo.width = fbo.height = m_shadow_map_dim;

    shadow_map_oss << " RGBA16F";

    // Make sure our scene materials are set up to work with this
    LightList lights;
    lights.push_back(new PCFSpotLight
      (bilinear, kernels[m_blur_preset], sigmas[m_blur_preset]));
    if (m_use_light2) {
      lights.push_back(new PCFSpotLight
        (bilinear, kernels[m_blur_preset], sigmas[m_blur_preset]));
    }
    m_materials->add_global_lighting_config(lights);
  }
  
  // Reattach and setup the lights
  if (scene_light) {
    m_light1_tra->add_child(scene_light);
    m_light1_tra->add_child(m_light_icon->clone());

    scene_light->color(Attrib3f(2.0f, 2.0f, 2.0f));
    scene_light->atten(Vec2(1300, 1600));
    scene_light->angle_atten(Vec2(PI*5/16, PI*8/16));

    if (m_use_light2) {
      // Clone the light
      SGTraSpotLightPtr extra_light = scene_light->clone("Light2");
      m_light2_tra->add_child(extra_light);
      m_light2_tra->add_child(m_light_icon->clone());
      
      // Setup settings
      extra_light->color(Attrib3f(2.2f, 1.8f, 1.8f));

      // Modify our other light as necessary
      scene_light->color(Attrib3f(1.5f, 1.5f, 1.7f));
    }
  }

  // Finalize strings
  m_shadow_map_string = shadow_map_oss.str();
  m_technique_string = technique_oss.str();

  std::cout << endl;
  std::cout << m_shadow_map_string << std::endl;
  std::cout << m_technique_string << std::endl;

  frame_time.reset();
}
//-----------------------------------------------------------------------------
void VSMApp::do_frame()
{
  input();
  move();
  draw();
}
//-----------------------------------------------------------------------------
void VSMApp::draw()
{
  // Clear The Screen And The Depth Buffer
  render_device->clear(RB_COLOR | RB_DEPTH, Attrib4f(0, 0, 0, 0), 1.0);

  // Render the scene using our current camera
  m_renderer->render(m_scene, Attrib4i(0, 0, width(), height()),
                     m_camera_node, m_materials, m_default_material);

  flip();
}
//-----------------------------------------------------------------------------
void VSMApp::move()
{
  Scalar time_change = static_cast<Scalar>(frame_time.time_change_sec());

  if (!m_paused) {
    m_time_passed += time_change;

    // Fly the light around
    m_light1_tra->translation
      (Vec3(cos(m_time_passed * 0.2f) * 400, 300,
            sin(m_time_passed * 0.2f) * 400));
  }

  m_scene->tra_root()->update_world_matrices();
}
//-----------------------------------------------------------------------------
void VSMApp::input()
{
  bool reinit = false;

  if (keyboard->key_pressed(KEY_ESCAPE)) {
    exit();
  }

  if (keyboard->key_pressed(KEY_SPACE)) {
    m_paused = !m_paused;
  }

  // Toggle second light  
  if (keyboard->key_pressed(KEY_L)) {
    m_use_light2 = !m_use_light2;
    reinit = true;
  }
  
  // Set technique
  if (keyboard->key_pressed(KEY_F5)) {
    m_shadow_type = ST_PCF;
    reinit = true;
  } else if (keyboard->key_pressed(KEY_F6)) {
    m_shadow_type = ST_PCF_B;
    reinit = true;
  } else if (keyboard->key_pressed(KEY_F7)) {
    m_shadow_type = ST_VSM16;
    reinit = true;
  } else if (keyboard->key_pressed(KEY_F8)) {
    m_shadow_type = ST_VSM16F;
    reinit = true;
  } else if (keyboard->key_pressed(KEY_F9)) {
    m_shadow_type = ST_VSM32F;
    reinit = true;
  }
  
  // Rotate shadow map size
  if (keyboard->key_pressed(KEY_S)) {
    m_shadow_map_dim = max(64, (m_shadow_map_dim << 1) % 2048);
    reinit = true;
  }


  // Blur kernel size shortcuts
  bool blur_changed = true;
  if      (keyboard->key_pressed(KEY_0)) m_blur_preset = 0;
  else if (keyboard->key_pressed(KEY_1)) m_blur_preset = 1;
  else if (keyboard->key_pressed(KEY_2)) m_blur_preset = 2;
  else if (keyboard->key_pressed(KEY_3)) m_blur_preset = 3;
  else if (keyboard->key_pressed(KEY_4)) m_blur_preset = 4;
  else if (keyboard->key_pressed(KEY_5)) m_blur_preset = 5;
  else                                   blur_changed = false;
  reinit |= blur_changed;


  // Reinitialize if necessary
  if (reinit) {
    init_lights();
  }


  // Mouse Orbit
  if (mouse->button_down(MOUSEBUTTON_LEFT)) {
    const Scalar sensativity = 0.006f;
    Scalar polar = -mouse->rel_x() * sensativity;
    Scalar azim = mouse->rel_y() * sensativity;
    if (polar != 0.0f || azim != 0.0f)
      m_camera->orbit(polar, azim, 0.1f, false);
  }
  
  // Mouse Pan
  if (mouse->button_down(MOUSEBUTTON_RIGHT)) {
    if (mouse->rel_x() != 0.0f || mouse->rel_y() != 0.0f) {
      // Roughly base the sensitivity on the ratio of the screen that we've
      // moved the mouse. This is an incorrect approximation, but it works OK
      // most of the time.
      Scalar sens = length(m_camera->vector_to_target());
      Scalar horiz_sens = sens / width();
      Scalar vert_sens = sens / height();
      
      Scalar horiz = -mouse->rel_x() * horiz_sens;
      Scalar vert = mouse->rel_y() * vert_sens;
      
      // Pan the camera and the target
      Vec3 d = m_camera->pan(horiz, vert);
      m_camera_target->translation(m_camera_target->translation() + d);
    }
  }
  
  // Mouse Dolly
  if (mouse->button_down(MOUSEBUTTON_MIDDLE)) {
    const Scalar sensativity = 5.0f;
    const Scalar min_distance = 10.0f;
    m_camera->dolly(-mouse->rel_y() * sensativity, min_distance);
  }
}
//-----------------------------------------------------------------------------
void VSMApp::init_materials(const std::string &media_dir)
{
  // Beast
  {
    SH::ShTexture2D<SH::ShColor4fub> beast_1_texture;
    SH::ShTexture2D<SH::ShColor4fub> beast_2_texture;

    TextureFactory::instance()->load(media_dir+"Beast_1.png", beast_1_texture);
    TextureFactory::instance()->load(media_dir+"Beast_2.png", beast_2_texture);

    FwMaterialPtr material = new FwTexPhong(true);
    material->set_texture("diffuse_texture", beast_1_texture);
    material->set_param("specular_color", Attrib3f(0.3f, 0.3f, 0.3f));
    material->set_param("specular_power", 80.0);
    m_materials->material("Beast_1", material);

    material = new FwTexPhong(true);
    material->set_texture("diffuse_texture", beast_2_texture);
    material->set_param("specular_color", Attrib3f(0.1f, 0.1f, 0.1f));
    material->set_param("specular_power", 80.0);
    m_materials->material("Beast_2", material);
  }

  // Ground
  {
    SH::ShWrapRepeat< SH::ShTexture2D<SH::ShColor4fub> > texture;
    TextureFactory::instance()->load(media_dir+"brick_texture1.png", texture);

    FwMaterialPtr material = new FwTexPhong(false);
    material->set_texture("diffuse_texture", texture);
    m_materials->material("Ground", material);
  }
}
//-----------------------------------------------------------------------------
