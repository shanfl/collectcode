#ifndef FWPCFDEPTH_HPP
#define FWPCFDEPTH_HPP
//-----------------------------------------------------------------------------
#include <sheen/FwUnlitMaterial.hpp>

namespace Sheen {
//-----------------------------------------------------------------------------
class PCFDepthShader : public FwUnlitShader
{
protected:
  SH::ShAttrib2f light_atten;
  
public:
  PCFDepthShader(const Args &args);
};
//-----------------------------------------------------------------------------
class PCFDepth : public FwUnlitMaterial<PCFDepthShader>
{
private:
  typedef FwUnlitMaterial<PCFDepthShader> Super;

public:
  PCFDepth()
    : Super(ShaderArgs())
  {}
};
//-----------------------------------------------------------------------------
} // namespace Sheen
#endif
