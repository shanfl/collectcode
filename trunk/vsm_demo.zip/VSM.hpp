#ifndef VSMAPP_HPP
#define VSMAPP_HPP
//-----------------------------------------------------------------------------
// Change this (and possibly linked libraries) to use a different framework
#include <sheen/framework/SDLFramework.hpp>
//-----------------------------------------------------------------------------
#include <sheen/OpenGL.hpp>
#include <sheen/Win32Defines.hpp>

#include "SGTraVSMLight.hpp"
#include "SGTraPCFLight.hpp"
#include "FwSimpleTexture.hpp"
//-----------------------------------------------------------------------------
/** A simple test application using the "chosen framework".
 */
class VSMApp : public Sheen::Framework
{
private:
  enum ShadowType {
    ST_VSM16 = 0,
    ST_VSM16F,
    ST_VSM32F,
    ST_PCF,
    ST_PCF_B
  };

  // Scene graph and renderer variables
  Sheen::SceneGraph                    *m_scene;
  Sheen::FwRenderer                    *m_renderer;
  Sheen::FwRenderer::SceneMaterialsPtr  m_materials;
  Sheen::FwMaterialPtr                  m_default_material;
  
  // Fonts and display
  std::string                           m_technique_string;
  std::string                           m_shadow_map_string;

  // Camera
  Sheen::SGTraLookAtPtr                 m_camera;
  Sheen::SGTraAffinePtr                 m_camera_target;
  Sheen::SGTraPerspectiveCameraPtr      m_camera_node;

  // Scene node variables
  Sheen::SGTraAffinePtr                 m_light_icon;
  Sheen::SGTraLookAtPtr                 m_light1_tra;
  Sheen::SGTraLookAtPtr                 m_light2_tra;

  // Settings
  ShadowType                            m_shadow_type;
  bool                                  m_use_light2;
  int                                   m_shadow_map_dim;
  int                                   m_blur_preset;  

  // Misc
  bool                                  m_paused;
  Sheen::Scalar                         m_time_passed;
  bool                                  m_supports_fp16_filtering;
  bool                                  m_supports_rgba16_filtering;

protected:
  virtual void do_frame();
  
  void draw();
  void move();
  void input();

  void init_after_video();
  void init_renderer();
  void init_scene(const std::string &media_dir);
  void init_lights();
  void init_materials(const std::string &media_dir);

public:
  VSMApp();
  ~VSMApp();
  
  virtual void init();
  virtual void run();
};
//-----------------------------------------------------------------------------
#endif
