#ifndef SGTRAFWVSMSPOTLIGHT_HPP
#define SGTRAFWVSMSPOTLIGHT_HPP
//-----------------------------------------------------------------------------
#include <sheen/SGTraLight.hpp>
#include "SGSpaVSMLight.hpp"

namespace Sheen {
//-----------------------------------------------------------------------------
class SGTraVSMSpotLight;
typedef SH::ShPointer<SGTraVSMSpotLight> SGTraVSMSpotLightPtr;
typedef SH::ShPointer<const SGTraVSMSpotLight> SGTraVSMSpotLightCPtr;

/** A transformed forward renderer spot light node.
 */
class SGTraVSMSpotLight
  : public SGCreatableNode<SGTraVSMSpotLight, SGTraSpotLight>
{
private:
  typedef SGCreatableNode<SGTraVSMSpotLight, SGTraSpotLight> Super;

  SGSpaVSMSpotLightPtr m_spa_node;

protected:
  void virtual_set_node(SGSpaVSMSpotLight *node)
  {
    Super::virtual_set_node(node);
    m_spa_node = node;
  }

public:
  SGTraVSMSpotLight(const std::string &name, bool shader_bilinear,
                    bool use_neg)
    : Super(name)
  {
    virtual_set_node(new SGSpaVSMSpotLight(name, shader_bilinear, use_neg));
  }

  /// Copy constructor
  explicit SGTraVSMSpotLight(const SGTraVSMSpotLight &n)
    : Super(n)
  {
    virtual_set_node(n.m_spa_node->clone());
  }

  SHEEN_SGCREATABLENODE_CLONE(SGTraVSMSpotLight);

  /// Set the VSM blur size
  void blur(int size, float sigma) { m_spa_node->blur(size, sigma); }

  virtual VSMSpotLight * light() const { return m_spa_node->light(); }
};
//-----------------------------------------------------------------------------
} // namespace Sheen
#endif
