//-----------------------------------------------------------------------------
#include "PCFSpotLight.hpp"
using namespace SH;

namespace Sheen {
//-----------------------------------------------------------------------------
PCFSpotLightShader::PCFSpotLightShader(const Args &args,
                                       const InstanceIDType &instance_id)
  : SpotLightShader(args, instance_id)
{
  /// Uniform parameter names
  SH_NAME(light_view_projection);
  SH_NAME(light_shadow_map);
  
  // Evaluate the gaussian function over this kernel size
  float *weights = new float[args.kernel_size + 1];
  float total = 0.0f;
  for (int i = 0; i <= args.kernel_size; ++i) {
    weights[i] = std::exp(-static_cast<float>(i*i) /
                          (2.0f * args.sigma * args.sigma)) / args.sigma;
    total += (i == 0 ? 1 : 2) * weights[i];
  }
  // Normalize the distribution function
  for (int i = 0; i <= args.kernel_size; ++i) {
    weights[i] /= total;
  }
  
  ShProgram new_light_shader = SH_BEGIN_PROGRAM("") {
    // Common interface for all light shaders
    ShInputPoint3f   SH_DECL(surf_position);
    ShInputNormal3f  SH_DECL(surf_normal);
    ShOutputColor3f  SH_DECL(light_contrib);
    ShOutputVector3f SH_DECL(dir_to_light);
    ShOutputAttrib1f SH_DECL(dist_to_light);
    ShOutputAttrib1f SH_DECL(n_dot_l);

    // Call the old light shader
    light_contrib & dir_to_light & dist_to_light & n_dot_l =
      m_light_shader(surf_position, surf_normal);

    // Transform the surface into light space and project
    ShPoint4f surf_world  = ShPoint4f(0, 0, 0, 1);
    surf_world(0,1,2) = surf_position;
    ShAttrib4f surf_tex  = light_view_projection | surf_world;
    surf_tex /= surf_tex(3);
    
    // Rescale viewport to be [0,1] (texture coordinate space)
    ShTexCoord2f shadow_tex = surf_tex(0,1) * 0.5f + 0.5f;

    // Rescale light distance
    ShAttrib1f rescaled_dist_to_light =
      mad(2.0f / light_atten(1), dist_to_light, ShConstAttrib1f(-1.0f));

    // Work out pixel offsets
    ShAttrib2f tex_size = light_shadow_map.size();
    ShAttrib2f tex_size_inv = 1 / tex_size;


    // Bilinear filtering stuff - we expect it to get optimized out if we
    // don't use it later.
    
    // Work out the 4 lookup coordinates.
    // We subtract 0.5 here to line up texel centers the same was as hardware
    // bilinear filtering does it.
    ShTexCoord4f device_coords = (shadow_tex * tex_size)(0,1,0,1) +
      ShConstAttrib4f(-0.5f, -0.5f, 0.5f, 0.5f);
    
    // Filter weights are based on the fractional part of the texture coords
    SH::ShAttrib4f bil_weights;
    bil_weights(0,1) = frac(device_coords(0,1));
    bil_weights(2,3) = 1 - bil_weights(0,1);
    bil_weights = bil_weights(0,2,0,2) * bil_weights(1,1,3,3);

    
    // Loop over the PCF region
    ShAttrib1f lit_texels = ShAttrib1f(0.0);
    for (short int x = -args.kernel_size; x <= args.kernel_size; ++x) {
      for (short int y = -args.kernel_size; y <= args.kernel_size; ++y) {
        // Offset texture coordinates
        ShConstAttrib2f offset(x, y);
        
        ShAttrib1f result;
        if (args.bilinear) {
          // Take four samples and bilinearly interpolate
          ShTexCoord4f coords = (device_coords + offset(0,1,0,1)) *
                                tex_size_inv(0,1,0,1);
          ShAttrib4f reads;
          reads(0) = light_shadow_map(coords(2,3))(0);
          reads(1) = light_shadow_map(coords(0,3))(0);
          reads(2) = light_shadow_map(coords(2,1))(0);
          reads(3) = light_shadow_map(coords(0,1))(0);
          // Depth compare and bilinear weighting
          result = dot(bil_weights, (rescaled_dist_to_light <= reads));
        }
        else {
          // Single nearest neighbor lookup
          ShTexCoord2f coords = shadow_tex + (offset * tex_size_inv);
          result = (rescaled_dist_to_light <= light_shadow_map(coords)(0));
        }
        
        // Check if we're in shadow
        lit_texels += (weights[abs(x)] * weights[abs(y)]) * result;
      }
    }

    // Adjust the light color based on percentage of texels in shadow
    light_contrib *= lit_texels;
  } SH_END_PROGRAM;

  // Use our new light shader
  m_light_shader = new_light_shader;
}
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
void PCFSpotLight::defaults()
{
  set_param("light_shadow_bias", 0.005f);

  // Default shadow map settings
  m_shadow_map_settings.width = 512;
  m_shadow_map_settings.height = 512;
  m_shadow_map_settings.mip_mapped = false;
  m_shadow_map_settings.depth_buffer = true;
  m_shadow_map_settings.gl_texture_target = GL_TEXTURE_2D;
  m_shadow_map_settings.gl_texture_format = GL_RGB16F_ARB;
  // Filtering should not be used with standard shadow mapping / PCF
  m_shadow_map_settings.gl_texture_min_filter = GL_NEAREST;
  m_shadow_map_settings.gl_texture_mag_filter = GL_NEAREST;
  m_shadow_map_settings.gl_texture_max_aniso = 1.0f;
}
//-----------------------------------------------------------------------------
} // namespace Sheen
