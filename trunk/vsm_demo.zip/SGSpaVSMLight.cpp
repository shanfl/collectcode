//-----------------------------------------------------------------------------
#include "SGSpaVSMLight.hpp"

namespace Sheen {
//-----------------------------------------------------------------------------
SGSpaVSMSpotLight::SGSpaVSMSpotLight(const std::string &name,
                                     bool shader_bilinear,
                                     bool use_neg)
  : Super(name)
{
  virtual_set_light(new VSMSpotLight(shader_bilinear, use_neg));
  dependency_calls = 0;
  m_vsm_depth = new VSMDepth(use_neg);
}
//-----------------------------------------------------------------------------
SGSpaVSMSpotLight::SGSpaVSMSpotLight(const SGSpaVSMSpotLight &n)
  : Super(n)
{
  virtual_set_light(n.m_light->clone());
  dependency_calls = 0;
  m_vsm_depth = n.m_vsm_depth->clone();

  // TODO: Copy blur settings correctly!
  m_blur_horiz = n.m_blur_horiz;
  m_blur_vert = n.m_blur_vert;
}
//-----------------------------------------------------------------------------
SGSpaVSMSpotLight::~SGSpaVSMSpotLight()
{
  if (m_shadow_map)
    GlFBOCache::instance()->done_with(m_shadow_map);
}
//-----------------------------------------------------------------------------
void SGSpaVSMSpotLight::generate_dependencies(SceneGraph *scene,
                                              const FwRenderer *renderer)
{
  ++dependency_calls;

  // Check if we need to generate a shadow map
  if (!m_shadow_map) {
    // Grab a (new) FBO with the requested settings
    GlFBOCache *fbo_cache = GlFBOCache::instance();
    m_shadow_map = fbo_cache->get(m_light->shadow_map_settings());

    // Setup for the depth pass
    m_vsm_depth->set_param("light_atten", atten());
    const WorldTransform &light_transform = world_transform();
    const Mat4x4 view = light_transform.camera_matrix();
    const Mat4x4 view_inv = light_transform.camera_inv_matrix();
    const Mat4x4 projection = projection_matrix();

    // Setup viewport and begin render
    m_shadow_map->bind();
    render_device->clear(RB_COLOR | RB_DEPTH, Attrib4f(1, 1, 1, 1), 1.0);
    renderer->render
      (scene,
       Attrib4i(0, 0, m_shadow_map->width(), m_shadow_map->height()),
       view, view_inv, projection,
       0,           // No scene materials
       m_vsm_depth, // Use our depth material for everything
       false        // Don't generate other light dependencies
       );
    m_shadow_map->unbind();

    // Now update the light shader with the view/projection matrix used for
    // shadow rendering, as well as the shadow texture.
    const Mat4x4 view_projection = projection | view;
    m_light->set_param("light_view_projection", view_projection);

    // Do any post processing on the shadow map
    if (m_blur_horiz)
      m_shadow_map = fbo_cache->apply_pp_effect(m_shadow_map, m_blur_horiz);
    if (m_blur_vert)
      m_shadow_map = fbo_cache->apply_pp_effect(m_shadow_map, m_blur_vert);

    // Generate mipmaps if necessary
    m_shadow_map->generate_mipmaps();

    // Set our light to use this buffer (use metadata)
    SH::ShTexture2D<SH::ShAttrib4f> shadow_tex(m_shadow_map->width(),
                                               m_shadow_map->height());
    shadow_tex.meta("opengl:texid",
                    to_string(m_shadow_map->gl_texture_name()));
    m_light->set_texture("light_shadow_map", shadow_tex);
  }
}
//-----------------------------------------------------------------------------
void SGSpaVSMSpotLight::invalidate_dependencies()
{
  // Need to free our reference?
  if (dependency_calls <= 1) {
    dependency_calls = 0;
    GlFBOCache::instance()->done_with(m_shadow_map);
    m_shadow_map = 0;
  }
  else
    --dependency_calls;
}
//-----------------------------------------------------------------------------
void SGSpaVSMSpotLight::blur(int size, float sigma)
{
  if (size > 0) {
    // Create new shaders for the blurring
    m_blur_horiz = new PPGaussianBlur(0, size, sigma);
    m_blur_vert  = new PPGaussianBlur(1, size, sigma);
    m_blur_horiz->shader()->verify_shader_prepared();
    m_blur_vert->shader()->verify_shader_prepared();
  }
  else {
    m_blur_horiz = 0;
    m_blur_vert = 0;
  }
}
//-----------------------------------------------------------------------------
} // namespace Sheen
