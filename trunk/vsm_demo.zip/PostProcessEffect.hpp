#ifndef POSTPROCESSEFFECT_HPP
#define POSTPROCESSEFFECT_HPP
//-----------------------------------------------------------------------------
#include <sheen/NamedParamsShader.hpp>

namespace Sheen {
//-----------------------------------------------------------------------------
class PostProcessShader;
typedef SH::ShPointer<PostProcessShader> PostProcessShaderPtr;
typedef SH::ShPointer<const PostProcessShader> PostProcessShaderCPtr;

/** Base class for all post processing shaders.
 * Inheritting classes need only provide a fragment shader, in addition to
 * defining a texture parameter called "source_texture". We let derived classes
 * define their own texture types so that they can operate on different types
 * of data depending on the specific effect.
 */
class PostProcessShader : public NamedParamsShader
{
private:
  /// Set containing the vertex and fragment shaders
  SH::ShProgramSetPtr m_shaders;

  /// Vertex shader used for this post processing effect
  /// Private since it is generalized. Non-static since we align outputs with
  /// fragment shader inputs by name.
  SH::ShProgram m_vertex_shader;

protected:
  /// Fragment shader used for this post processing effect
  SH::ShProgram m_fragment_shader;

  virtual void prepare_shader();

  PostProcessShader(const Args &args);

public:
  /// Bind the shader program to the current render device.
  virtual void bind();
};
//-----------------------------------------------------------------------------
class PostProcessEffect;
typedef SH::ShPointer<PostProcessEffect> PostProcessEffectPtr;
typedef SH::ShPointer<const PostProcessEffect> PostProcessEffectCPtr;

class PostProcessEffect : public NamedParams
{
private:
  PostProcessShaderPtr m_shader;

protected:
  // Construct a new post processing effect using the given pointer.
  PostProcessEffect(const PostProcessShaderPtr &shader)
    : m_shader(shader)
  {}

public:
  /// Return the contained shader for this effect.
  PostProcessShaderPtr  shader()       { return m_shader; }
  /// Return the contained shader for this effect.
  PostProcessShaderCPtr shader() const { return m_shader; }
};
//-----------------------------------------------------------------------------
// Template class used to aid in inheritting from PostProcessEffect.
template <class ShaderType>
class PostProcessEffectTemplate : public PostProcessEffect
{
protected:
  typedef typename ShaderType::Args ShaderArgs;

  /// Optional constructor for passing through an already-created shader.
  PostProcessEffectTemplate(const PostProcessShaderPtr &shader)
    : PostProcessEffect(shader)
  {}
  
public:
  /// Construct a new effect, creating a new shader if necessary.
  PostProcessEffectTemplate(const ShaderArgs &args)
    : PostProcessEffect(PostProcessShaderPtr(SingletonFactory::instance()->
                        SingletonFactory::template create_from_args
                        <ShaderType>(args)))
  {}
};
//-----------------------------------------------------------------------------
} // namespace Sheen
#endif
