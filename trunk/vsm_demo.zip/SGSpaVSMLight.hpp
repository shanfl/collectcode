#ifndef SGSPAVSMSPOTLIGHT_HPP
#define SGSPAVSMSPOTLIGHT_HPP
//-----------------------------------------------------------------------------
#include <sheen/SGSpaSpotLight.hpp>
#include "VSMSpotLight.hpp"
#include "VSMDepth.hpp"
#include "PPGaussianBlur.hpp"

namespace Sheen {
//-----------------------------------------------------------------------------
class SGSpaVSMSpotLight;
typedef SH::ShPointer<SGSpaVSMSpotLight> SGSpaVSMSpotLightPtr;
typedef SH::ShPointer<const SGSpaVSMSpotLight> SGSpaVSMSpotLightCPtr;

/** Spatial directional light node interface implemented with a
 * VSMSpotLight instance.
 */
class SGSpaVSMSpotLight
  : public SGCreatableNode<SGSpaVSMSpotLight, SGSpaSpotLight>
{
private:
  typedef SGCreatableNode<SGSpaVSMSpotLight, SGSpaSpotLight> Super;

  VSMSpotLightPtr m_light;
  FwMaterialPtr m_vsm_depth;
  int dependency_calls;  
  GlFramebufferObjectPtr m_shadow_map;
  PostProcessEffectPtr m_blur_horiz;
  PostProcessEffectPtr m_blur_vert;

protected:
  void virtual_set_light(VSMSpotLight *light)
  {
    Super::virtual_set_light(light);
    m_light = light;
  }

public:
  SGSpaVSMSpotLight(const std::string &name, bool shader_bilinear,
                    bool use_neg);

  explicit SGSpaVSMSpotLight(const SGSpaVSMSpotLight &n);

  SHEEN_SGCREATABLENODE_CLONE(SGSpaVSMSpotLight);

  virtual ~SGSpaVSMSpotLight();

  /// Generate shadow map
  virtual void generate_dependencies(SceneGraph *scene,
                                     const FwRenderer *renderer);
  /// Invalidate shadow map
  virtual void invalidate_dependencies();

  /// Set the gaussian blur setting on the VSM.
  /// Setting size to 0 disables blurring.
  /// NOTE: Should really only be done at startup since if the size/sigma
  /// setting is unique, it will mean a shader compilation!
  void blur(int size, float sigma);

  virtual VSMSpotLight * light() const { return m_light.object(); }
};
//-----------------------------------------------------------------------------
} // namespace Sheen
#endif
