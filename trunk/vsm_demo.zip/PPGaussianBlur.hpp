#ifndef PPGAUSSIANBLUR_HPP
#define PPGAUSSIANBLUR_HPP
//-----------------------------------------------------------------------------
#include "PostProcessEffect.hpp"

namespace Sheen {
//-----------------------------------------------------------------------------
class PPGaussianBlurShader : public PostProcessShader
{
public:
  struct Args : public PostProcessShader::Args
  {
    typedef PostProcessShader::Args Super;
    int blur_dimension;     ///< Dimension to blur in (0=horiz, 1=vert, etc)
    int kernel_size;        ///< (Half) size of the kernel in pixels
    float sigma;            ///< StdDev of distribution in pixels. >0

    Args(int dimension = 0, int kernel = 5, float sig = 3)
      : blur_dimension(dimension), kernel_size(kernel), sigma(sig)
    {}
    bool operator<(const Args &p) const
    {
      // Call the parent
      if      (static_cast<const Super &>(*this) < p    ) return true;
      else if (static_cast<const Super &>(p)     < *this) return false;
      if      (  blur_dimension < p.blur_dimension)       return true;
      else if (p.blur_dimension <   blur_dimension)       return false;
      if      (  kernel_size < p.kernel_size)             return true;
      else if (p.kernel_size <   kernel_size)             return false;
      if      (  sigma < p.sigma)                         return true;
      //else if (p.sigma <   sigma)                         return false;
      return false;
    }
  };

protected:
  // Uniforms
  SH::ShWrapClampToEdge< SH::ShInterp<1, SH::ShNoMIPFilter<
    SH::ShTexture2D<SH::ShColor4f> > > > source_texture;

public:
  PPGaussianBlurShader(const Args &args)
    : PostProcessShader(args)
  {
    // Uniform names
    SH_NAME(source_texture);
    
    // Evaluate the gaussian function over this kernel size
    float *weights = new float[args.kernel_size + 1];
    float total = 0.0f;
    for (int i = 0; i <= args.kernel_size; ++i) {
      weights[i] = std::exp(-static_cast<float>(i*i) /
                            (2.0f * args.sigma * args.sigma)) / args.sigma;
      total += (i == 0 ? 1 : 2) * weights[i];
    }
    // Normalize the distribution function
    for (int i = 0; i <= args.kernel_size; ++i)
      weights[i] /= total;

    // Define the fragment shader to do the blurring
    m_fragment_shader = SH_BEGIN_FRAGMENT_PROGRAM {
      SH::ShInputPosition4f SH_DECL(position);
      SH::ShInputTexCoord2f SH_DECL(tex_coord);
      SH::ShOutputAttrib4f  SH_DECL(output);

      // Initialization
      output = source_texture(tex_coord) * weights[0];
      SH::ShTexCoord2f offset_tex_coord = tex_coord;      
      SH::ShAttrib1f dim_size_inv =
        1.0f / source_texture.size()(args.blur_dimension);

      // Loop over the kernel width
      for (int i = 1; i <= args.kernel_size; ++i) {
        SH::ShAttrib1f offset = static_cast<float>(i) * dim_size_inv;

        // Negative side
        offset_tex_coord(args.blur_dimension) =
          tex_coord(args.blur_dimension) - offset;
        SH::ShAttrib4f contrib = source_texture(offset_tex_coord);

        // Positive side
        offset_tex_coord(args.blur_dimension) =
          tex_coord(args.blur_dimension) + offset;
        contrib += source_texture(offset_tex_coord);

        // Add weighted contribution
        output = mad(contrib, weights[i], output);
      }
    } SH_END_PROGRAM;

    delete [] weights;
  }
};
//-----------------------------------------------------------------------------
class PPGaussianBlur : public PostProcessEffectTemplate<PPGaussianBlurShader>
{
private:
  typedef PostProcessEffectTemplate<PPGaussianBlurShader> Super;

public:
  PPGaussianBlur(int blur_dimension = 0, int kernel_size = 5, float sigma = 3)
    : Super(ShaderArgs(blur_dimension, kernel_size, sigma))
  {
    set_param("filter_size", Attrib1f(0.001f));
  }
};
//-----------------------------------------------------------------------------
} // namespace Sheen
#endif
