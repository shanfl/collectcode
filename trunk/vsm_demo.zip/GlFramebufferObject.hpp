#ifndef GLFRAMEBUFFEROBJECT_HPP
#define GLFRAMEBUFFEROBJECT_HPP
//-----------------------------------------------------------------------------
#include <sheen/sheen.hpp>
#include <sheen/OpenGL.hpp>
#include <sheen/GlUtil.hpp>

namespace Sheen {
//-----------------------------------------------------------------------------
/** A structure of FBO settings for convenience and comparison.
 * TODO: Some of these settings (ex. filtering) can be changed easily without
 * creating a whole new FBO. They should be ignored in the comparison and
 * mutable in the FBO object.
 */
struct GlFBOSettings
{
  int width;
  int height;  
  bool mip_mapped;
  bool depth_buffer;
  GLenum gl_texture_target;
  GLenum gl_texture_format;
  GLenum gl_texture_min_filter;
  GLenum gl_texture_mag_filter;
  float gl_texture_max_aniso;

  GlFBOSettings()
  {
    width = 256;
    height = 256;
    mip_mapped = false;
    depth_buffer = true;
    gl_texture_target = GL_TEXTURE_2D;
    gl_texture_format = GL_RGBA8;
    gl_texture_min_filter = GL_LINEAR;
    gl_texture_mag_filter = GL_LINEAR;
    gl_texture_max_aniso = 1.0f;
  }

  bool operator<(const GlFBOSettings &s) const
  {
    return (std::memcmp(this, &s, sizeof(GlFBOSettings)) < 0);
  }
};
//-----------------------------------------------------------------------------
class GlFramebufferObject;
typedef SH::ShPointer<GlFramebufferObject> GlFramebufferObjectPtr;
typedef SH::ShPointer<const GlFramebufferObject> GlFramebufferObjectCPtr;

/** Implements an OpenGL FBO.
 */
class GlFramebufferObject : public SH::ShRefCountable
{
private:
  GlFBOSettings m_settings;
  GLuint m_gl_framebuffer;
  GLuint m_gl_texture;
  GLuint m_gl_depth_renderbuffer;
  int m_mip_levels;

  /// Initialize the FBO with the given parameters
  void init(const GlFBOSettings &settings);

public:
  /// Create a new framebuffer with the given parameters
  GlFramebufferObject(const GlFBOSettings &settings)
  {
     init(settings);
  }

  /// Creates a new framebuffer with the same characteristics as f.
  GlFramebufferObject(const GlFramebufferObject &f)
  {
     init(f.m_settings);
  }

  virtual ~GlFramebufferObject();

  /// Virtual copy constructor
  virtual GlFramebufferObject * clone() const
  {
    return new GlFramebufferObject(*this);
  }

  /// Get the settings for this FBO
  const GlFBOSettings & settings() const { return m_settings; }

  /// Get the OpenGL name of the texture
  GLenum gl_texture_name() const { return m_gl_texture; }
  /// Get the target of the OpenGL texture
  GLenum gl_texture_target() const { return m_settings.gl_texture_target; }

  /// Get the width of this FBO
  int width() const { return m_settings.width; }
  /// Get the height of this FBO
  int height() const { return m_settings.height; }

  /// Generate a mipmap chain for the FBO (only works in mipmaps are enabled)
  /// Should not be called when the buffer is bound.
  void generate_mipmaps()
  {
    if (m_mip_levels > 1) {
      glBindTexture(gl_texture_target(), m_gl_texture);
      glGenerateMipmapEXT(gl_texture_target());
      glBindTexture(gl_texture_target(), 0);
    }
  }

  /// Bind the framebuffer object
  void bind()
  {
    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, m_gl_framebuffer);
    gl_check_for_fbo_error();
  }

  /// Unbind the framebuffer object
  void unbind()
  {
    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
    gl_check_for_fbo_error();
  }
};
//-----------------------------------------------------------------------------
} // namespace Sheen
#endif
