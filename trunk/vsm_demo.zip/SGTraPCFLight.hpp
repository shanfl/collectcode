#ifndef SGTRAFWPCFSPOTLIGHT_HPP
#define SGTRAFWPCFSPOTLIGHT_HPP
//-----------------------------------------------------------------------------
#include <sheen/SGTraLight.hpp>
#include "SGSpaPCFLight.hpp"

namespace Sheen {
//-----------------------------------------------------------------------------
class SGTraPCFSpotLight;
typedef SH::ShPointer<SGTraPCFSpotLight> SGTraPCFSpotLightPtr;
typedef SH::ShPointer<const SGTraPCFSpotLight> SGTraPCFSpotLightCPtr;

/** A transformed forward renderer spot light node.
 */
class SGTraPCFSpotLight
  : public SGCreatableNode<SGTraPCFSpotLight, SGTraSpotLight>
{
private:
  typedef SGCreatableNode<SGTraPCFSpotLight, SGTraSpotLight> Super;

  SGSpaPCFSpotLightPtr m_spa_node;

protected:
  void virtual_set_node(SGSpaPCFSpotLight *node)
  {
    Super::virtual_set_node(node);
    m_spa_node = node;
  }

public:
  SGTraPCFSpotLight(const std::string &name, bool bilinear = false,
                    int kernel_size = 1, float sigma = 3)
    : Super(name)
  {
    virtual_set_node(new SGSpaPCFSpotLight(name, bilinear, kernel_size, sigma));
  }

  /// Copy constructor
  explicit SGTraPCFSpotLight(const SGTraPCFSpotLight &n)
    : Super(n)
  {
    virtual_set_node(n.m_spa_node->clone());
  }

  SHEEN_SGCREATABLENODE_CLONE(SGTraPCFSpotLight);

  virtual PCFSpotLight * light() const { return m_spa_node->light(); }
};
//-----------------------------------------------------------------------------
} // namespace Sheen
#endif
