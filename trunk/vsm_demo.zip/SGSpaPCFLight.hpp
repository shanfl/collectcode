#ifndef SGSPAFWPCFSPOTLIGHT_HPP
#define SGSPAFWPCFSPOTLIGHT_HPP
//-----------------------------------------------------------------------------
#include <sheen/SGSpaSpotLight.hpp>
#include "PCFSpotLight.hpp"
#include "PCFDepth.hpp"

namespace Sheen {
//-----------------------------------------------------------------------------
class SGSpaPCFSpotLight;
typedef SH::ShPointer<SGSpaPCFSpotLight> SGSpaPCFSpotLightPtr;
typedef SH::ShPointer<const SGSpaPCFSpotLight> SGSpaPCFSpotLightCPtr;

/** Spatial directional light node interface implemented with a
 * PCFSpotLight instance.
 */
class SGSpaPCFSpotLight
  : public SGCreatableNode<SGSpaPCFSpotLight, SGSpaSpotLight>
{
private:
  typedef SGCreatableNode<SGSpaPCFSpotLight, SGSpaSpotLight> Super;

  PCFSpotLightPtr m_light;
  FwMaterialPtr m_pcf_depth;
  int dependency_calls;
  GlFramebufferObjectPtr m_shadow_map;

protected:
  void virtual_set_light(PCFSpotLight *light)
  {
    Super::virtual_set_light(light);
    m_light = light;
  }

public:
  SGSpaPCFSpotLight(const std::string &name, bool bilinear = false,
                    int kernel_size = 1, float sigma = 3);

  explicit SGSpaPCFSpotLight(const SGSpaPCFSpotLight &n);

  SHEEN_SGCREATABLENODE_CLONE(SGSpaPCFSpotLight);

  virtual ~SGSpaPCFSpotLight();

  /// Generate shadow map
  virtual void generate_dependencies(SceneGraph *scene,
                                     const FwRenderer *renderer);
  /// Invalidate shadow map
  virtual void invalidate_dependencies();

  virtual PCFSpotLight * light() const { return m_light.object(); }
};
//-----------------------------------------------------------------------------
} // namespace Sheen
#endif
