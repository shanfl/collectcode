#ifndef FWVSMDEPTH_HPP
#define FWVSMDEPTH_HPP
//-----------------------------------------------------------------------------
#include <sheen/FwUnlitMaterial.hpp>

namespace Sheen {
//-----------------------------------------------------------------------------
class VSMDepthShader : public FwUnlitShader
{
public:
  // Few "messing around" constants
  // Could be arguments eventually, but they are convenient to change here
  static const bool distribute_outputs = true;
  static const int  distribute_factor  = 32;

  struct Args : public FwUnlitShader::Args
  {
    typedef FwUnlitShader::Args Super;
    bool use_neg;                 ///< Scale to [-1, 1] instead of [0, 1]

    Args(bool neg = false)
      : use_neg(neg) {}
    bool operator<(const Args &p) const
    {
      // Call the parent
      if      (static_cast<const Super &>(*this) < p    ) return true;
      else if (static_cast<const Super &>(p)     < *this) return false;
      if      (  use_neg < p.use_neg)                     return true;
      //else if (p.use_neg <   use_neg)                     return false;
      return false;
    }
  };
  
private:
  SH::ShAttrib2f light_atten;

public:
  VSMDepthShader(const Args &args);
};
//-----------------------------------------------------------------------------
class VSMDepth : public FwUnlitMaterial<VSMDepthShader>
{
private:
  typedef FwUnlitMaterial<VSMDepthShader> Super;

public:
  VSMDepth(bool use_neg)
    : Super(ShaderArgs(use_neg))
  {}

  SHEEN_FWMATERIAL_CLONE(VSMDepth);
};
//-----------------------------------------------------------------------------
} // namespace Sheen
#endif
