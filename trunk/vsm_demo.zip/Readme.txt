Variance Shadow Maps Demo
Copyright 2006 by Andrew Lauritzen and William Donnelly


DISCLAIMER
==========

This demo and source is provided AS-IS and we take no responsability for anything that it does to your computer, your life, etc. Use it at your own risk.


DEMO
====

The demo requires a Radeon 9500, Geforce 6 or newer with the latest drivers (must have EXT_framebuffer_object support for one).

Simply execute the "Demo.exe" application from the root directory. A few useful keys:

Left drag     - Camera orbit
Right drag    - Camera pan
Middle drag   - Camera zoom
Escape        - Exit
Space         - Toggle pause light animation
F5            - Use percentage closer filtering
F6            - Use bilinear percentage closer filtering
F7            - Use variance shadow maps with 16-bit fixed point buffer
F8            - Use variance shadow maps with 16-bit floating point buffer
F9            - Use variance shadow maps with 32-bit floating point buffer
S             - Step through shadow maps sizes
0 to 5        - Set blur size (0 = disable)
L             - Toggle second light


SOURCE
======

The source is not particularly easy to compile. It requires Visual C++ 2005 (Express is fine) and several external libraries. Most notably:

1) Sh GPU Metaprogramming Language
(compiled using 0.8 release - SVN at http://svn.libsh.org/sh/branches/0.8/)

2) Sheen scene graph library
(compiled using r3569 from SVN at http://svn.libsh.org/game/trunk/)

3) SDL
(compiled using version 1.2 available from http://www.libsdl.org/)

4) GLEW
(available from http://glew.sourceforge.net/)


NOTES
=====

1) The PCF implementation exhibits some "peter panning": the biasing is overly aggressive to avoid self-shadowing when used with large blur kernels. This is better handled by biasing based on the z-slope of the polygon. However I didn't have time to make this work well on both ATI and NVIDIA (derivatives seem to differ somewhat) so it is disabled for now.

2) The bilinear PCF implementation is non-optimal in that it takes redundant texture samples. Some of this will probably get filtered out by the shader compiler, but it could be done better at the high level. In any case, it was convenient for implementation time reasons to use the readily-available bilinear_lookup function.

3) Some stuff is somewhat "hacked"... remember that this is primarily a RESEARCH impelementation so there's extra stuff and non-optimal code for our research purposes. It is useful as a reference, but by no means should the code be directly lifted into a production environment.


Enjoy!