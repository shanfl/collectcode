//-----------------------------------------------------------------------------
#include "VSMDepth.hpp"
using namespace SH;

namespace Sheen {
//-----------------------------------------------------------------------------
VSMDepthShader::VSMDepthShader(const Args &args)
  : FwUnlitShader(args)
{
  SH_NAME(light_atten);
  
  m_vertex_shader = SH_BEGIN_VERTEX_PROGRAM {
    ShInputPosition4f  SH_DECL(position);
    ShOutputPosition4f SH_DECL(position_screen);
    ShOutputVector3f   SH_DECL(light_vec);

    position_screen = (world_view_projection_matrix() | position);
    light_vec       = (world_view_matrix()            | position)(0,1,2);
  } SH_END_PROGRAM;

  m_fragment_shader = SH_BEGIN_FRAGMENT_PROGRAM {
    ShInputPosition4f  SH_DECL(position_screen);
    ShInputVector3f    SH_DECL(light_vec);
    ShOutputAttrib4f   SH_DECL(output);

    // Compute the distance (can use any metric)
    ShAttrib1f x = length(light_vec);

    if (args.use_neg) {
      // Rescale to [-1, 1]
      x = mad(2.0f / light_atten(1), x, ShConstAttrib1f(-1.0f));
    } else {
      // Rescale to [0, 1]
      x /= light_atten(1);
    }

    // Compute the moments
    ShAttrib2f moments;
    moments(0) = x;
    moments(1) = x * x;

    if (distribute_outputs) {
      // Rescale and distribute precision to four components
      output(2,3) = frac(moments * distribute_factor);
      output(0,1) = moments - (output(2,3) / distribute_factor);
    } else {
      output = join(moments(0,1), ShConstAttrib2f(0, 0));
    }
  } SH_END_PROGRAM;
}
//-----------------------------------------------------------------------------
} // namespace Sheen
