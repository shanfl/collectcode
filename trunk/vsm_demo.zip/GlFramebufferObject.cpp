//-----------------------------------------------------------------------------
#include "GlFramebufferObject.hpp"

namespace Sheen {
//-----------------------------------------------------------------------------
void GlFramebufferObject::init(const GlFBOSettings &settings)
{
  m_settings = settings;

  // Generate GL names for our potential items
  glGenFramebuffersEXT(1, &m_gl_framebuffer);
  glGenTextures(1, &m_gl_texture);
  glGenRenderbuffersEXT(1, &m_gl_depth_renderbuffer);

  glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, m_gl_framebuffer);

  // Work out the number of mip-map levels
  m_mip_levels = 1;
  if (settings.mip_mapped) {
    int d = (std::max(settings.width, settings.height)) >> 1;
    while (d > 0) {
      ++m_mip_levels;
      d >>= 1;
    }
  }

  // Initialize the texture (color buffer)
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(gl_texture_target(), m_gl_texture);
  glTexImage2D(gl_texture_target(), 0, settings.gl_texture_format,
    width(), height(), 0, GL_RGBA, GL_FLOAT, NULL);
  // Initialize all of the MIP levels
  if (m_mip_levels > 1)
    glGenerateMipmapEXT(gl_texture_target());
  

  // Set filter and wrap modes
  glBindTexture(gl_texture_target(), m_gl_texture);
  glTexParameteri(gl_texture_target(), GL_TEXTURE_MIN_FILTER, m_settings.gl_texture_min_filter);
  glTexParameteri(gl_texture_target(), GL_TEXTURE_MAG_FILTER, m_settings.gl_texture_mag_filter);
  glTexParameterf(gl_texture_target(), GL_TEXTURE_MAX_ANISOTROPY_EXT, m_settings.gl_texture_max_aniso);

  glBindTexture(gl_texture_target(), 0);

  // Attach it to the FBO
  // Last param is MIP level... there may be a need to handle this when we're
  // using MIP-mapping, but I'm not totally sure. If we're generating MIP-maps
  // on the fly, this should be fine I think. See above as well.
  glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT, 
                            gl_texture_target(), m_gl_texture, 0);

  // Create a depth buffer if requested
  if (settings.depth_buffer) {
    glBindRenderbufferEXT(GL_RENDERBUFFER_EXT, m_gl_depth_renderbuffer);
    glRenderbufferStorageEXT(GL_RENDERBUFFER_EXT, GL_DEPTH_COMPONENT24,
                             width(), height());
    glFramebufferRenderbufferEXT(GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT, 
                                 GL_RENDERBUFFER_EXT, m_gl_depth_renderbuffer);
  }

  // Make sure that it all worked.
  gl_check_for_fbo_error();
  
  // Unbind the framebuffer and put it back to the default window system
  glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
}
//-----------------------------------------------------------------------------
GlFramebufferObject::~GlFramebufferObject()
{
  // Cleanup
  glDeleteRenderbuffersEXT(1, &m_gl_depth_renderbuffer);
  glDeleteTextures(1, &m_gl_texture);
  glDeleteFramebuffersEXT(1, &m_gl_framebuffer);
}
//-----------------------------------------------------------------------------
} // namespace Sheen
