//-----------------------------------------------------------------------------
#include "VSM.hpp"
#include <iostream>
#include <sstream>
using namespace std;
//-----------------------------------------------------------------------------
int main(int argc, char *argv[])
{
  bool error = true;

  // Default settings
  bool windowed = true;
  int width = 1024;
  int height = 768;
  int FSAA_samples = 4;
  bool vsync = false;

  // Read command-line parameters
  for (int i = 1; i < argc; ++i) {
    const std::string arg = argv[i];
    // Set framebuffer resolution
    if ((arg == "-res" || arg == "-dim") && (argc - i) > 2) {
      istringstream w(argv[++i]);
      istringstream h(argv[++i]);
      w >> width;
      h >> height;
    }
    // Set the fsaa level
    else if (arg == "-fsaa" && (argc - i) > 1) {
      istringstream f(argv[++i]);
      f >> FSAA_samples;
    }
    // Run in windowed mode
    else if (arg == "-win") {
      windowed = true;
    }
    // Run in full-screen mode
    else if (arg == "-full") {
      windowed = false;
    }
    // Run with vsync (only affects Win32 in full-screen mode)
    else if (arg == "-vsync") {
      vsync = true;
    }
  }
  
  VSMApp *app = new VSMApp();
  try {
    app->init();
    app->set_video_mode(windowed, width, height, FSAA_samples, vsync);

    // Display the video mode that ended up being chosen
    cout << "\"" << app->caption() << "\": " << app->width() << "x"
         << app->height() << " " << app->FSAA_samples() << "xFSAA";
    if (app->windowed()) cout << ", Windowed";
    if (app->vsync()) cout << ", VSync";
    cout << endl;
    
    app->run();
    error = false;
  }
  // Anything from std::exception
  catch (const std::exception &e) { cerr << e.what() << endl; }
  // Anything else
  //catch (...) { cerr << "Unhandled exception!" << endl; }

  // Cleanup
  delete app;
  app = 0;

  return 0;
}
//-----------------------------------------------------------------------------
