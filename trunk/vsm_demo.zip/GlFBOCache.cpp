//-----------------------------------------------------------------------------
#include "GlFBOCache.hpp"

namespace Sheen {
//-----------------------------------------------------------------------------
GlFBOCacheBase::GlFBOCacheBase()
{
  // Post-processing setup
  m_screen_aligned_quad = create_screen_aligned_quad();
}
//-----------------------------------------------------------------------------
GlFramebufferObjectPtr GlFBOCacheBase::get(const GlFBOSettings &settings)
{
  // See if we already have one available
  FBOMap::iterator i = m_fbo_map.find(settings);
  if (i != m_fbo_map.end()) {
    GlFramebufferObjectPtr fbo = i->second;
    m_fbo_map.erase(i);   // No longer available for use
    return fbo;
  }
  else                    // None available, create a new one
    return new GlFramebufferObject(settings);
}
//-----------------------------------------------------------------------------
void GlFBOCacheBase::done_with(const GlFramebufferObjectPtr &fbo)
{
  if (fbo)
    m_fbo_map.insert(FBOMap::value_type(fbo->settings(), fbo));
}
//-----------------------------------------------------------------------------
GlFramebufferObjectPtr
GlFBOCacheBase::apply_pp_effect(const GlFramebufferObjectPtr &fbo,
                                const PostProcessEffectPtr &effect)
{
  // Grab a new buffer of the same type
  GlFramebufferObjectPtr new_fbo = get(fbo->settings());

  // Setup the effect to use the current buffer as the source  
  m_source_texture.size(fbo->width(), fbo->height());
  m_source_texture.meta("opengl:texid", to_string(fbo->gl_texture_name()));
  effect->set_texture("source_texture", m_source_texture);
  effect->shader()->update_parameters(effect);
  effect->shader()->bind();

  // Render our screen aligned quad into the new buffer
  render_device->viewport(Attrib4i(0, 0, fbo->width(), fbo->height()));
  new_fbo->bind();
  render_device->clear(RB_COLOR | RB_DEPTH, Attrib4f(0, 0, 0, 0), 1.0);
  m_screen_aligned_quad->render_chunk();
  new_fbo->unbind();

  // Return the old buffer to the cache and return the new
  done_with(fbo);
  return new_fbo;
}
//-----------------------------------------------------------------------------
} // namespace Sheen
