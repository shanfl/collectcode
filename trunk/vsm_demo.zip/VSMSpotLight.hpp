#ifndef VSMSPOTLIGHT_HPP
#define VSMSPOTLIGHT_HPP
//-----------------------------------------------------------------------------
#include <sheen/SpotLight.hpp>
#include "GlFBOCache.hpp"

namespace Sheen {
//-----------------------------------------------------------------------------
/** A spot light shader with variance shadow mapping.
 */
class VSMSpotLightShader : public SpotLightShader
{
public:
  struct Args : public SpotLightShader::Args
  {
    typedef SpotLightShader::Args Super;
    bool shader_bilinear;         ///< Emulate bilinear filtering in shader
    bool use_neg;                 ///< Scale to [-1, 1] instead of [0, 1]

    Args(bool bilinear = false, bool neg = false)
      : shader_bilinear(bilinear), use_neg(neg) {}
    bool operator<(const Args &p) const
    {
      // Call the parent
      if      (static_cast<const Super &>(*this) < p    ) return true;
      else if (static_cast<const Super &>(p)     < *this) return false;
      if      (  shader_bilinear < p.shader_bilinear)     return true;
      else if (p.shader_bilinear <   shader_bilinear)     return false;
      if      (  use_neg < p.use_neg)                     return true;
      //else if (p.use_neg <   use_neg)                     return false;
      return false;
    }
  };

protected:
  // Uniform parameters
  SH::ShMatrix4x4f light_view_projection;
  SH::ShAttrib1f light_vsm_epsilon;

  SH::ShWrapClampToEdge< SH::ShInterp<1, SH::ShMIPFilter<
    SH::ShTexture2D<SH::ShAttrib4f> > > > light_shadow_map;

public:
  VSMSpotLightShader(const Args &args, const InstanceIDType &instance_id);
};
//-----------------------------------------------------------------------------
class VSMSpotLight;
typedef SH::ShPointer<VSMSpotLight> VSMSpotLightPtr;
typedef SH::ShPointer<const VSMSpotLight> VSMSpotLightCPtr;

class VSMSpotLight
  : public LightTemplate<VSMSpotLightShader, SpotLight>
{
private:
  typedef LightTemplate<VSMSpotLightShader, SpotLight> Super;
  
  /// The requested settings for the shadow map
  /// TODO: Abstract to API-independent representation
  GlFBOSettings m_shadow_map_settings;

  void defaults();

protected:
  /// Passthrough an already-constructed shader
  /// Optional constructor for passing through an already-created shader.
  VSMSpotLight(const LightShaderPtr &shader)
    : Super(shader)
  {
    defaults();
  }

public:
  /// Create a new point light and associated shader.
  VSMSpotLight(bool shader_bilinear = false, bool use_neg = false)
    : Super(ShaderArgs(shader_bilinear, use_neg))
  {
    defaults();
  }

  SHEEN_FWLIGHT_CLONE(VSMSpotLight);

  /// Get the requested shadow map settings, read/write.
  GlFBOSettings & shadow_map_settings()
  {
    return m_shadow_map_settings;
  }
  /// Get the requested shadow map settings, read only.
  const GlFBOSettings & shadow_map_settings() const
  {
    return m_shadow_map_settings;
  }
};
//-----------------------------------------------------------------------------
} // namespace Sheen
#endif
