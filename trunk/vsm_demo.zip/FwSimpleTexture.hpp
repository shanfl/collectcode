#ifndef FWSIMPLETEXTURE_HPP
#define FWSIMPLETEXTURE_HPP
//-----------------------------------------------------------------------------
#include <sheen/FwUnlitMaterial.hpp>

namespace Sheen {
//-----------------------------------------------------------------------------
class FwSimpleTextureShader : public FwUnlitShader
{
protected:
  // Uniform parameters
  SH::ShWrapRepeat< SH::ShInterp<1, SH::ShMIPFilter<
    SH::ShTexture2D<SH::ShColor4fub> > > > texture;

public:
  FwSimpleTextureShader(const Args &args)
    : FwUnlitShader(args)
  {
    // Uniform parameter names
    SH_NAME(texture);

    m_vertex_shader = SH_BEGIN_VERTEX_PROGRAM {
      SH::ShInOutPosition4f SH_DECL(position);
      SH::ShInOutTexCoord2f SH_DECL(tex_coord);
      position = world_view_projection_matrix() | position;
    } SH_END_PROGRAM;

    m_fragment_shader = SH_BEGIN_FRAGMENT_PROGRAM {
      SH::ShInputPosition4f SH_DECL(position);
      SH::ShInputTexCoord2f SH_DECL(tex_coord);
      SH::ShOutputColor3f   SH_DECL(fragment_color);
      fragment_color = texture(tex_coord)(0,1,2);
    } SH_END_PROGRAM;
  }
};
//-----------------------------------------------------------------------------
class FwSimpleTexture : public FwUnlitMaterial<FwSimpleTextureShader>
{
private:
  typedef FwUnlitMaterial<FwSimpleTextureShader> Super;

public:
  FwSimpleTexture()
    : Super(ShaderArgs())
  {}
};
//-----------------------------------------------------------------------------
} // namespace Sheen
#endif
