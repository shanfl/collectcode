
#include "CLog.h"

/////////////////////////////////////////////////////////////////
//Construction: No args, default name Log.wri				   //
/////////////////////////////////////////////////////////////////

CLog::CLog()
{
	fstream *handler;
	char line[1024];

	handler = new fstream;

	handler->open("Log.wri",ios::binary | ios::out | ios::trunc);

	if(handler->fail()) {
		handler->close();
		return;
	}

	//Clean garbage
	memset(line,0,1024);
	sprintf(line,"Log File Log.wri");

	sprintf((char*)m_LogName, "%s", "Log.wri");

	handler->write((char *) line,strlen(line));

	handler->close();	

	AddTimeDate();
	AddOSVersion();

}

/////////////////////////////////////////////////////////////////
//Construction: creates a Log with the provided name.		   //
/////////////////////////////////////////////////////////////////

CLog::CLog(char *LogName)
{
	fstream *handler;
	char line[1024];

	handler = new fstream;

	handler->open(LogName,ios::binary | ios::out | ios::trunc);

	if(handler->fail()) {
		handler->close();
		return;
	}

	char *logname = &m_LogName[0];

	sprintf(logname, "%s", LogName); 
	
	//Clean garbage
	memset(line,0,1024);
	sprintf(line,"Log File: %s \n", LogName);

	handler->write((char *) line,strlen(line));

	handler->close();	

	AddTimeDate();
	AddOSVersion();
}

void CLog::AddTimeDate(void)
{
	char dbuffer[9];
	char tbuffer[9];

	_strdate(dbuffer);
	_strtime(tbuffer);

	AddString("Date: %s, Time: %s \n",dbuffer,tbuffer);
}

/////////////////////////////////////////////////////////////////
//AddString: writes formatted text							   //
/////////////////////////////////////////////////////////////////

void CLog::AddString(char *error, ...)
{
	va_list argptr;
	char	text[1024];
	char	text2[1024];

	va_start (argptr,error);
	vsprintf (text, error, argptr);
	va_end (argptr);

	sprintf(text2,"%s", text);

	AddLine(text2);
	OutputDebugString(text2);
}

/////////////////////////////////////////////////////////////////
//AddLine: writes unformatted text							   //
/////////////////////////////////////////////////////////////////

void CLog::AddLine(char *text)
{
	fstream *handler;
	char line[1024];

	handler = new fstream;

	handler->open((char *) m_LogName,ios::binary | ios::out | ios::app);

	if(handler->fail()) {
		handler->close();
		return;
	}

	memset(line,0,1024);
	sprintf(line,"%s",text);

	handler->write((char *) line,strlen(line));

	handler->close();
}

//////////////////////////////////////////////////////////////
//AddOSVersion: Get's OS version info						//
//////////////////////////////////////////////////////////////
void CLog::AddOSVersion()
{
	OSVERSIONINFO OSinfo;
	OSinfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);

	GetVersionEx(&OSinfo);
	
	BOOL bIsWindows98orLater = (OSinfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS) &&
								( (OSinfo.dwMajorVersion > 4) ||
								( (OSinfo.dwMajorVersion == 4) && (OSinfo.dwMinorVersion > 0) ) );
	
	AddLine("\n");
	AddLine("---OS Version Info---\n");
	AddString("Version: %u.%u.%u\n", OSinfo.dwMajorVersion,
			  OSinfo.dwMinorVersion, OSinfo.dwBuildNumber & 0xFFFF);
	if (strlen(&OSinfo.szCSDVersion[0]) > 1)
		AddString("Additional info: %s\n", OSinfo.szCSDVersion);
	else
		AddLine("Additional info: -none-\n");
	
	switch(OSinfo.dwPlatformId)
	{
		case VER_PLATFORM_WIN32s:
			AddLine("Win32s on Windows 3.1 detected.\n");
			break;
		case VER_PLATFORM_WIN32_WINDOWS:
			if (bIsWindows98orLater)
				AddLine("Windows 98 or later detected.\n");
			else
				if (LOWORD(OSinfo.dwBuildNumber) > 1080)
					AddLine("Windows 95 OSR2 detected.\n");
				else 
					AddLine("Windows 95 detected.\n");
			break;
		case VER_PLATFORM_WIN32_NT:
			AddLine("Windows NT detected.\n");
		break;
	}

	AddLine("---End OS Version Info---\n");
}

//////////////////////////////////////////////////////////////
//AddMemoryStatus: Get's OS version info					//
//////////////////////////////////////////////////////////////
void CLog::AddMemorySatus(void)
{
	MEMORYSTATUS memstat;
	memstat.dwLength = sizeof(MEMORYSTATUS);

	GlobalMemoryStatus(&memstat);

	AddLine("\n---Memory Stat---\n");
	AddString("Total Physical Memory: %.02f MB.\n", memstat.dwTotalPhys/1048576.f);
	AddString("Available Physical Memory:  %.02f MB.\n", memstat.dwAvailPhys/1048576.f);
	AddString("Total Virtual Memory: %u MB.\n", memstat.dwTotalVirtual/1048576);
	AddString("Available Virtual Memory:  %u MB.\n", memstat.dwAvailVirtual/1048576);
	AddLine("---End Memory Stat---\n\n");
}


