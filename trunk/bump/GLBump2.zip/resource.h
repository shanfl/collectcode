//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GL_Bump.rc
//
#define IDC_MYICON                      2
#define IDD_GL_FRAMEWORK_DIALOG         102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_GL_FRAMEWORK                107
#define IDI_SMALL                       108
#define IDC_GL_FRAMEWORK                109
#define IDR_MAINFRAME                   128
#define IDD_CONFIG                      130
#define IDB_BITMAP1                     132
#define IDC_RESOLUTION                  1001
#define IDC_SHOWFRAMERATE               1006
#define IDC_TITLE                       1016
#define IDM_FULLSCREEN                  32771
#define IDM_CONFIG                      32772
#define ID_HEIGHTMAP                    32773
#define ID_TEXTURE                      32774
#define ID_ALL                          32775
#define ID_USEMULTITEXTURE              32776
#define ID_3PASS                        32776
#define ID_2PASS                        32777
#define ID_1PASS                        32778
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
