#ifndef __CLOG_H_CUERVO_
#define __CLOG_H_CUERVO_

#include <windows.h>
#include <memory.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>

#include <time.h>
#include <fstream.h>
#include <ios.h>


class CLog
{
	public:
		CLog();						//Construction
		CLog(char* LogName);		//Construction
		~CLog() {};					//Destruction

	public:
		void AddString(char *error, ...);
		void AddLine(char *text);
		void AddTimeDate(void);
		void AddOSVersion(void);
		void AddMemorySatus(void);

	private:
		char m_LogName[20];
};

#endif //__CLOG_H_CUERVO_