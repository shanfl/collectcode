#ifndef __GL_CUERVO_BUMP_DEMO_H__
#define __GL_CUERVO_BUMP_DEMO_H__

#define WIN32_LEAN_AND_MEAN	

// Windows Header Files:
#include <windows.h>

// C RunTime Header Files
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include <string.h>

#include <mmsystem.h>	//For timeGetTime()

//math header
#include <math.h>

// OpenGL Headers
#include <GL\gl.h>
#include <GL\glu.h>

//#include "stdafx.h"
#include "glext.h"
#include "resource.h"
#include "CGL_Dib.h"
#include "CLog.h"
#include "AuxMath.h"
#include "CCam.h"




#endif //__GL_CUERVO_BUMP_DEMO_H__