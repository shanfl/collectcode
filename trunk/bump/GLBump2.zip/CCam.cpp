/*************************************************************
* CCam.cpp: CCam class implementation.						 *
*															 *		
*			    ----- Camera by Cuervo  ----				 *	
*	           Copyright Diego A. T�rtara 1999				 *	
*				(diego_tartara@ciudad.com.ar)			     *
*														     *
*************************************************************/

#include "CCam.h"
#include <GL\gl.h>
#include <GL\glu.h>

/******************************
*	Constructor				  *
******************************/

CCam::CCam()
{
	Reset();
}

/******************************************************
* LookAt: From where it is to point					  *
******************************************************/
void CCam::LookAt(const vect &point)
{
	//if target is locked get out
	if (IsTargetLocked())
		return;
	
	/*-------------------------------------------------------
	To define a unique position/rotation aiming at point, we 
	need to define vector plus a Z rotation (remember 
	quaternions?). We can do it by maintaining the acual Z
	rotation or by an arbitrary one
	--------------------------------------------------------*/
	//I'll use the World Y as vWorldUp as yaw is undesirable here
	//when aiming. Use matrix.GetViewUp() to keep actual Z rot
	vect vWorldUp = vect(0,1,0);//matrix.GetViewUp();

	//View Up, rigth and normal for the new orthonormal base
	vect Vup, Vright, Vnormal;
	
	//the normal vector (camera z) must point 
	//now in target-position direction
	vect campos = GetPos();
	Vnormal = campos - point;
	
	float length = Mod(Vnormal);
	
	/*------------------------------------------------------
	If the distance between camera and point is too small
	get out as float is not that presice.
	-------------------------------------------------------*/
	if (length < EPS)
		return;
	
	//normalize it
	Vnormal /= length;

	//Get VRight as Cross product of vWorldUp and Vnormal
	Vright = VectXProd(vWorldUp ,Vnormal);

	length = Mod(Vright);

	/*-----------------------------------------------------
	we must control that vWorldUp is not aligned with the
	view direction. If so use arbitrary vector as vWorldUp
	------------------------------------------------------*/
	if (length < EPS)
	{
		//Use Y = (0,1,0) as vWorldUp first
		vWorldUp.Set(0,1,0);
		Vright = VectXProd(vWorldUp, Vnormal);
		length = Mod(Vright);
		//check again. If still aligned use another
		if (length < EPS)
		{
			//Use Z = (0,0,1) as vWorldUp
			vWorldUp.Set(0,0,1);
			Vright = VectXProd(vWorldUp, Vnormal);
			length = Mod(Vright);
			//still doesn't pass (I think not possible.. but)
			if (length < EPS) return;
		}
	}

	//normalize it
	Vright/=length;

	//Camera's Vup is orthogonal to Vright and Vnormal.
	Vup = VectXProd(Vnormal,Vright);

	mat4 newbasis;
	newbasis.SetId();

	//Load the rotation
	newbasis.SetViewNormal(Vnormal);
	newbasis.SetViewRight(Vright);
	newbasis.SetViewUp(Vup);

	//Load the translation, in cam new coordinates
	newbasis.m1[3][0] = -VectDotProd(campos, Vright);
	newbasis.m1[3][1] = -VectDotProd(campos, Vup);
	newbasis.m1[3][2] = -VectDotProd(campos, Vnormal);

	matrix = newbasis;

	/*--------------------------------------------------------
	Note: We only have a valid target after a LookAt and upto 
		  another operation makes the target invalid.
		  The difference between TargetValid and TargetLocked 
		  is that we can have an unlocked valid target, but we
		  can't have an invalid locked one
	---------------------------------------------------------*/
	target = point;
	flags |= TARGET_VALID;
}

/**********************************************************
* SetPos: Sets absolute position. After this command is   *
*		  executed the cam will be at the desired point   *
*		  no matter what. Rotation remains intact.        *
**********************************************************/
void CCam::SetPos(const vect &newpos)
{
	//check not locked position
	if (IsPosLocked())
		return;

	/*---------------------------------------------------
	Move to the desired place keeping the rotation.
	That's done placing the translation in cam coords
	----------------------------------------------------*/
	matrix.m1[3][0] = -VectDotProd(newpos, matrix.GetViewRight());
	matrix.m1[3][1] = -VectDotProd(newpos, matrix.GetViewUp());
	matrix.m1[3][2] = -VectDotProd(newpos, matrix.GetViewNormal());
	flags &= (~TARGET_VALID);
	
	/*---------------------------------------------------
	Si target was lockeado, aim again.
	----------------------------------------------------*/
	if (IsTargetLocked())
	{
		//unlock and relock, or LookAt woun't accept the operation
		flags &= (~TARGET_LOCKED);
		LookAt(target);
		flags |= TARGET_LOCKED;
	}
}

/**********************************************************
* GetPos: Returns cam position in World coordinates.	  *
**********************************************************/
vect CCam::GetPos(void)
{

	/*--------------------------------------------------- 
	We must translate the translation contained in matrix
	to world coordinates. Calc the inverse matrix and 
	return translation part.
	----------------------------------------------------*/
	vect pos;
	pos.x = -(matrix.m1[3][0] * matrix.m1[0][0] + matrix.m1[3][1] * matrix.m1[0][1] + matrix.m1[3][2] * matrix.m1[0][2]);
	pos.y = -(matrix.m1[3][0] * matrix.m1[1][0] + matrix.m1[3][1] * matrix.m1[1][1] + matrix.m1[3][2] * matrix.m1[1][2]);
	pos.z = -(matrix.m1[3][0] * matrix.m1[2][0] + matrix.m1[3][1] * matrix.m1[2][1] + matrix.m1[3][2] * matrix.m1[2][2]);

	return pos;
}

/**********************************************************
* GetYaw: Returns rotation about Z Axis.				  *
**********************************************************/
float CCam::GetYaw(void)
{
	return (float)(atan2(matrix[4], matrix[5]));
}

/**********************************************************
* GetRoll: Returns rotation about X axis.			      *
**********************************************************/
float CCam::GetRoll(void)
{
	return (float)(atan2(matrix[9], matrix[10]));
}

/**********************************************************
* GetPitch: Returns rotation about Y axis.				  *
**********************************************************/
float CCam::GetPitch(void)
{
	return (float)(-atan2(matrix[8], matrix[10]));
}


/***********************************************************
* GetTarget: Returns target if there is a valid one.	   *
*		     If not returns a point in the line of sight   *
*		     1.0 in front of the cam.					   *
*		     This is so to make it a more usefull function *
*			 If you need to know if it's a real target ask *
*            IsTargetValid()							   *
***********************************************************/
vect CCam::GetTarget()
{ 
	if (IsTargetValid()) 
		return target;	
	else 
		return (GetPos() - matrix.GetViewNormal());
}

/**********************************************************
* Apply: Call to upload the transformation.				  *	
*        Will invalidate the previous MODELVIEW matrix	  *	
**********************************************************/
void CCam::Apply()
{
	/*-------------------------------------------------------
	In debug mode, we draw the cam uploading it's own inverse
	transform, and look from an arbitrary fixed point
	------------------------------------------------------*/
	if (IsDebugOn())	{
		//modify glulookat according to the desired eye/target
		//placement (target could be the Cam position for chasing)
		glLoadIdentity();
		gluLookAt(5, 5, 5, 0, 0, 0, 0, 1, 0);
		//It's really bad to push all these attribs, but
		//we are in debug mode anyway
		glPushAttrib(GL_CURRENT_BIT | GL_ENABLE_BIT | 
						 GL_LINE_BIT | GL_POINT_BIT |
						 GL_LIGHTING_BIT );
		glPushMatrix();
			mat4 invmatrix = matrix;
			invmatrix.Invert();
			glMultMatrixf(&invmatrix.m[0]);
			DrawDebug();
		glPopMatrix();
		DrawAim();
		glPopAttrib();
	}
	else
	{
		glLoadMatrixf(&matrix.m[0]);
	}
}

/*******************************************************
* RotateX: Rotates the cam about it's own X axis	   *
*******************************************************/
void CCam::RotateX(const float rad)
{
	float sine = (float)sin(rad);
	float cosine = (float)cos(rad);
	
	mat4 rotX;
	rotX.SetId();

	rotX.m1[1][1] = cosine;
	rotX.m1[1][2] = -sine;
	rotX.m1[2][1] = sine;
	rotX.m1[2][2] = cosine;

	if (IsTargetLocked())	{
		/*-----------------------------------------------------
		If the target is locked rotate around 'it'. Create a 
		matrix that translate the cam to the target position,
		rotates the desired angle, and go backwards again
		------------------------------------------------------*/

		//get dist. to target
		float DistToTarget = Mod(GetPos() - target);
		/* Just need to add: */
		rotX.m1[3][1] = DistToTarget * sine;
		rotX.m1[3][2] = DistToTarget * (cosine - 1);
		MultMatrix(rotX);
		return;
	}

	MultMatrix(rotX);

	//We rotated.. invalidate target
	flags &= (~TARGET_VALID);
}

/*******************************************************
* RotateY: Rotates the cam about it's own X axis	   *
*******************************************************/
void CCam::RotateY(const float rad)
{
	float sine = (float)sin(rad);
	float cosine = (float)cos(rad);

	mat4 rotY;
	rotY.SetId();

	rotY.m1[0][0] = cosine;
	rotY.m1[0][2] = sine;
	rotY.m1[2][0] = -sine;
	rotY.m1[2][2] = cosine;
	
	if (IsTargetLocked())	{
		/*-----------------------------------------------------
		Same as RotateX if target is locked
		------------------------------------------------------*/
		float DistToTarget = Mod(GetPos() - target);
		rotY.m1[3][0] = -DistToTarget * sine;
		rotY.m1[3][2] = DistToTarget * (cosine - 1);
		MultMatrix(rotY);
		return;
	}

	//Not locked.. accum transformationt
	MultMatrix(rotY);

	//invalidate target
	flags &= (~TARGET_VALID);
}

/*******************************************************
* RotateZ: Rotates the cam about it's own X axis	   *
*		   The cam's Z axis is the sight dorection	   *
*******************************************************/
void CCam::RotateZ(const float rad)
{
	/*----------------------------------------------------
	Rotate around Z doesn't invalidate the target as the
	cam "looks" through this direction
	----------------------------------------------------*/
	float sine = (float)sin(rad);
	float cosine = (float)cos(rad);
	
	mat4 rotZ;
	rotZ.SetId();

	rotZ.m1[0][0] = cosine;
	rotZ.m1[0][1] = -sine;
	rotZ.m1[1][0] = sine;
	rotZ.m1[1][1] = cosine;

	MultMatrix(rotZ);
}

/**********************************************************
* Rotate: Rotates the cam about any given arbitrary axis  *
**********************************************************/
void CCam::Rotate(const vect & vdir, const float rad)
{
	float Sin = (float)sin(rad);
	float Cos = (float)cos(rad);

	//normalize v 
	vect v = Normalize(vdir);

	mat4 rotm;

	//rotation part
	rotm.m1[0][0] = ( v.x * v.x ) * ( 1.0f - Cos ) + Cos;
    rotm.m1[0][1] = ( v.x * v.y ) * ( 1.0f - Cos ) - (v.z * Sin);
    rotm.m1[0][2] = ( v.x * v.z ) * ( 1.0f - Cos ) + (v.y * Sin);

    rotm.m1[1][0] = ( v.y * v.x ) * ( 1.0f - Cos ) + (v.z * Sin);
    rotm.m1[1][1] = ( v.y * v.y ) * ( 1.0f - Cos ) + Cos;
    rotm.m1[1][2] = ( v.y * v.z ) * ( 1.0f - Cos ) - (v.x * Sin);

    rotm.m1[2][0] = ( v.z * v.x ) * ( 1.0f - Cos ) - (v.y * Sin);
    rotm.m1[2][1] = ( v.z * v.y ) * ( 1.0f - Cos ) + (v.x * Sin);
    rotm.m1[2][2] = ( v.z * v.z ) * ( 1.0f - Cos ) + Cos;
    
	//check if target is locked
	if (IsTargetLocked())	{
		/*-----------------------------------------------------
		Target is locked. Operate as in RotateX
		------------------------------------------------------*/
		float DistToTarget = Mod(GetPos() - target);
		rotm.m1[3][0] = DistToTarget * rotm.m1[2][0];
		rotm.m1[3][1] = DistToTarget * rotm.m1[2][1];
		rotm.m1[3][2] = DistToTarget * (rotm.m1[2][2]-1);
		MultMatrix(rotm);
		return;
	}

	//no estaba lockeado
    rotm.m1[0][3] = rotm.m1[1][3] = rotm.m1[2][3] = 0.0f;
	rotm.m1[3][0] = rotm.m1[3][1] = rotm.m1[3][2] = 0.0f;
	rotm.m1[3][3] = 1.0f;

	MultMatrix(rotm);

	flags &= (~TARGET_VALID);
}

/*************************************************************
* RotateWX: Rotates around "WORLD" X, traslated over the cam * 
*************************************************************/
void CCam::RotateWX(const float rad)
{
	//The trick is to transformWorld X to cam coordinates
	//and use Rotate.
	vect newx(matrix.m1[0][0], matrix.m1[0][1], matrix.m1[0][2]);
	Rotate(newx, rad);

}

/*************************************************************
* RotateWY: Rotates around "WORLD" Y, traslated over the cam *
*************************************************************/
void CCam::RotateWY(const float rad)
{	
	//The trick is to transformWorld Y to cam coordinates
	//and use Rotate.
	vect newy(matrix.m1[1][0], matrix.m1[1][1], matrix.m1[1][2]);
	Rotate(newy, rad);
}

/*************************************************************
* RotateWZ: Rotates around "WORLD" Z, traslated over the cam *
*************************************************************/
void CCam::RotateWZ(const float rad)
{
	//The trick is to transformWorld Z to cam coordinates
	//and use Rotate.
	vect newz(matrix.m1[2][0], matrix.m1[2][1], matrix.m1[2][2]);
	Rotate(newz, rad);

}

/*******************************************************
* Translate: Translation, same as glTranslatef		   *
*******************************************************/
void CCam::Translate(const vect &v)
{
	if (IsPosLocked())
		return;

	mat4 transmat;
	transmat.SetId();
	transmat.m1[3][0] = -v.x;
	transmat.m1[3][1] = -v.y;
	transmat.m1[3][2] = -v.z;

	//if target is locked, aim again after transformation
	if (IsTargetLocked())
	{
		//Upload the transformation
		MultMatrix(transmat);
		//unlock and relock to make LookAt accept the operation
		flags &= (~TARGET_LOCKED);
		LookAt(target);
		flags |= TARGET_LOCKED;
		return;
	}

	//if we don't have a valid target we can return
	if (!IsTargetValid()) {
		//Upload the transformation
		MultMatrix(transmat);
		return;
	}
		
	//we have one. Check to see if we lost it.
	//We didn't loose it if we translated troguh z and
	//also didn't pass over.
	if (v.x != 0 || v.y != 0)	{
		//Upload the transformation
		MultMatrix(transmat);
		flags &= (~TARGET_VALID);
		return;
	}
	
	//if we got here is because we translated trough z
	//get previous position, and translate  
	vect prevpos = GetPos();
	MultMatrix(transmat);
	//get translated position
	vect campos = GetPos();

	//compare distance to target before and after transform to
	//know if we passed over the target.
	if (ModSquared(target-prevpos) < ModSquared(campos-prevpos))
		flags &= (~TARGET_VALID);
}


/*******************************************************
* Forward: Moves the cam ahead or back parallel to XZ  *
*		   world plane... quake style				   *
*******************************************************/
void CCam::Forward(const float dist)
{
	if (dist == 0)
		return;

	vect ahead(matrix.GetViewNormal());
	vect up(matrix.GetViewUp());
	vect right(matrix.GetViewRight());

	vect XZproj(ahead.x, 0, ahead.z);

	float length = Mod(XZproj);

	if (length < EPS)
		//if we are looking exactly 90� ahead or above 
		//ViewNormal parallel to Wolrd Y avoid division
		//by zero
		return;
	
	//make module = distance to move the given distance
	XZproj *= dist/length;

	//proyect on ViewNormal and ViewUp
	float nproj = VectDotProd(XZproj, ahead);
	float uproj = VectDotProd(XZproj, up);
	float rproj = VectDotProd(XZproj, right);

	Translate(vect(rproj, uproj, nproj));
}

/*******************************************************
* Strafe: Moves the cam right or left parallel to XZ   *
*		  world plane... quake like					   *
*******************************************************/
void CCam::Strafe(const float dist)
{
	if (dist == 0)
		return;

	vect ahead(matrix.GetViewNormal());
	vect up(matrix.GetViewUp());
	vect right(matrix.GetViewRight());

	vect XZproj(right.x, 0, right.z);
	
	float length = Mod(XZproj);

	if (length < EPS)
		//right vector is aligned with World Y, avoid 
		//division by zero
		return;


	XZproj *= dist/length;

	//proyect on ViewRight, ViewNormal y ViewUp
	float nproj = VectDotProd(XZproj, ahead);
	float uproj = VectDotProd(XZproj, up);
	float rproj = VectDotProd(XZproj, right);

	Translate(vect(rproj, uproj, nproj));
}

/********************************************************
* Up: Muves the cam up or down, parallel al to World Y  *
*	  jump/crouch quake like							*
********************************************************/
void CCam::Up(const float dist)
{
	vect up(matrix.m1[1][0], matrix.m1[1][1], matrix.m1[1][2]);

	//As the base is orthonormal, no need to normalize

	//make module = dist (if dist<0 goes down)
	up*=dist;

	Translate(up);
}

/********************************************************
* UploadInvertRot: To position things facing the camera *
*				   Translate the thing and the call this*
*				   function to calc the proper rotation	*
*				   Usefull for volumetric explosions    *
*				   or other billboarded stuff			*
********************************************************/
void CCam::UploadInvertRot()
{
	mat4 matinv;

	//invert matrix
	matinv.m1[0][0] = matrix.m1[0][0];
	matinv.m1[1][1] = matrix.m1[1][1];
	matinv.m1[2][2] = matrix.m1[2][2];
	matinv.m1[0][1] = matrix.m1[1][0];
	matinv.m1[0][2] = matrix.m1[2][0];
	matinv.m1[1][2] = matrix.m1[2][1];
	matinv.m1[1][0] = matrix.m1[0][1];
	matinv.m1[2][0] = matrix.m1[0][2];
	matinv.m1[2][1] = matrix.m1[1][2];
	matinv.m1[3][0] = matinv.m1[3][1] = matinv.m1[3][2] = 0;
	matinv.m1[0][3] = matinv.m1[1][3] = matinv.m1[2][3] = 0;
	matinv.m1[3][3] = 1;

	glMultMatrixf((float*)&matinv);
}

/*****************************************************************
* LockTarget: Locks/Unlocks the target							 *
*****************************************************************/
void CCam::LockTarget(BOOL lock)
{
	if (lock && IsTargetValid())
		flags |= TARGET_LOCKED;
	else
		flags &= (~TARGET_LOCKED);
}

/*****************************************************************
* LockPos: Locks/Unlocks camera position						 *
*****************************************************************/
void CCam::LockPos(BOOL lock)
{
	if (lock)
		flags |= POS_LOCKED;
	else
		flags &= (~POS_LOCKED);
}

/*************************************************************
* Reset: Resets all. Even flags, they are mandatory.		 *
*************************************************************/
void CCam::Reset(void)
{
	//Deja de estar lockeada la rotaci�n o el target
	//El target deja de ser v�lido
	flags = 0;
	matrix.SetId();
}

/*********************************************************
* ResetRot: Sets null rotation. Keeps position			 *
*********************************************************/
void CCam::ResetRot(void)
{
	vect pos = GetPos();

	matrix.m1[3][0] = -pos.x;
	matrix.m1[3][1] = -pos.y;
	matrix.m1[3][2] = -pos.z;

	matrix.m1[0][0] = matrix.m1[1][1] = matrix.m1[2][2] = 1.0f;
	matrix.m1[1][0] = matrix.m1[0][1] = 0.f;
	matrix.m1[2][0] = matrix.m1[0][2] = 0.f;
	matrix.m1[2][1] = matrix.m1[1][2] = 0.f;

	//target invalidated
	flags &= ~(TARGET_VALID | TARGET_LOCKED);
}

/*************************************************************
* ResetPos: Returns camera to origin keeping rotation		 *
*************************************************************/
void CCam::ResetPos(void)
{
	/*-------------------------------------------------
	If we have a locked target aim again
	-------------------------------------------------*/
	if (IsTargetLocked())
	{
		matrix.SetId();
		flags &= (~TARGET_LOCKED);
		LookAt(target);
		flags |= TARGET_LOCKED;
	}
	else
	{
		matrix.m1[3][0] = matrix.m1[3][1] = matrix.m1[3][2] = 0.0f;
		//I've lost it if there was one
		flags &= (~TARGET_VALID);
	}
}

/*************************************************************
* ResetYaw: Resets the rotation bout Z						 *
*************************************************************/
void CCam::ResetYaw()
{
	/*-------------------------------------------------------
	Code very similat to lookat
	--------------------------------------------------------*/
	vect vWorldUp(0,1,0);

	//View Up, rigth and normal
	vect Vup, Vright, Vnormal;
	
	//Save cam's position
	vect campos = GetPos();
	//normal vector (cam's Z) remains the same
	Vnormal = matrix.GetViewNormal();
	
	Vright = VectXProd(vWorldUp ,Vnormal);

	float length = Vright.GetModSquared();

	/*-----------------------------------------------------
	chack vWorldUp not aligned with world Y
	------------------------------------------------------*/
	if (length < EPS) 
	{
		//Use Z = (0,0,1) as vWorldUp
		vWorldUp.Set(0,0,1);
		Vright = VectXProd(vWorldUp, Vnormal);
		length = Mod(Vright);
		//check again, if it doesn't pass use X=(1,0,0) as vWorldUp
		if (length < EPS)
		{
			vWorldUp.Set(1,0,0);
			Vright = VectXProd(vWorldUp, Vnormal);
			length = Mod(Vright);
			if (length < EPS) return;
		}
	}

	//normalize it
	Vright/=(float)sqrt(length);

	//cam's Vup is normal to both Vright and Vnormal.
	Vup = VectXProd(Vnormal,Vright);

	mat4 newbasis;
	newbasis.SetId();

	//Upload rotation to matrix
	newbasis.SetViewNormal(Vnormal);
	newbasis.SetViewRight(Vright);
	newbasis.SetViewUp(Vup);

	//Upload translation (cam position) in new cam coordinates
	newbasis.m1[3][0] = -VectDotProd(campos, Vright);
	newbasis.m1[3][1] = -VectDotProd(campos, Vup);
	newbasis.m1[3][2] = -VectDotProd(campos, Vnormal);

	matrix = newbasis;

	/*--------------------------------------------------------
	Nota: target remains valid (if it was) as it's a rotation
		  aroun Z.
	---------------------------------------------------------*/
}

/*****************************************************************
* DrawDebug: Used in debug mode. Draws the cam and it's axis	 *
*															     *
*****************************************************************/
void CCam::DrawDebug()
{
	/* axis */
    glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_CULL_FACE);
	glLineWidth(2.0f);

	//axis lenght
	const float length = 0.7f;
	//draw them
	glBegin (GL_LINES);
		//X Axis
		glColor3f (0.4f, 0.0, 0.0);
		glVertex3f (-length, 0.0, 0.0);
		glColor3f (1.0f, 0.0, 0.0);
		glVertex3f (length, 0.0, 0.0);
		//Y Axis
		glColor3f (0.0, 0.4f, 0.0);
		glVertex3f (0.0, -length, 0.0);
		glColor3f (0.0, 1.0f, 0.0);
		glVertex3f (0.0, length, 0.0);
		//Z Axis
		glColor3f (0.0, 0.0, 0.4f);
		glVertex3f (0.0, 0.0, -length);
		glColor3f (0.0, 0.0, 1.0f);
		glVertex3f (0.0, 0.0, length);
	glEnd ();

	glColor3f (0.1f, 0.1f, 0.1f);

	//body and lens measures
	const float x = 0.2f, y = 0.2f, z = 0.4f;
	const float diam = 0.2f;
	
	const GLfloat CamMat[]   = { 0.7f, 0.7f, 0.7f, 1.0f};

	glEnable(GL_LIGHTING);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, CamMat);
	//lens
	glPushMatrix();
		glTranslatef(0.0f,0.0f,-2*diam-z/2);
		GLUquadricObj *MyQuad;
		MyQuad = gluNewQuadric();
		gluCylinder(MyQuad,  diam, diam*0.5f, 2*diam, 15, 1);
		gluDeleteQuadric(MyQuad);
	glPopMatrix();

	//Body
	glBegin(GL_QUADS);

		//front face
		glNormal3f(0.0f,0.0f,1.0f);
		glVertex3f(x,y,z);
		glVertex3f(-x,y,z);
		glVertex3f(-x,-y,z);
		glVertex3f(x,-y,z);
	
		//right face
		glNormal3f(1.0f,0.0f,0.0f);
		glVertex3f(x,y,z);
		glVertex3f(x,-y,z);
		glVertex3f(x,-y,-z);
		glVertex3f(x,y,-z);
 
		//back face
		glNormal3f(0.0f,0.0f,-1.0f);
		glVertex3f(-x,y,-z);
		glVertex3f(x,y,-z);
		glVertex3f(x,-y,-z);
		glVertex3f(-x,-y,-z);

		//left face
		glNormal3f(-1.0f,0.0f,0.0f);
		glVertex3f(-x,y,-z);
		glVertex3f(-x,-y,-z);
		glVertex3f(-x,-y,z);
		glVertex3f(-x,y,z);
		
		//bottom
		glNormal3f(0.0f,-1.0f,0.0f);
		glVertex3f(-x,-y,z);
		glVertex3f(-x,-y,-z);
		glVertex3f(x,-y,-z);
		glVertex3f(x,-y,z);
		
		//top
		glNormal3f(0.0f,1.0f,0.0f);
		glVertex3f(x,y,z);
		glVertex3f(x,y,-z);
		glVertex3f(-x,y,-z);
		glVertex3f(-x,y,z);
		
	glEnd();

}



/*****************************************************************
* DrawAim: Used in debug mode. Draws a line from cam to target   *
*		   if there is one valid.								 *															     *
*****************************************************************/
void CCam::DrawAim()
{
	/*----------------------------------------------------
	Also mark the target with a point
	-----------------------------------------------------*/
	glDisable(GL_LIGHTING);
	if (IsTargetValid())	{
		//line from position to target
		vect campos = GetPos();
		glBegin (GL_LINES);
			glColor3f (1.0f, 1.0, 0.0);
			glVertex3f (target.x, target.y, target.z);
			glVertex3f (campos.x, campos.y, campos.z);	
		glEnd ();
		//the target
		glPointSize(7.0f);
		glBegin (GL_POINTS);
			glVertex3f (target.x, target.y, target.z);
		glEnd ();
	
	}
}

/*****************************************************************
* MultMatrix: Accumulates transformations in cam's matrix.		 *
*															     *
*****************************************************************/
void CCam::MultMatrix(const mat4 &a)
{
	mat4 b = matrix;
	
#define M(A, i, j)	 (A).m1[(i)][(j)]

	//rotation
	M(matrix,0,0) = M(b,0,0)*M(a,0,0) + M(b,0,1)*M(a,1,0) + M(b,0,2)*M(a,2,0);
	M(matrix,0,1) = M(b,0,0)*M(a,0,1) + M(b,0,1)*M(a,1,1) + M(b,0,2)*M(a,2,1);
	M(matrix,0,2) = M(b,0,0)*M(a,0,2) + M(b,0,1)*M(a,1,2) + M(b,0,2)*M(a,2,2);
	
	M(matrix,1,0) = M(b,1,0)*M(a,0,0) + M(b,1,1)*M(a,1,0) + M(b,1,2)*M(a,2,0);
	M(matrix,1,1) = M(b,1,0)*M(a,0,1) + M(b,1,1)*M(a,1,1) + M(b,1,2)*M(a,2,1);
	M(matrix,1,2) = M(b,1,0)*M(a,0,2) + M(b,1,1)*M(a,1,2) + M(b,1,2)*M(a,2,2);

	M(matrix,2,0) = M(b,2,0)*M(a,0,0) + M(b,2,1)*M(a,1,0) + M(b,2,2)*M(a,2,0);
	M(matrix,2,1) = M(b,2,0)*M(a,0,1) + M(b,2,1)*M(a,1,1) + M(b,2,2)*M(a,2,1);
	M(matrix,2,2) = M(b,2,0)*M(a,0,2) + M(b,2,1)*M(a,1,2) + M(b,2,2)*M(a,2,2);

	//translation
	M(matrix,3,0) = M(b,3,0)*M(a,0,0) + M(b,3,1)*M(a,1,0) + M(b,3,2)*M(a,2,0) + M(a,3,0);
	M(matrix,3,1) = M(b,3,0)*M(a,0,1) + M(b,3,1)*M(a,1,1) + M(b,3,2)*M(a,2,1) + M(a,3,1);
	M(matrix,3,2) = M(b,3,0)*M(a,0,2) + M(b,3,1)*M(a,1,2) + M(b,3,2)*M(a,2,2) + M(a,3,2);

#undef M
}




