/*-------------------------------------------------------------

GLBump.cpp: Emboss bumpmapping demo.					  

			Copyright Diego T�rtara, 1999.
			
		   -  diego_tartara@ciudad.com.ar  -

Coments: The code you should look at is at DrawMesh3Pass and 
		 DrawMesh2Pass. The first one doesn't use multitexturing
		 while the second one does. I kept them in separate 
		 functions to make the more readables.
		 Notice that this demo is implemented on a "framework"
		 of my own so there is unused functionality on it.

Known Issues: The texture should have a border or should be 
			  mapped from somewhere "inside" to avoid artifacts
			  produced by repeating it. 
			  Keep it this way to not complicate things.
			  I don't really know if the rest is really ok and
			  by the book, but looks sweet, doesn't it?
			  
Improvements: More complicated geometry.
			  Implement 1 Pass mode with no degradation
			  (anyone one this??).

Other cool stuff: 

CCam class: Really good camera class. This demo doesn't show it's 
			potential at all.

Cdib class: Loads almost any Dib except for compressed ones.
			Any bpp, paletted or not. Stop the madness about
			only 24bpp, perfectly power of two dimensions.
			Trow the name of the file and you are done.
			Plus: Screen capture to OpenGL texture for the same 
				  price.

Some others may be interesting (not for experianced people)
such a resolution switching, palette creation for RGBA in 
8bpp mode, using multitexture or the framework itself 
--------------------------------------------------------------*/

#include "GL_Bump.h"

//ARB Multitexture Extensions 
PFNGLMULTITEXCOORD1DARBPROC		glMultiTexCoord1dARB = NULL;
PFNGLMULTITEXCOORD1DVARBPROC	glMultiTexCoord1dvARB = NULL;	
PFNGLMULTITEXCOORD1FARBPROC		glMultiTexCoord1fARB = NULL;
PFNGLMULTITEXCOORD1FVARBPROC	glMultiTexCoord1fvARB = NULL;
PFNGLMULTITEXCOORD1IARBPROC		glMultiTexCoord1iARB = NULL;
PFNGLMULTITEXCOORD1IVARBPROC	glMultiTexCoord1ivARB = NULL;	
PFNGLMULTITEXCOORD1SARBPROC		glMultiTexCoord1sARB = NULL;
PFNGLMULTITEXCOORD1SVARBPROC	glMultiTexCoord1svARB = NULL;
PFNGLMULTITEXCOORD2DARBPROC		glMultiTexCoord2dARB = NULL;
PFNGLMULTITEXCOORD2DVARBPROC	glMultiTexCoord2dvARB = NULL;	
PFNGLMULTITEXCOORD2FARBPROC		glMultiTexCoord2fARB = NULL;
PFNGLMULTITEXCOORD2FVARBPROC	glMultiTexCoord2fvARB = NULL;
PFNGLMULTITEXCOORD2IARBPROC		glMultiTexCoord2iARB = NULL;
PFNGLMULTITEXCOORD2IVARBPROC	glMultiTexCoord2ivARB = NULL;
PFNGLMULTITEXCOORD2SARBPROC		glMultiTexCoord2sARB = NULL;
PFNGLMULTITEXCOORD2SVARBPROC	glMultiTexCoord2svARB = NULL;
PFNGLMULTITEXCOORD3DARBPROC		glMultiTexCoord3dARB = NULL;
PFNGLMULTITEXCOORD3DVARBPROC	glMultiTexCoord3dvARB = NULL;
PFNGLMULTITEXCOORD3FARBPROC		glMultiTexCoord3fARB = NULL;
PFNGLMULTITEXCOORD3FVARBPROC	glMultiTexCoord3fvARB = NULL;
PFNGLMULTITEXCOORD3IARBPROC		glMultiTexCoord3iARB = NULL;
PFNGLMULTITEXCOORD3IVARBPROC	glMultiTexCoord3ivARB = NULL;
PFNGLMULTITEXCOORD3SARBPROC		glMultiTexCoord3sARB = NULL;
PFNGLMULTITEXCOORD3SVARBPROC	glMultiTexCoord3svARB = NULL;
PFNGLMULTITEXCOORD4DARBPROC		glMultiTexCoord4dARB = NULL;
PFNGLMULTITEXCOORD4DVARBPROC	glMultiTexCoord4dvARB = NULL;	
PFNGLMULTITEXCOORD4FARBPROC		glMultiTexCoord4fARB = NULL;
PFNGLMULTITEXCOORD4FVARBPROC	glMultiTexCoord4fvARB = NULL;
PFNGLMULTITEXCOORD4IARBPROC		glMultiTexCoord4iARB = NULL;
PFNGLMULTITEXCOORD4IVARBPROC	glMultiTexCoord4ivARB = NULL;
PFNGLMULTITEXCOORD4SARBPROC		glMultiTexCoord4sdARB = NULL;
PFNGLMULTITEXCOORD4SVARBPROC	glMultiTexCoord4svARB = NULL;
PFNGLACTIVETEXTUREARBPROC		glActiveTextureARB = NULL;
PFNGLCLIENTACTIVETEXTUREARBPROC	glClientActiveTextureARB = NULL;	

#define MAX_LOADSTRING	100

/*Texture defines*/
#define BASETEXTURE		19
#define BUMP			20
#define INVBUMP			21
#define BASE_BUMP       22

/* enumerations for the mouse buttons */
enum {
    UP = 1, 
    DOWN, 
};

//////////////////////////////////////
// Global Variables:				//
//////////////////////////////////////
HINSTANCE hInst;						//Current instance
HWND Hwnd;								//MainWindow Handle
TCHAR szTitle[MAX_LOADSTRING];			//The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];	//The window class name
BOOL bAppActive = TRUE;					//Are we active?
BOOL bFullScreen = FALSE;				//Ruing Fullscreen?
BOOL bShouldEnd = FALSE;				//Shold we terminate?
BOOL bDebugCam = FALSE;					//Debug cam mode
BOOL bLockTarget = FALSE;				//Lock the target?
float Elapsed;							//Time between frames
int width, height;						//window size
float gRot[] = {0.0f,0.0f,0.0f};		//Global rotation
int mLState = UP;						//Mouse button state
int mRState = UP;						//Mouse button state
CLog MyLog("Bump.wri");					//The log file
CCam Cam;								//camera
BOOL hasmultitexture;					//multitexture
int method = ID_3PASS;					//1,2 or 3 passes
int bumptype = ID_ALL;					//Bump all/heightmap/base texture
vect lpos;								//light position

///////////////////////////////////////////////////////////////////
// Foward declarations of functions included in this code module //
///////////////////////////////////////////////////////////////////
ATOM				RegisterClass(HINSTANCE hInstance, BOOL fullscreen);
BOOL				InitInstance(HINSTANCE, int nCmdShow, BOOL fullscreen);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
void				Exit(void);
BOOL				AppIdle(void);
void				DoTimerStuff(void);

/////////////////////////////////////////////////////
// OpenGL related functions and variables		   //
/////////////////////////////////////////////////////
HDC			hDC = NULL;				//Client window DC 
HGLRC		hglRC = NULL;			//Opengl rendering context
HPALETTE	hPal = NULL;			//palette handle.. if needed
HPALETTE	hOldPal = NULL;			//to store old palette
int			PixelIndex = 0;			//Selected PixelIndex

BOOL		SetupPFD		(void);	//Setea el PFD y rendering context
BOOL		CreateRGBPalette(PIXELFORMATDESCRIPTOR pfd); //for 8bpp display mode
void		SetRenderStates (void);	//Sets Common GL Render States
void		InitGLLights	(void);	//Sets initial lighting
void		RenderFrame		(void);	//Render code
void		LoadTextures	(void);	//Texture Loading
void		DrawAxis		(void);	//Good debugging aid
BOOL		ChangeDisplay	(int p_width, int p_height,
							 int p_bpp);	//Switch Fullscreen/Windowed
BOOL		CheckEXT		(char* name);	//Checks if extension is present
void		linkEXT			(void);			 //Get Extensions function pointers

//Actual Render Code
void				DrawMesh3Pass(void);
void				DrawMesh2Pass(void);
void				DrawMesh1Pass(void);
void				MoveLight(void);

/*****************************************************************
*   FUNCTION: WinMain(HINSTANCE, HINSTANCE, LPSTR, int			 *																 *
*																 *	
*	PURPOSE: Program EntryPoint. Leads to the main loop          *
*																 *
*****************************************************************/

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	MyLog.AddTimeDate();
	MyLog.AddOSVersion();
	MyLog.AddMemorySatus();

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_GL_FRAMEWORK, szWindowClass, MAX_LOADSTRING);
	RegisterClass(hInstance, FALSE);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow, FALSE)) 
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_GL_FRAMEWORK);

	/*----------------------------------------------------------
	This is the main message loop. Render while there are no
	messages. Process message if anyone arrives.
	Code similar (if not equal) to D3D toolkit
	-----------------------------------------------------------*/
	for (;;)
	{
	    //Check for messages. If any, PeekMessage returns nonzero
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
	    {
			//There is at least one. If it's QUIT, get out of the loop
			if (msg.message == WM_QUIT)
				break;
			
			/*----------------------------------------------
			if it was a key press that's in the Accelerator
			table, translate it.
			Also check for Hwnd = 0 (actually no window) to 
			see if we are switching video modes.
			-----------------------------------------------*/
			if (!Hwnd || !TranslateAccelerator(Hwnd, hAccelTable, &msg))
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
		//No messages, proceed to render
		else
		{
			if (AppIdle())
				//AppIdle returned TRUE, so we are not active
				//(probably minimized or without focus)
				//Wait for a message (specially WM_ACTIVATEAPP)
				//activos. Esperemos un mensaje. WaitMessage()
				WaitMessage();
		}
	}

	//We received a WM_QUIT.. clean up
	Exit();		
	
	MyLog.AddString("Application terminated.\n");
	//ChangeDisplaySettings(NULL, 0);

	return msg.wParam;	//Bye!

}



/**********************************************************************************
//  FUNCTION: RegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage is only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.(Just as AppWizard Hello World created)
/**********************************************************************************/
ATOM RegisterClass(HINSTANCE hInstance, BOOL fullscreen)
{
	MyLog.AddString("Registering Window class..\n");

	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_GL_FRAMEWORK);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= fullscreen?NULL:(LPCSTR)IDC_GL_FRAMEWORK;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

/*****************************************************************
*   FUNCTION: InitInstance(HANDLE, int)						     *
*																 *
*   PURPOSE: Saves instance handle and creates main window		 *
*			 Also we save Main Window Handle					 *
*																 *
*   COMMENTS: Creates Main Window, Call SetupPFD(), InitLights() *
*			  and SetRenderStates().							 *
*			  Once we are out we have a fully functional OpenGL  *
*			  capable Window ready to render on it.			     *	
*****************************************************************/
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow, BOOL fullscreen)
{
 
	DWORD fullStyle = WS_POPUP|WS_MAXIMIZE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN;
	DWORD wndStyle = WS_OVERLAPPEDWINDOW|WS_CLIPSIBLINGS|WS_CLIPCHILDREN;	
	
	//prevTime = (float)timeGetTime();
   
	Hwnd = NULL;
	hInst = hInstance; // Store instance handle in our global variable

	MyLog.AddString("Creating Main Window..\n");

	width = GetSystemMetrics (SM_CXSCREEN);
    height = GetSystemMetrics (SM_CYSCREEN);

	Hwnd = CreateWindow(
		//fullscreen?WS_EX_TOPMOST:WS_EX_APPWINDOW,	//Ext style
		szWindowClass,								//class
		szTitle,									//title	
		fullscreen?fullStyle:wndStyle,				//style
		fullscreen?0:50,							//x pos
		fullscreen?0:50,							//y pos
		fullscreen?width:600,						//width
		fullscreen?height:500,						//height
		NULL,										//no parent
		NULL,										//no menu, already in class
		hInstance,									//instance
		NULL);										//no additional params

	if (!Hwnd)
	{
		MessageBox(Hwnd,"Error creating window","Error",MB_OK);
		MyLog.AddString("Error creating Main Window.\n");
		return FALSE;
	}
	
	MyLog.AddString("Main Window Created successfully, HWND: %u\n",Hwnd);
	
	int lBits = GetDeviceCaps(hDC, BITSPIXEL);
    int lWidth = GetDeviceCaps(hDC, HORZRES);
    int lHeight = GetDeviceCaps(hDC, VERTRES);
	
	MyLog.AddString("Actual Screen Settings: %ix%ix%ibpp.\n", lWidth, lHeight, lBits);
	
	ShowWindow(Hwnd, nCmdShow);

	if (fullscreen)
		SetWindowPos(Hwnd, HWND_TOPMOST, 0,0,width, height, SWP_SHOWWINDOW);

	InitGLLights();
	SetRenderStates();
	 
	//Set cam away from mesh
	Cam.SetPos(vect(0,0,10));
	
	//We need GL_EXT_texture_env_combine aside from 
	//GL_ARB_multitexture to do 2 pass method
	hasmultitexture = (CheckEXT("GL_ARB_multitexture") && 
					   CheckEXT("GL_EXT_texture_env_combine"));
	
	if (hasmultitexture)
		linkEXT();
	
	LoadTextures();

	return TRUE;
}

/****************************************************************
* Function name	: RenderFrame   				     			*
* Description	: Called once per frame, contains all           *
*				  instructions and calls to OpenGL commands     * 
* Return type	: void										    *	
* Argument      : void										    *
****************************************************************/
void RenderFrame(void)
{	

	DoTimerStuff();

	glClear(GL_COLOR_BUFFER_BIT| GL_DEPTH_BUFFER_BIT);

	glMatrixMode (GL_MODELVIEW);

	/*----------------------------
		Camera positioning
	----------------------------*/

	/*- translation -*/
	if (GetAsyncKeyState(VK_LEFT))
		Cam.Strafe(-10*Elapsed);   
	if (GetAsyncKeyState(VK_RIGHT))
		Cam.Strafe(10*Elapsed);    
	if (GetAsyncKeyState(VK_UP))
		Cam.Forward(-10*Elapsed); 
	if (GetAsyncKeyState(VK_DOWN))
		Cam.Forward(10*Elapsed);   
	if (GetAsyncKeyState(VK_INSERT))
		Cam.Up(10*Elapsed);		  
	if (GetAsyncKeyState(VK_DELETE))
		Cam.Up(-10*Elapsed);

	/*- rotation -*/
	if (gRot[1] != 0)	{
		Cam.RotateWY(DegToRad(gRot[1]));
		gRot[1] = 0;
	}
	if (gRot[0] != 0)	{
		Cam.RotateX(DegToRad(gRot[0]));
		gRot[0] = 0;
	}
	if (GetAsyncKeyState(VK_RBUTTON))
		Cam.RotateZ(2*Elapsed);
	
	//Apply transform
	Cam.Apply();
	
	
	/*----------------------------
		light positioning
	----------------------------*/
	MoveLight();
	
	/*----------------------------
		Geometry drawing
	----------------------------*/

	// Choose the method acording 
	// to user selection
	switch (method)
	{
	case ID_1PASS:
		DrawMesh1Pass();
		break;
	case ID_2PASS:
		DrawMesh2Pass();
		break;
	default:
		DrawMesh3Pass();
	}


	//Done
	SwapBuffers( hDC );
}


/******************************************************************
* Function name	: AppIdle            			     			  *
* Description	: Checks wether the App is Active or not.         *
*				  If is Active Call Render Frame and return FALSE *
*				  Else return TRUE to put the App to sleep        * 	 
* Return type	: BOOL										      *	
* Argument      : void										      *
******************************************************************/

BOOL AppIdle(void)
{
	//Go on as long as we are active

	if (bAppActive)
	{
	    //We are active, render the next frame
		RenderFrame();
		//Return FALSE 
		return FALSE;
	}
	else
	{
		//We are not active, return TRUE to wait for a message
		return TRUE;
	}
}

/******************************************************************
* Function name	: SetupPFD           			     			  *
* Description	: Creates and setup the PIXELFORMATDESCRIPTOR.    *
*				  is one, it makes it not current and delete it.  *
*				  Release the HDC and unregister Window Class.	  *    
* Return type	: BOOL										      *	
* Argument      : void										      *
******************************************************************/

BOOL SetupPFD( void ) {

	MyLog.AddString("SetupPFD() Called:\n");
	MyLog.AddLine("\n");
	MyLog.AddLine("---PFD Description---\n");
	
	PIXELFORMATDESCRIPTOR pfd;
	
	pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);
	pfd.nVersion = 1;
	pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL |
		PFD_DOUBLEBUFFER | PFD_STEREO_DONTCARE;
	pfd.iPixelType = PFD_TYPE_RGBA;		//RGBA Type
	pfd.cColorBits = 16;				//16 bpp
	pfd.cRedBits = 0;					//Color bits ignored
	pfd.cRedShift = 0;					//	"	  "		"	
	pfd.cGreenBits = 0;					//	"	  "		"
	pfd.cGreenShift = 0;				//	"	  "		"
	pfd.cBlueBits = 0;					//	"	  "		"
	pfd.cBlueShift = 0;					//	"	  "		"
	pfd.cAlphaBits = 0;					//	"	  "		"
	pfd.cAlphaShift = 0;				//No alpha bitplanes (not supp)
	pfd.cAccumBits = 0;					//No accum buffer
	pfd.cAccumRedBits = 0;				// "   "	 "
	pfd.cAccumGreenBits = 0;			// "   "	 "
	pfd.cAccumBlueBits = 0;				// "   "	 "
	pfd.cAccumAlphaBits = 0;			// "   "	 "
	pfd.cDepthBits = 16;				//16 bit Z-buffer
	pfd.cStencilBits = 0;				//No stencil needed
	pfd.cAuxBuffers = 0;				//No aux buff (not supported anyway)
	pfd.iLayerType = PFD_MAIN_PLANE;	//Main layer (No longer used)
	pfd.bReserved = 0;					//Reserved
	pfd.dwLayerMask = 0;				//Layer masks ignored
	pfd.dwVisibleMask = 0;				//	"	  "		 "
	pfd.dwDamageMask = 0;				//Ignored
		
	PixelIndex = ChoosePixelFormat(hDC,&pfd);

		
	//If PixelIndex == 0 then OpenGL couldn't find
	//an apropiate PixelIndex similar to the one we
	//asked for. Choose the default and use it.
	if(PixelIndex == 0) // We choose default
	{
		MyLog.AddString("Colud not get an appropiate Pixel Index. Using the default...\n");
		PixelIndex = 1;
		if(DescribePixelFormat(hDC,PixelIndex,
			sizeof(PIXELFORMATDESCRIPTOR),&pfd)==0)
			return FALSE;
	}

	//Set the pixel format in the HDC
	if(!SetPixelFormat(hDC,PixelIndex,&pfd))
		return FALSE;

	/*-----------------------------------
		Describe and log pixel format
	------------------------------------*/
	DescribePixelFormat(hDC, PixelIndex, sizeof(pfd), &pfd);

	MyLog.AddString("Pfd: dwFlags: %d, ",pfd.dwFlags);
	if(pfd.dwFlags & PFD_DRAW_TO_WINDOW) {
	MyLog.AddString("PFD_DRAW_TO_WINDOW, ");
	}
	if(pfd.dwFlags & PFD_DRAW_TO_BITMAP) {
	MyLog.AddString("PFD_DRAW_TO_BITMAP, ");
	}
	if(pfd.dwFlags & PFD_SUPPORT_GDI) {
	MyLog.AddString("PFD_SUPPORT_GDI, ");
	}
	if(pfd.dwFlags & PFD_SUPPORT_OPENGL) {
	MyLog.AddString("PFD_SUPPORT_OPENGL, ");
	}
	if(pfd.dwFlags & PFD_GENERIC_ACCELERATED) {
	MyLog.AddString("PFD_GENERIC_ACCELERATED, ");
	}
	if(pfd.dwFlags & PFD_GENERIC_FORMAT) {
	MyLog.AddString("PFD_GENERIC_FORMAT, ");
	}
	if(pfd.dwFlags & PFD_NEED_PALETTE) {
	MyLog.AddString("PFD_NEED_PALETTE, ");
	}
	if(pfd.dwFlags & PFD_NEED_SYSTEM_PALETTE) {
	MyLog.AddString("PFD_NEED_SYSTEM_PALETTE, ");
	}
	if(pfd.dwFlags & PFD_DOUBLEBUFFER) {
	MyLog.AddString("PFD_DOUBLEBUFFER, ");
	}
	if(pfd.dwFlags & PFD_STEREO) {
	MyLog.AddString("PFD_STEREO, ");
	}
	if(pfd.dwFlags & PFD_SWAP_LAYER_BUFFERS) {
	MyLog.AddString("PFD_SWAP_LAYER_BUFFERS, ");
	}
	if(pfd.dwFlags & PFD_DEPTH_DONTCARE) {
	MyLog.AddString("PFD_DEPTH_DONTCARE, ");
	}
	if(pfd.dwFlags & PFD_DOUBLEBUFFER_DONTCARE) {
	MyLog.AddString("PFD_DOUBLEBUFFER_DONTCARE, ");
	}
	if(pfd.dwFlags & PFD_SWAP_COPY) {
	MyLog.AddString("PFD_SWAP_COPY, ");
	}
	if(pfd.dwFlags & PFD_SWAP_EXCHANGE) {
	MyLog.AddString("PFD_SWAP_EXCHANGE, ");
	}
	MyLog.AddLine("\nPixel Type: ");
	if(pfd.iPixelType == PFD_TYPE_RGBA) {
	MyLog.AddString("PFD_TYPE_RGBA");
	}
	if(pfd.iPixelType == PFD_TYPE_COLORINDEX) {
	MyLog.AddString("PFD_TYPE_COLORINDEX");
	}
	MyLog.AddString("\n");

	MyLog.AddString("Pfd: cAccumAlphaBits: %d \n",pfd.cAccumAlphaBits);
	MyLog.AddString("Pfd: cAccumBits:      %d \n",pfd.cAccumBits);
	MyLog.AddString("Pfd: cAccumBlueBits:  %d \n",pfd.cAccumBlueBits);
	MyLog.AddString("Pfd: cAccumGreenBits: %d \n",pfd.cAccumGreenBits);
	MyLog.AddString("Pfd: cAccumRedBits:   %d \n",pfd.cAccumRedBits);
	MyLog.AddString("Pfd: cAlphaBits:      %d \n",pfd.cAlphaBits);
	MyLog.AddString("Pfd: cAlphaShift:     %d \n",pfd.cAlphaShift);
	MyLog.AddString("Pfd: cAuxBuffers:     %d \n",pfd.cAuxBuffers);
	MyLog.AddString("Pfd: cBlueBits:       %d \n",pfd.cBlueBits);
	MyLog.AddString("Pfd: cBlueShift:      %d \n",pfd.cBlueShift);
	MyLog.AddString("Pfd: cColorBits:      %d \n",pfd.cColorBits);
	MyLog.AddString("Pfd: cDepthBits:      %d \n",pfd.cDepthBits);
	MyLog.AddString("Pfd: cGreenBits:      %d \n",pfd.cGreenBits);
	MyLog.AddString("Pfd: cGreenShift:     %d \n",pfd.cGreenShift);
	MyLog.AddString("Pfd: cRedBits:        %d \n",pfd.cRedBits);
	MyLog.AddString("Pfd: cRedShift:       %d \n",pfd.cRedShift);
	MyLog.AddString("Pfd: cStencilBits:    %d \n",pfd.cStencilBits);
	//MyLog.AddString("Pfd: dwDamageMask:    %d \n",pfd.dwDamageMask);
	//MyLog.AddString("Pfd: dwLayerMask:     %d \n",pfd.dwLayerMask);
	MyLog.AddString("Pfd: dwVisibleMask:   %d \n",pfd.dwVisibleMask);
	MyLog.AddString("Pfd: iLayerType:      %d \n",pfd.iLayerType);
	//MyLog.AddString("Pfd: iPixelType:      %d \n",pfd.iPixelType);
	MyLog.AddString("Pfd: nVersion:        %d \n",pfd.nVersion);

	MyLog.AddLine("---End PFD Description---\n");
	MyLog.AddLine("\n");
	
	/*-----------------------------------------
		Create the OpenGL rendering context
	-----------------------------------------*/	
	hglRC = wglCreateContext( hDC );
 
	if ( !hglRC ) {
		MyLog.AddString("Couldn't create an HGLRC\n");
		return FALSE;
	}

	MyLog.AddString("HGLRC created: %u\n",hglRC);
	//if needed create a palette
	if (pfd.dwFlags & PFD_NEED_PALETTE)
		CreateRGBPalette(pfd);
	//Make the rendering context current 
	if ( !wglMakeCurrent( hDC, hglRC ) ) 
	{
		//Could't make it current, delete it and return FALSE
		MyLog.AddString("Couldn't asociate HGLRC %u with HDC %u\nDeleting HGLRC %u\n",hglRC, hDC, hglRC);
		wglDeleteContext( hglRC );
		hglRC = NULL;
		return FALSE;
	}

	MyLog.AddString("HGLRC %u asociated with HDC %u\n",hglRC, hDC);

	/*-----------------------------------------
		Log Driver info.
	-----------------------------------------*/	
	char *str;
	unsigned short l1;	
	char car;

	MyLog.AddLine("\n");
	MyLog.AddLine("---OpenGL Driver Info---\n");
	
	str = (char *) glGetString(GL_VENDOR);
	if(str) {
		MyLog.AddString("Vendor: %s \n",str);
	}
	str = (char *) glGetString(GL_RENDERER);
	if(str) {
		MyLog.AddString("Renderer: %s \n",str);
	}
	str = (char *) glGetString(GL_VERSION);
	if(str) {
		MyLog.AddString("Version: %s \n",str);
	}
	MyLog.AddString("Supported Extensions:\n");
	str = (char *) glGetString(GL_EXTENSIONS);
	if(str) {
		for(l1=0;l1<strlen(str);l1++) {
			car = *(str + l1);
			if(car == '\n') {
				break;
			}
			if (l1 == 0) MyLog.AddString("        ");
			if(car == ' ' && *(str + l1 + 1) != 0) {
				MyLog.AddString("\n        ");
			} else {
				MyLog.AddString("%c",car);
			}
		}
	} else {
		MyLog.AddString("-none-\n");
	}

	MyLog.AddLine("\n---End OpenGL Driver Info---\n\n");

	return TRUE;

}

/******************************************************************
* Function name	: CreatePalette          			     		  *
* Description	: Creates and setup a palette. Only called when   *
*				  the selected PFD reports PFD_NEED_PALETTE       *
* Return type	: BOOL										      *	
* Argument      : PIXELFORMATDESCRIPTOR									      *
******************************************************************/
BOOL CreateRGBPalette(PIXELFORMATDESCRIPTOR pfd)
{

	//define the system palette
	//this colors will be replaced in our LOGPALLETTE to
	//make them match the 20 system colors, altough only
	//12 need to be remaped (the rest fall ok)
	int m_defaultOverride[13] = {
    0, 3, 24, 27, 64, 67, 88, 173, 181, 236, 247, 164, 91
	};

	PALETTEENTRY m_defaultPalEntry[20] = {
    { 0,   0,   0,    0 }, //0
    { 0x80,0,   0,    0 }, 
    { 0,   0x80,0,    0 }, 
    { 0x80,0x80,0,    0 }, 
    { 0,   0,   0x80, 0 },
    { 0x80,0,   0x80, 0 },
    { 0,   0x80,0x80, 0 },
    { 0xC0,0xC0,0xC0, 0 }, //7

    { 192, 220, 192,  0 }, //8
    { 166, 202, 240,  0 },
    { 255, 251, 240,  0 },
    { 160, 160, 164,  0 }, //11

    { 0x80,0x80,0x80, 0 }, //12
    { 0xFF,0,   0,    0 },
    { 0,   0xFF,0,    0 },
    { 0xFF,0xFF,0,    0 },
    { 0,   0,   0xFF, 0 },
    { 0xFF,0,   0xFF, 0 },
    { 0,   0xFF,0xFF, 0 },
    { 0xFF,0xFF,0xFF, 0 }  //19
	};
  
	MyLog.AddString("Attempting to create a palette...\n");

	// Allocate a log pal and fill it with the color table info.
	LOGPALETTE* pPal = (LOGPALETTE*) malloc(sizeof(LOGPALETTE) 
                    + 256 * sizeof(PALETTEENTRY));
	pPal->palVersion = 0x300; // Windows 3.0
	pPal->palNumEntries = 256; // table size

	//
	// Create palette.
	//
	int byRedMask = (1 << pfd.cRedBits) - 1 ;
	int byGreenMask = (1 << pfd.cGreenBits) - 1 ;
	int byBlueMask = (1 << pfd.cBlueBits) - 1 ;

	int n = 1 << pfd.cColorBits;
	for (int i=0; i<n; i++)
	{
		pPal->palPalEntry[i].peRed =
             (unsigned char)((double)((i >> pfd.cRedShift) & byRedMask) 
			 * (255.0 / (double)(byRedMask)) + 0.5);
		pPal->palPalEntry[i].peGreen =
             (unsigned char)((double)((i >> pfd.cGreenShift) & byGreenMask) 
			 * (255.0 / (double)(byGreenMask)) + 0.5); 
		pPal->palPalEntry[i].peBlue =
             (unsigned char)((double)((i >> pfd.cBlueShift) & byBlueMask) 
			 * (255.0 / (double)(byBlueMask)) + 0.5);
		pPal->palPalEntry[i].peFlags = 0;
	}

	//now accomodate system colors
	if ((pfd.cColorBits == 8)                           &&
		(pfd.cRedBits   == 3) && (pfd.cRedShift   == 0) &&
		(pfd.cGreenBits == 3) && (pfd.cGreenShift == 3) &&
		(pfd.cBlueBits  == 2) && (pfd.cBlueShift  == 6))
	{
		for (int j = 1 ; j <= 12 ; j++)
			pPal->palPalEntry[m_defaultOverride[j]] = 
                                               m_defaultPalEntry[j];
	}


	hPal = CreatePalette(pPal);
	hOldPal = SelectPalette(hDC, hPal, FALSE);
	RealizePalette(hDC);
	free (pPal);
	
	if (hPal != NULL)
		MyLog.AddString("Palette created succesfully.\n");
	else
		MyLog.AddString("Could not create Palette.\n");

	return (hPal != NULL);
}

/******************************************************************
* Function name	: InitGLLights      			     			  *
* Description	: Initializes light parameters (if any).	      *
* Return type	: void										      *	
* Argument      : void										      *
******************************************************************/
void InitGLLights (void)	{


	MyLog.AddString("Initiating lights parameters\n");
		
	//I will set one light here: LIGHT0
	GLfloat LightAmbient[]    = { 0.2f, 0.2f, 0.2f, 1.0f };
    GLfloat LightDiffuse[]    = { 1.0f,1.0f,1.0f, 1.0f};
    GLfloat LightSpecular[]    = { 0.5f, 0.5f, 0.5f, 1.0f };
	GLfloat LightPosition[]   = { 0.0f, 0.0f, 2.0f, 1.0f };

	glLightfv( GL_LIGHT0, GL_AMBIENT, LightAmbient);
	glLightfv( GL_LIGHT0, GL_DIFFUSE, LightDiffuse);
	glLightfv( GL_LIGHT0, GL_SPECULAR, LightSpecular);
	glLightfv( GL_LIGHT0, GL_POSITION, LightPosition);
}

/******************************************************************
* Function name	: SetRenderStates				     			  *
* Description	: Sets common OpenGL rendering states.			  *
*				  Can be called to re-set parameters based on     *	
*				  global variables to enable/disable things       *	
* Return type	: void										      *	
* Argument      : void										      *
******************************************************************/
void SetRenderStates(void) {

	MyLog.AddString("Setting render states\n");
		
	//We draw to the back buffer, then we flip to the front
	glDrawBuffer(GL_BACK);
	
	//Background color
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	
	//Draw front faced polys, solid (not wireframe)
	glPolygonMode(GL_FRONT, GL_FILL);
	
	//Some implementations may be slower if Clear Depth != 1.0
	//(Thats what I've heard)
	glClearDepth(1.0);
	
	//Use gouraud shading
	glShadeModel(GL_SMOOTH);

	//To speed Up things lets cull back faces
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);		
	
	//Enable Z-Buffering
	glEnable(GL_DEPTH_TEST);
	
	//Enable lighting and light 0
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);

	glEnable(GL_DITHER);

	glEnable(GL_POINT_SMOOTH);
	glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
	
	//Set common material properties
	GLfloat MatSpecular[]    = { 1.0f, 1.0f, 1.0f, 1.1f };
	GLfloat WhMat[]  = { 1.0f, 1.0f, 1.0f, 1.0f };

	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 128.0f);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, MatSpecular);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, WhMat);
}

/******************************************************************
* Function name	: Exit               			     			  *
* Description	: Checks for a valid Rendering Context. If there  *
*				  is one, it makes it not current and delete it.  *
*				  Release the HDC and unregister Window Class.	  *    
* Return type	: BOOL										      *	
* Argument      : void										      *
******************************************************************/

void Exit(void)
{
	MyLog.AddString("Restoring..\n");
	
	if(wglGetCurrentContext()!=NULL) 
    {
        //release the rendering context
        wglMakeCurrent(NULL, NULL) ;
		MyLog.AddString("Releasing HGLRC.\n");
    }
    
    if (hglRC!=NULL)	//delete it
    {
        wglDeleteContext(hglRC);
		MyLog.AddString("HGLRC Deleted: %u\n", hglRC);
        hglRC = NULL;
    }

	if (hDC)
	{
		if (hOldPal != NULL)	{
			SelectPalette(hDC, hOldPal, FALSE);
			DeleteObject(hPal);
			hPal = hOldPal = NULL;
			MyLog.AddString("Palette unselected and deleted.\n");
		}
		ReleaseDC(Hwnd, hDC);	//Release the HDC
		MyLog.AddString("HDC Released: %u\n",hDC);
		hDC = NULL;
	}
	
	//Destroy Window
	if (Hwnd)
	{
		DestroyWindow(Hwnd);
		MyLog.AddString("Destroying Window: %u\n", Hwnd);
		Hwnd = NULL;
	}
	
	//Unregister Window Class
	UnregisterClass(szWindowClass,hInst);
}


//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static int OldPos[] = {0,0}; //for tracking mouse
	int wmId, wmEvent, nVirtKey;
	TCHAR CharCode;

	switch (message) 
	{
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			// Parse the menu selections:
			switch (wmId)
			{
				case IDM_ABOUT:
					bAppActive = FALSE;
					DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
					bAppActive = TRUE;
					break;
				case IDM_EXIT:
					DestroyWindow(hWnd);
					Hwnd = NULL;
					break;
				case IDM_FULLSCREEN:
					//switch fullscreen. Here I'll keep actual
					//settings, but we could switch to a fixed 
					//size/bpp if we like
					ChangeDisplay(GetSystemMetrics(SM_CXSCREEN),
								  GetSystemMetrics(SM_CYSCREEN),
								  GetDeviceCaps(hDC, BITSPIXEL));
					break;
				case ID_HEIGHTMAP:
					bumptype = ID_HEIGHTMAP;
					break;
				case ID_TEXTURE:
					bumptype = ID_TEXTURE;
					break;
				case ID_ALL:
					bumptype = ID_ALL;
					break;
				case ID_1PASS:
					method = ID_1PASS;
					break;
				case ID_2PASS:
					method = ID_2PASS;
					break;
				case ID_3PASS:
					method = ID_3PASS;
					break;
				default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;
		case WM_INITMENU:
			if (!hasmultitexture)	{
				EnableMenuItem((HMENU) wParam, ID_1PASS, MF_BYCOMMAND | MF_GRAYED);
				EnableMenuItem((HMENU) wParam, ID_2PASS, MF_BYCOMMAND | MF_GRAYED);
				CheckMenuItem((HMENU) wParam, ID_3PASS, MF_BYCOMMAND | MF_CHECKED);	
			}
			else	{
				CheckMenuItem((HMENU) wParam, method, MF_BYCOMMAND | MF_CHECKED);	
			}
			//uncheck all
			CheckMenuItem((HMENU) wParam, ID_ALL, MF_BYCOMMAND | MF_UNCHECKED);	
			CheckMenuItem((HMENU) wParam, ID_HEIGHTMAP, MF_BYCOMMAND | MF_UNCHECKED);	
			CheckMenuItem((HMENU) wParam, ID_TEXTURE, MF_BYCOMMAND | MF_UNCHECKED);	
			
			//uncheck all
			CheckMenuItem((HMENU) wParam, ID_3PASS, MF_BYCOMMAND | MF_UNCHECKED);	
			CheckMenuItem((HMENU) wParam, ID_2PASS, MF_BYCOMMAND | MF_UNCHECKED);	
			CheckMenuItem((HMENU) wParam, ID_1PASS, MF_BYCOMMAND | MF_UNCHECKED);	
			
			//1 pass only renders all
			switch (method)
			{
			case ID_1PASS:
				EnableMenuItem((HMENU) wParam, ID_HEIGHTMAP, MF_BYCOMMAND | MF_GRAYED);
				EnableMenuItem((HMENU) wParam, ID_TEXTURE, MF_BYCOMMAND | MF_GRAYED);
				CheckMenuItem((HMENU) wParam, ID_ALL, MF_BYCOMMAND | MF_UNCHECKED);	
				break;
			default:
				EnableMenuItem((HMENU) wParam, ID_HEIGHTMAP, MF_BYCOMMAND | MF_ENABLED);
				EnableMenuItem((HMENU) wParam, ID_TEXTURE, MF_BYCOMMAND | MF_ENABLED);
				CheckMenuItem((HMENU) wParam, bumptype, MF_BYCOMMAND | MF_CHECKED);	
				break;
			}
			//check the one active
			CheckMenuItem((HMENU) wParam, method, MF_BYCOMMAND | MF_CHECKED);
			break;
		case WM_ACTIVATEAPP:
			//Only render while app still active
			bAppActive = (BOOL)wParam;
			return 0;
		case WM_PAINT:
			RenderFrame();
			break;			
		case WM_LBUTTONDOWN:
			mLState = DOWN;
            OldPos[0] = LOWORD(lParam);  
            OldPos[1] = HIWORD(lParam);  
            break;
		case WM_LBUTTONUP:
			mLState = UP;
			break;
		case WM_RBUTTONDOWN:
			mRState = DOWN;
            OldPos[0] = LOWORD(lParam);  
            OldPos[1] = HIWORD(lParam);  
            break;
		case WM_RBUTTONUP:
			mRState = UP;
			break;
		case WM_MOUSEMOVE:
			{
			int xPos = LOWORD(lParam);  //horizontal position of cursor 
			int yPos = HIWORD(lParam);  //vertical position of cursor 
 			if (mLState == DOWN) 
			{
				gRot[0] -= ((float)(OldPos[1] - yPos)*0.3f);
				gRot[1] -= ((float)(OldPos[0] - xPos)*0.3f);
				ClampD (gRot[0]);
				ClampD (gRot[1]);
			} 
			OldPos[0] = xPos;   
			OldPos[1] = yPos;
			}
			break;
			
		case WM_CHAR:
			CharCode = (TCHAR) wParam;
			switch(CharCode)
			{
				case 't':
				case 'T':
					Cam.LookAt(vect (0,0,0));
					Cam.LockTarget(!Cam.IsTargetLocked());
					return 0;
				case 'R':
				case 'r':
					Cam.Reset();
					return 0;
				case 'P':
				case 'p':
					Cam.ResetPos();
					return 0;
				case 'O':
				case 'o':
					Cam.ResetRot();
					return 0;
			}
			break;

		case WM_KEYDOWN:
			nVirtKey = (int) wParam;    
			switch(nVirtKey)
			{
				case VK_SPACE:
					Cam.SetDebugMode(!Cam.IsDebugOn());
					//bDebugCam = !bDebugCam;
					return 0;
			}
			break;

		case WM_ERASEBKGND:
			//avoid DefWindowProc for this message
			return 0;
			break;
		case WM_CREATE:	
			{
				MyLog.AddString("WM_CREATE\n");
				//Here we take once and for all a ClientDC
				//We will release it once we exit the App.
				hDC = GetDC(hWnd);
				MyLog.AddString("HDC %u retrieved\n", hDC);
				if (SetupPFD())
					return 0;
				else
					//SetupPFD() failed, stop the creation of
					//the Window, will lead to program termination
					return -1;
			}
			break;
		case WM_SIZE:
		{
			MyLog.AddString("WM_SIZE, Recalculating Projection Matrix.\n");
			if (wParam == SIZE_MINIMIZED){
				bAppActive = FALSE;
				return 0;
			}
			width = LOWORD(lParam); 
			height = HIWORD(lParam); 
			glViewport(0, 0, width, height);
			glMatrixMode(GL_PROJECTION);
			glLoadIdentity();
			gluPerspective(60, (GLdouble)width/(GLdouble)height, 0.1, 30.0);
			glMatrixMode(GL_MODELVIEW);
			glLoadIdentity();
			return 0;	//We handled the message, return 0
		}
		case WM_CLOSE:
		{
			MyLog.AddString("WM_CLOSE\n");
			bShouldEnd = TRUE;
			break;
		}
		case WM_DESTROY:
			if (bShouldEnd)
			{
				MyLog.AddString("WM_DESTROY\n");
				Hwnd = NULL;
				PostQuitMessage(0);
				return 0;
			}
			return 0;
		
   }
   	return DefWindowProc(hWnd, message, wParam, lParam);
}

// Mesage handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;
		case WM_WINDOWPOSCHANGED:
			InvalidateRect(hDlg, NULL, TRUE);
				return TRUE;
		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
			
	}
    return FALSE;
}


/****************************************************************
* Function name	: LoadTextures   				     			*
* Description	: Called from InitInstance. Load and bind all   *
*				  texturs here.									* 
* Return type	: void										    *	
* Argument      : void										    *
****************************************************************/

void LoadTextures(void)
{

	CGL_Dib MyDib, MyDib2;

	MyLog.AddString("Loading Textures...\n");

	//to mesure time consumed loading Textures
	DWORD time1 = timeGetTime();

	LPBYTE pImage;
	int a;

	/*-------------------------------
				BITMAPS
	--------------------------------*/
	
	//Base texture is used as is.
	MyDib.LoadBind("basetex.bmp", BASETEXTURE );

	//Heightmap needs further porcess. Load but don't bind it. 
	MyDib.Load("bump.bmp");

	/*--------------------------------------------------------
	From the heightmap (grayscale image) we will build two 
	different textures. 
	1. Same as original but half brightness.
	2. Inverted, and then half brightness.
	--------------------------------------------------------*/
	
	/*---- BUMP: Half brightness  -----*/
	pImage = new BYTE[3 * MyDib.GetWidth() * MyDib.GetHeight()];

	for (a = 0; a < (MyDib.GetWidth()*MyDib.GetHeight()); a++)
	{
		pImage[3*a]   = (BYTE)(MyDib.m_pGLImage[a].rgbRed/2.f + 0.5f);
		pImage[3*a+1] = (BYTE)(MyDib.m_pGLImage[a].rgbGreen/2.f + 0.5f);
		pImage[3*a+2] = (BYTE)(MyDib.m_pGLImage[a].rgbBlue/2.f + 0.5f);	
	}

	glBindTexture (GL_TEXTURE_2D, BUMP); 
	glPixelStorei (GL_UNPACK_ALIGNMENT, 1);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
	glTexImage2D (GL_TEXTURE_2D, 0, 3, MyDib.GetWidth(), MyDib.GetHeight(), 0, GL_RGB, GL_UNSIGNED_BYTE, (GLvoid*)pImage);
	

	/*---- INVBUMP: Inverted, then half brightness  -----*/
	for (a = 0; a < (MyDib.GetWidth()*MyDib.GetHeight()); a++)
	{
		pImage[3*a]   = (BYTE)(((255 - MyDib.m_pGLImage[a].rgbRed)/2.f) + 0.5f);
		pImage[3*a+1] = (BYTE)(((255 - MyDib.m_pGLImage[a].rgbGreen)/2.f) + 0.5f);
		pImage[3*a+2] = (BYTE)(((255 - MyDib.m_pGLImage[a].rgbBlue)/2.f) + 0.5f);
	}

	glBindTexture (GL_TEXTURE_2D, INVBUMP); 
	glPixelStorei (GL_UNPACK_ALIGNMENT, 1);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
	glTexImage2D (GL_TEXTURE_2D, 0, 3, MyDib.GetWidth(), MyDib.GetHeight(), 0, GL_RGB, GL_UNSIGNED_BYTE, (GLvoid*)pImage);

	delete [] pImage;

	if (!hasmultitexture)
	{
		float dif = (timeGetTime() - time1)/1000.f;
		MyLog.AddString("Time to load textures: %.2f sec.\n", dif);
		return;
	}

	/*----------------
	  Now for 1 PASS
	----------------*/
	MyDib.Load("basetex.bmp");
	MyDib2.Load("bump.bmp");
	
	//Dibs must have same sizes or caboom!!
	if 	(MyDib.GetWidth() != MyDib2.GetWidth() ||
		 MyDib.GetHeight() != MyDib2.GetHeight())
	{
		MessageBox(Hwnd, "Both bitmaps must be same size!", "Warning",
				   MB_OK || MB_APPLMODAL || MB_ICONEXCLAMATION);
		return;
	}

	//Put base texture as color and bump texture as alpha
	pImage = new BYTE[4 * MyDib.GetWidth() * MyDib.GetHeight()];

	for (a = 0; a < (MyDib.GetWidth()*MyDib.GetHeight()); a++)
	{
		pImage[4*a]   = (BYTE)(MyDib.m_pGLImage[a].rgbRed);
		pImage[4*a+1] = (BYTE)(MyDib.m_pGLImage[a].rgbGreen);
		pImage[4*a+2] = (BYTE)(MyDib.m_pGLImage[a].rgbBlue);	
		pImage[4*a+3] = (BYTE)((MyDib2.m_pGLImage[a].rgbRed + 
								MyDib2.m_pGLImage[a].rgbGreen +
								MyDib2.m_pGLImage[a].rgbBlue)/6.f);
	}
	
	glBindTexture (GL_TEXTURE_2D, BASE_BUMP); 
	glPixelStorei (GL_UNPACK_ALIGNMENT, 1);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
	glTexImage2D (GL_TEXTURE_2D, 0, 4, MyDib.GetWidth(), MyDib.GetHeight(), 0, GL_RGBA, GL_UNSIGNED_BYTE, (GLvoid*)pImage);
	
	//destructor will handle Dibs deletion

	float dif = (timeGetTime() - time1)/1000.f;
	MyLog.AddString("Time to load textures: %.2f sec.\n", dif);
}


/****************************************************************
* Function name	: DrawAxis    				     				*
* Description	: Draw X,Y,Z  Axis. It's a good debugging aid.  *
* Return type	: void										    *	
* Argument      : void										    *
****************************************************************/
void DrawAxis(void)
{

	glPushAttrib(GL_CURRENT_BIT | GL_LIGHTING_BIT | GL_LINE_BIT);

	glDisable(GL_LIGHTING);
	
	glLineWidth(2.0f);

	const float length = 7.0f;

	glBegin (GL_LINES);
		//X Axis
		glColor3f (0.3f, 0.0, 0.0);
		glVertex3f (-length, 0.0, 0.0);
		glColor3f (1.0f, 0.0, 0.0);
		glVertex3f (length, 0.0, 0.0);
		//Y Axis
		glColor3f (0.0, 0.3f, 0.0);
		glVertex3f (0.0, -length, 0.0);
		glColor3f (0.0, 1.0f, 0.0);
		glVertex3f (0.0, length, 0.0);
		//Z Axis
		glColor3f (0.0, 0.0, 0.3f);
		glVertex3f (0.0, 0.0, -length);
		glColor3f (0.0, 0.0, 1.0f);
		glVertex3f (0.0, 0.0, length);
	glEnd ();
	
	glPopAttrib();
}

/****************************************************************
* Function name	: ChangeDisplay   				     			*
* Description	: Switch between Fullscreen/Windowed		    *
* Return type	: BOOL										    *	
* Argument      : void										    *
****************************************************************/
BOOL ChangeDisplay(int p_width, int p_height, int p_bpp)
{
	DEVMODE devmode;
	BOOL modeswitch;
	LONG result;
	CHAR error[50];
	int count=0;

	MyLog.AddString("Changing Display Mode..\n");

	//Remember you should rebuild all your display lists
	//after this
	if (!bFullScreen)		//We are windowed, switch fullscreen
	{
		
		MyLog.AddString("Attempting Fullscreen %ix%ix%ibpp\n",
						p_width, p_height, p_bpp);
		
		//Enumerate possible display modes
		//find the DEVMODE number for p_width x p_height x p_bpp
		do
		{
			modeswitch = EnumDisplaySettings(NULL, count, &devmode);
			count++;
		}
		while(((devmode.dmBitsPerPel != (ULONG)p_bpp) || 	
			  (devmode.dmPelsWidth != (ULONG)p_width) ||   
			  (devmode.dmPelsHeight != (ULONG)p_height)) && 
			  (count<50) );	//Stop after 50 tries
		
		if (!modeswitch)		
		{
			sprintf(&error[0], "Fullscreen %ix%ix%ibpp not supported", p_width, p_height, p_bpp);
			MessageBox(0, &error[0], "Changing..", MB_ICONERROR);
			return FALSE;
		}
		else
		{
			devmode.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;
			result = ChangeDisplaySettings(&devmode, 0);

			//Check if we were not succesfull
			if (result != DISP_CHANGE_SUCCESSFUL)
			{
				MyLog.AddString("Error attempting to change display settings.\n");
				
				if(result==DISP_CHANGE_RESTART)	{
					sprintf(&error[0], "You must manually set %ix%ix%ibpp and restart", p_width, p_height, p_bpp);
					MessageBox(0, &error[0], "Changing..", MB_ICONEXCLAMATION);
				}
				else if(result==DISP_CHANGE_BADMODE)	{
					sprintf(&error[0], "%ix%ix%ibpp not supported", p_width, p_height, p_bpp);	
					MessageBox(0, &error[0], "Changing..", MB_ICONERROR);
				}
				else if(result==DISP_CHANGE_FAILED)		{
					sprintf(&error[0], "Hardware failed to change to %ix%ix%ibpp", p_width, p_height, p_bpp);	
					MessageBox(0, &error[0], "Changing..", MB_ICONERROR);
				}
				return FALSE;
			}
		
			MyLog.AddString("Display Change Successfull: %ix%ix%ibpp\n", 
							devmode.dmPelsWidth, devmode.dmPelsHeight, devmode.dmBitsPerPel );

		}
		
		bFullScreen = TRUE;
		
		//Clean and destroy window
		Exit();
		
		//Register new class
		RegisterClass(hInst, TRUE);

		//Init everything again
		InitInstance(hInst, SW_SHOWNORMAL, TRUE);
		
		//Hide the cursor for fullscreen
		ShowCursor(FALSE);	
			
		return TRUE;
	}
	else		//We are Fullscreen, return to windowed
	{
		MyLog.AddString("Switching back to windowed\n");
		
		//Clean and destroy window
		Exit();
		
		//Return To previous mode
		ChangeDisplaySettings(NULL, 0);
		
		RegisterClass(hInst, FALSE);

		InitInstance(hInst, SW_SHOWNORMAL, FALSE);
		
		bFullScreen = FALSE;
		
		//Show the cursor while windowed
		ShowCursor(TRUE);	

		return TRUE;
	}
}

/****************************************************************
* Function name	: Do TimerStuff 			     				*
* Description	: Timing stuff								    *
* Return type	: void										    *	
* Argument      : void											*
****************************************************************/
void DoTimerStuff(void)
{
	static float Timer = 0.0f;
	static DWORD prevTime = timeGetTime();
	static float FrameRate = 0.f;
	static unsigned int FrameCount = 0;
	
	FrameCount++;	
	
	//Time now
	DWORD now = timeGetTime();
	//Calc elapsed since last frame in secs
	Elapsed = (float)(now - prevTime)/1000.0f; 

	//increment timer
	Timer += Elapsed;

	//Update Framerate each second
	if (Timer>=1.0f)	{
		FrameRate = ((float)FrameCount)/Timer;
		//Reset Framecount and Timer
		FrameCount = 0;		
		Timer = 0.0f;	
		//Update Titlebar only when windowed
		if (!bFullScreen)	{
			sprintf(szTitle, "OpenGL Emboss Bumpmapping [%.0f fps]",FrameRate); 
			SetWindowText(Hwnd, szTitle);
		}
	}

	//Make sure Elapsed is not too big or 
	//the light will change too much
	if (Elapsed > 0.1f) Elapsed = 0.1f;

	//Update prevTime for next frame
	prevTime = now;
}

/*************************************************************
* Function name	: CheckEXT  			     				 *
* Description	: Checks if extension is supported.		     *	
*				  Code by Mark Kilgard.						 *											
* Return type	: BOOL										 *	
* Argument      : char* (the exact EXT name)    			 *
*************************************************************/
BOOL CheckEXT(char* name)
{
	MyLog.AddString("OpenGl %s extension ", name);

	const GLubyte *extensions = NULL;
	const GLubyte *start;
	GLubyte *where, *terminator;

	/* Extension names should not have spaces. */
	where = (GLubyte *) strchr(name, ' ');
	if (where || *name == '\0')	{
		MyLog.AddString("not supported\n");
		return 0;
	}
	
	extensions = glGetString(GL_EXTENSIONS);
	
	/* It takes a bit of care to be fool-proof about parsing the
     OpenGL extensions string. Don't be fooled by sub-strings,
     etc. */
	
	start = extensions;
	
	for (;;) {
		where = (GLubyte *) strstr((const char *)start, name);
		if (!where)
			break;
		terminator = where + strlen(name);
		if (where == start || *(where - 1) == ' ')
			if (*terminator == ' ' || *terminator == '\0')	{
				MyLog.AddString("supported\n");	
				return TRUE;
			}
		start = terminator;
	}
	
	MyLog.AddString("not supported\n");
	return FALSE;
}
 
/*************************************************************
* Function name	: DrawMesh3Pass			     				 *
* Description	: Three pass method. No multitexture or any  *	
*				  other extension is needeed.			     *
* Return type	: void										 *	
* Argument      : void						    			 *
*************************************************************/
void DrawMesh3Pass(void)
{
	
	const int col = 10;	//mesh columns
	const int row = 10;	//mesh rows

	const float mWidth = 10.f;	//mesh width
	const float mHeight = 10.f;	//mesh height

	const float stepx = mWidth/col;		//distance between columns
	const float stepy = mHeight/row;    //distance between rows

	const int polymode = GL_TRIANGLE_STRIP;
	
	vect vertex;
	
	/*------------------------------------------------------
	First Pass: No Blend. Use half brightness texture.
				No lighting.
				No offsetted texcoords.
	------------------------------------------------------*/

	glDisable(GL_BLEND);
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, BUMP);

	//if bumptype is ID_TEXTURE we only render the base texture
	if (bumptype != ID_TEXTURE)
	{
		/*-----------------------------------------------------
		Just a simple plain mesh. We could do it with a single 
		QUAD (as no lighting is performed) but that wouldn't 
		show the advantages of multitexturing. Thats because 
		the	geometry is really simple
		------------------------------------------------------*/
		for (int a = 0; a < row; a++)	{
			glBegin(polymode);
			for (int b = 0; b <= col; b++)	
			{
				vertex.x = b*stepx - mWidth/2;
				vertex.y = (a+1)*stepy - mHeight/2;
				vertex.z = 0;
			
				glTexCoord2f( (float)b/col, (float)(a+1)/row );
				glVertex3fv(vertex);
			
				vertex.y -= stepy;
				glTexCoord2f((float)b/col, (float)a/row);
				glVertex3fv(vertex);
			}
			glEnd();
		}
	}
	
	/*--------------------------------------------------------
	Second Pass: Use inverted - half brightness texture.
		         Still no lighting.
				 Blend 1x (thats ADD)
				 Offsetted texcoords.
	
	Offsetted texcoords: Thats what makes the "depth' feeling.
	First get the vector from vertex to light being rendered.
	Normalize it. Then project this vector into "tangent space".
	Tangent	space is the plane tangent to the surface at the
	current	vertex. In this particular example the surface is 
	parallel to the XY plane, so projecting the vertex would be
	making it's Z component 0. Offset texcoords by (x,y) com-
	ponents of that vector in (s,t).
	Here you can see why we make both bump textures half bright.
	Thats because we ADD them in this pass. 
	--------------------------------------------------------*/
	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE, GL_ONE);
	//Set DepthFunc to LEQUAL or it will not pass depth test
	glDepthFunc(GL_LEQUAL);
	glBindTexture(GL_TEXTURE_2D, INVBUMP);

	//maxoffset, higher to increase depth perception at the expense
	//of some quality. Dependant of geometry size. Change and see.
	float maxoffset = 0.004f;
	
	if (bumptype != ID_TEXTURE)
	{
		for (int a = 0; a < row; a++)	{
			
			glBegin(polymode);

			for (int b = 0; b <= col; b++)	
			{
				vertex.x = b*stepx - mWidth/2;
				vertex.y = (a+1)*stepy - mHeight/2;
				vertex.z = 0;
			
				vect texcoord;
				texcoord = lpos - vertex;
				texcoord.Normalize();
				texcoord *= maxoffset;

				glTexCoord2f((float)b/col + texcoord.x, (float)(a+1)/row + texcoord.y);
				glVertex3fv(vertex);
	
				vertex.y -= stepy;

				texcoord = lpos - vertex;
				texcoord.Normalize();
				texcoord *= maxoffset;

				glTexCoord2f((float)b/col + texcoord.x, (float)a/row + texcoord.y);
				glVertex3fv(vertex);
			}
			glEnd();
		}
	}

	glEnable(GL_LIGHTING);
	
	/*------------------------------------------------------
	Third Pass: Use unmodified base texture.
				Enable lighting.
				No offsetted texcoords.
				Blend mode -> Multiply 2x
	------------------------------------------------------*/
	
	//this blend func reads as dst*src + src*dst. Efectively
	//2*(dst*src) or multiply 2x
	glBlendFunc(GL_DST_COLOR, GL_SRC_COLOR);

	//If we are rendering just the base texture do no blending
	if (bumptype == ID_TEXTURE)
		glDisable(GL_BLEND);
	
	glBindTexture(GL_TEXTURE_2D, BASETEXTURE);
	glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	//if we are rendering just the heightmap skip this pass
	if (bumptype != ID_HEIGHTMAP)
	{

		for (int a = 0; a < row; a++)	{
			glBegin(polymode);
			for (int b = 0; b <= col; b++)	{
				glNormal3f(0,0,1);
			
				vertex.x = b*stepx - mWidth/2;
				vertex.y = (a+1)*stepy - mHeight/2;
				vertex.z = 0;
			
				glTexCoord2f( (float)b/col, (float)(a+1)/row);
				glVertex3fv(vertex);
			
				vertex.y -= stepy;
			
				glTexCoord2f((float)b/col, (float)a/row);
				glVertex3fv(vertex);
			}
			glEnd();
		}
	}

	//restore previous states
	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	glDepthFunc(GL_LESS);
	
	//Draw a little yellow point at lightpos
	glDisable(GL_LIGHTING);
	glColor3f(1,1,0);
	glPointSize(5.0f);
	glBegin(GL_POINTS);
	glVertex3fv(lpos);
	glEnd();
	glEnable(GL_LIGHTING);
	glColor3f(1,1,1);
}
	
/*************************************************************
* Function name	: DrawMesh2Pass			     				 *
* Description	: Taking advantage of multitexturing capa-   *
*				  bilities we can convine pass 1 and 2 into a* 
*				  single one. We also need more flexible     *
*				  Texture conviners than the simplistic OGL  *
*				  ones so we use EXT_texture_env_combine to  *
*				  have the desired control over texture ops. *
*														     *
* Return type	: void										 *	
* Argument      : void						    			 *
*************************************************************/
void DrawMesh2Pass(void)
{
	const float offset = 0.004f;
	
	const int col = 10;	//mesh columns
	const int row = 10;	//mesh rows

	const float mWidth = 10.f;	//mesh width
	const float mHeight = 10.f;	//mesh height

	const float stepx = mWidth/col;
	const float stepy = mHeight/row;

	const int polymode = GL_TRIANGLE_STRIP;
	
	vect vertex, texcoord;
	
	/*------------------------------------------------------
	First Pass: No blending. No lighting.
	
	Texture Unit 0: Use half bright heightmap.
					Texture Op REPLACE. Unmodified texcoords.
			
	Texture Unit 1: Use inverted half bright heightmap
					Texture Op ADD. Offsetted texcoords.
	------------------------------------------------------*/

	glDisable(GL_BLEND);
	glDisable(GL_LIGHTING);

	/*TEXTURE UNIT 0*/
	glActiveTextureARB(GL_TEXTURE0_ARB);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, BUMP);
	//convine mode
	glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE_EXT);
	//Operation: REPLACE
	glTexEnvf (GL_TEXTURE_ENV, GL_COMBINE_RGB_EXT, GL_REPLACE);

	/*TEXTURE UNIT 1*/
	glActiveTextureARB(GL_TEXTURE1_ARB);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, INVBUMP);
	//convine mode
	glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE_EXT);
	//Operation: ADD
	glTexEnvf (GL_TEXTURE_ENV, GL_COMBINE_RGB_EXT, GL_ADD);
	
	/*------------------------------------------------------------
	Same mesh as 3 passes. Normal texcoords for Texture Unit 0.
	Offsetted for Texture Unit 1.
	It's the same as pass 1 and 2 for three passes mode but all
	in one.
	-------------------------------------------------------------*/
	if (bumptype != ID_TEXTURE)
	{
		for (int a = 0; a < row; a++)	{
			glBegin(polymode);
			for (int b = 0; b <= col; b++)	
			{
				glNormal3f(0,0,1);

				vertex.x = b*stepx - mWidth/2;
				vertex.y = (a+1)*stepy - mHeight/2;
				vertex.z = 0;
							
				texcoord = lpos - vertex;
				texcoord.Normalize();
				texcoord *= offset;

				glMultiTexCoord2fARB(GL_TEXTURE0_ARB, (float)b/col, (float)(a+1)/row);
				glMultiTexCoord2fARB(GL_TEXTURE1_ARB, (float)b/col + texcoord.x, (float)(a+1)/row + texcoord.y);
				glVertex3f( vertex.x, vertex.y, vertex.z);
			
				vertex.y -= stepy;
				texcoord = lpos - vertex;
				texcoord.Normalize();
				texcoord *= offset;	

				glMultiTexCoord2fARB(GL_TEXTURE0_ARB, (float)b/col, (float)a/row);
				glMultiTexCoord2fARB(GL_TEXTURE1_ARB, (float)b/col + texcoord.x, (float)a/row + texcoord.y);
				glVertex3f( vertex.x, vertex.y, vertex.z);
			}
			glEnd();
		}
	}

	/*--------------------------------------------------------------
	Base Texture (multiply 2x). Same as third pass of 3 passes mode
	--------------------------------------------------------------*/
	
	glDepthFunc(GL_LEQUAL);
	glEnable(GL_LIGHTING);

	//disable second texture unit
	glActiveTextureARB(GL_TEXTURE1_ARB);
	glDisable(GL_TEXTURE_2D);
	
	//bind base texture to texture unit 0
	glActiveTextureARB(GL_TEXTURE0_ARB);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, BASETEXTURE);
	
	glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glBindTexture(GL_TEXTURE_2D, BASETEXTURE); 
	
	if (bumptype == ID_TEXTURE)
		glDisable(GL_BLEND);
	else
	{
		glEnable(GL_BLEND);
		glBlendFunc(GL_DST_COLOR, GL_SRC_COLOR);
	}

	if (bumptype != ID_HEIGHTMAP)
	{

		for (int a = 0; a < row; a++)	{
			glBegin(polymode);
			for (int b = 0; b <= col; b++)	{
				glNormal3f(0,0,1);
			
				vertex.x = b*stepx - mWidth/2;
				vertex.y = (a+1)*stepy - mHeight/2;
				vertex.z = 0;
			
				glTexCoord2f( (float)b/col, (float)(a+1)/row);
				glVertex3fv(vertex);
			
				vertex.y -= stepy;
			
				glTexCoord2f((float)b/col, (float)a/row);
				glVertex3fv(vertex);
			}
			glEnd();
		}
	}

	//restore previous states
	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	glDepthFunc(GL_LESS);
	
	//Draw a little yellow point at lightpos
	glDisable(GL_LIGHTING);
	glColor3f(1,1,0);
	glPointSize(5.0f);
	glBegin(GL_POINTS);
	glVertex3fv(lpos);
	glEnd();
	glEnable(GL_LIGHTING);
	glColor3f(1,1,1);

}

/*************************************************************
* Function name	: DrawMesh1Pass			     				 *
* Description	: Taking advantage of multitexturing capa-   *
*				  bilities and more advanced texture register* 
*				  conviners we can do it in a single single  *	
*				  pass.										 *
* Return type	: void										 *	
* Argument      : void						    			 *
*************************************************************/
void DrawMesh1Pass(void)
{
	/*-------------------------------------------------------
	For this method we will use a texture that has the base
	texture as color RGB channel and the heighmap as an alpha 
	channel.
	Some color degradation is visible. Maybe I'm not doing it
	right. Maybe as color operations are done with imprecise 
	integer color values, so many operations end in loss off
	presicion.
	Also, highlights have less intensity.
	It's a tradeoff for a noticeable increase in speed.
	-------------------------------------------------------*/
	const float offset = 0.004f;
	
	const int col = 10;	//mesh columns
	const int row = 10;	//mesh rows

	const float mWidth = 10.f;	//mesh width
	const float mHeight = 10.f;	//mesh height
	
	const float stepx = mWidth/col;
	const float stepy = mHeight/row;

	const int polymode = GL_TRIANGLE_STRIP;
	
	vect vertex, texcoord;

	//Blend mode
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ZERO);
	
	//We do lighting so keep it enabled
	
	glPushAttrib(GL_TEXTURE_BIT);
	
	/*----------------
	  Texture unit 0 
	----------------*/
	glActiveTextureARB(GL_TEXTURE0_ARB);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, BASE_BUMP);
	
	//-convine mode-
	glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE_EXT);
	
	//-Color Operation: modulate2X-
	glTexEnvf (GL_TEXTURE_ENV, GL_COMBINE_RGB_EXT, GL_MODULATE);
	glTexEnvf (GL_TEXTURE_ENV, GL_RGB_SCALE_EXT, 2.0);
	//Defaults SOURCE<n> and OPERAND<n> are ok

	//-Alpha operation-
	glTexEnvf (GL_TEXTURE_ENV, GL_COMBINE_ALPHA_EXT, GL_REPLACE);
	//Defaults SOURCE<n> and OPERAND<n> are ok

	/*----------------
	  Texture unit 1 
	----------------*/
	glActiveTextureARB(GL_TEXTURE1_ARB);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, BASE_BUMP);
	
	//convine mode
	glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE_EXT);
	
	//Color Operation
	glTexEnvf (GL_TEXTURE_ENV, GL_COMBINE_RGB_EXT, GL_REPLACE);
	glTexEnvf (GL_TEXTURE_ENV, GL_RGB_SCALE_EXT, 1.0);

	//Use result of previous texture environment as input source
	glTexEnvf (GL_TEXTURE_ENV, GL_SOURCE0_RGB_EXT, GL_PREVIOUS_EXT);
	
	//Alpha operation: Add Signed 2X (that's Arg0 + Arg1 - 0.5)
	glTexEnvf (GL_TEXTURE_ENV, GL_COMBINE_ALPHA_EXT, GL_ADD_SIGNED_EXT);

	//Use texture as SOURCE0
	glTexEnvf (GL_TEXTURE_ENV, GL_SOURCE0_ALPHA_EXT, GL_TEXTURE);
	//Use (1-alpha) as OPERAND0
	glTexEnvf (GL_TEXTURE_ENV, GL_OPERAND0_ALPHA_EXT, GL_ONE_MINUS_SRC_ALPHA);
	
	//Use result of previous texture environment as SOURCE1
	glTexEnvf (GL_TEXTURE_ENV, GL_SOURCE1_ALPHA_EXT, GL_PREVIOUS_EXT);

	/*------------------------------------------------------------
	Same mesh as 3 passes. Normal texcoords for Texture Unit 0.
	Offsetted for Texture Unit 1.
	-------------------------------------------------------------*/
	for (int a = 0; a < row; a++)	{
		glBegin(polymode);
		for (int b = 0; b <= col; b++)	
		{
			glNormal3f(0,0,1);

			vertex.x = b*stepx - mWidth/2;
			vertex.y = (a+1)*stepy - mHeight/2;
			vertex.z = 0;
							
			texcoord = lpos - vertex;
			texcoord.Normalize();
			texcoord *= offset;

			glMultiTexCoord2fARB(GL_TEXTURE0_ARB, (float)b/col, (float)(a+1)/row);
			glMultiTexCoord2fARB(GL_TEXTURE1_ARB, (float)b/col + texcoord.x, (float)(a+1)/row + texcoord.y);
			glVertex3f( vertex.x, vertex.y, vertex.z);
			
			vertex.y -= stepy;
			texcoord = lpos - vertex;
			texcoord.Normalize();
			texcoord *= offset;	

			glMultiTexCoord2fARB(GL_TEXTURE0_ARB, (float)b/col, (float)a/row);
			glMultiTexCoord2fARB(GL_TEXTURE1_ARB, (float)b/col + texcoord.x, (float)a/row + texcoord.y);
			glVertex3f( vertex.x, vertex.y, vertex.z);
		}
		glEnd();
	}

	//restore previous states
	glPopAttrib();
	glDisable(GL_BLEND);
	//disable both texture units
	glActiveTextureARB(GL_TEXTURE1_ARB);
	glDisable(GL_TEXTURE_2D);
	glActiveTextureARB(GL_TEXTURE0_ARB);	
	glDisable(GL_TEXTURE_2D);
	
	//Draw a little yellow point at lightpos
	glDisable(GL_LIGHTING);
	glColor3f(1,1,0);
	glPointSize(5.0f);
	glBegin(GL_POINTS);
	glVertex3fv(lpos);
	glEnd();
	glEnable(GL_LIGHTING);
	glColor3f(1,1,1);

}

/*************************************************************
* Function name	: MoveLight				     				 *
* Description	: Called each frame to position the one and  *	
*				  only light in scene.					     *
* Return type	: void										 *	
* Argument      : void						    			 *
*************************************************************/
void MoveLight(void)
{
	static float angle = 0;
	
	//For this example I'll move the light in a circle 
	//in front of the mesh
	angle += 60*Elapsed;
	ClampD(angle);
	
	lpos.x = 4*(float)cos(DegToRad(angle));
	lpos.y = 4*(float)sin(DegToRad(angle));
	lpos.z = 2.f;

	GLfloat LightPosition[]   = { lpos.x, lpos.y, lpos.z, 1.0f };
	glLightfv( GL_LIGHT0, GL_POSITION, LightPosition);
}

/*************************************************************
* Function name	: linkEXT				     				 *
* Description	: Get function pointers for the desired      * 
*				  extensions.								 *	
*				  I'm being optimistic here and think that if*
*				  a ICD reports support for an extension	 *
*				  wglGetProcAddress will find the address.	 *
*				  Further enhancements: Check not null		 *
*				  pointers returned.						 *
* Return type	: void										 *	
* Argument      : void						    			 *
*************************************************************/
void linkEXT()
{
glMultiTexCoord1dARB	= (PFNGLMULTITEXCOORD1DARBPROC)		wglGetProcAddress("glMultiTexCoord1dEXT");
glMultiTexCoord1dvARB	= (PFNGLMULTITEXCOORD1DVARBPROC)	wglGetProcAddress("glMultiTexCoord1dvARB");	
glMultiTexCoord1fARB	= (PFNGLMULTITEXCOORD1FARBPROC)		wglGetProcAddress("glMultiTexCoord1fARB");
glMultiTexCoord1fvARB	= (PFNGLMULTITEXCOORD1FVARBPROC)	wglGetProcAddress("glMultiTexCoord1fvARB");
glMultiTexCoord1iARB	= (PFNGLMULTITEXCOORD1IARBPROC)		wglGetProcAddress("glMultiTexCoord1iARB");
glMultiTexCoord1ivARB	= (PFNGLMULTITEXCOORD1IVARBPROC)	wglGetProcAddress("glMultiTexCoord1ivARB");
glMultiTexCoord1sARB	= (PFNGLMULTITEXCOORD1SARBPROC)		wglGetProcAddress("glMultiTexCoord1sARB");
glMultiTexCoord1svARB	= (PFNGLMULTITEXCOORD1SVARBPROC)	wglGetProcAddress("glMultiTexCoord1svARB");
glMultiTexCoord2dARB	= (PFNGLMULTITEXCOORD2DARBPROC)		wglGetProcAddress("glMultiTexCoord2dARB");
glMultiTexCoord2dvARB	= (PFNGLMULTITEXCOORD2DVARBPROC)	wglGetProcAddress("glMultiTexCoord2dvARB");	
glMultiTexCoord2fARB	= (PFNGLMULTITEXCOORD2FARBPROC)		wglGetProcAddress("glMultiTexCoord2fARB");
glMultiTexCoord2fvARB	= (PFNGLMULTITEXCOORD2FVARBPROC)	wglGetProcAddress("glMultiTexCoord2fvARB");
glMultiTexCoord2iARB	= (PFNGLMULTITEXCOORD2IARBPROC)		wglGetProcAddress("glMultiTexCoord2iARB");
glMultiTexCoord2ivARB	= (PFNGLMULTITEXCOORD2IVARBPROC)	wglGetProcAddress("glMultiTexCoord2ivARB");
glMultiTexCoord2sARB	= (PFNGLMULTITEXCOORD2SARBPROC)		wglGetProcAddress("glMultiTexCoord2sARB");
glMultiTexCoord2svARB	= (PFNGLMULTITEXCOORD2SVARBPROC)	wglGetProcAddress("glMultiTexCoord2svARB");
glMultiTexCoord3dARB	= (PFNGLMULTITEXCOORD3DARBPROC)		wglGetProcAddress("glMultiTexCoord3dARB");
glMultiTexCoord3dvARB	= (PFNGLMULTITEXCOORD3DVARBPROC)	wglGetProcAddress("glMultiTexCoord3dvARB");
glMultiTexCoord3fARB	= (PFNGLMULTITEXCOORD3FARBPROC)		wglGetProcAddress("glMultiTexCoord3fARB");
glMultiTexCoord3fvARB	= (PFNGLMULTITEXCOORD3FVARBPROC)	wglGetProcAddress("glMultiTexCoord3fvARB");
glMultiTexCoord3iARB	= (PFNGLMULTITEXCOORD3IARBPROC)		wglGetProcAddress("glMultiTexCoord3iARB");
glMultiTexCoord3ivARB	= (PFNGLMULTITEXCOORD3IVARBPROC)	wglGetProcAddress("glMultiTexCoord3ivARB");
glMultiTexCoord3sARB	= (PFNGLMULTITEXCOORD3SARBPROC)		wglGetProcAddress("glMultiTexCoord3sARB");
glMultiTexCoord3svARB	= (PFNGLMULTITEXCOORD3SVARBPROC)	wglGetProcAddress("glMultiTexCoord3svARB");
glMultiTexCoord4dARB	= (PFNGLMULTITEXCOORD4DARBPROC)		wglGetProcAddress("glMultiTexCoord4dARB");
glMultiTexCoord4dvARB	= (PFNGLMULTITEXCOORD4DVARBPROC)	wglGetProcAddress("glMultiTexCoord4dvARB");	
glMultiTexCoord4fARB	= (PFNGLMULTITEXCOORD4FARBPROC)		wglGetProcAddress("glMultiTexCoord4fARB");
glMultiTexCoord4fvARB	= (PFNGLMULTITEXCOORD4FVARBPROC)	wglGetProcAddress("glMultiTexCoord4fvARB");
glMultiTexCoord4iARB	= (PFNGLMULTITEXCOORD4IARBPROC)		wglGetProcAddress("glMultiTexCoord4iARB");
glMultiTexCoord4ivARB	= (PFNGLMULTITEXCOORD4IVARBPROC)	wglGetProcAddress("glMultiTexCoord4ivARB");
glMultiTexCoord4sdARB	= (PFNGLMULTITEXCOORD4SARBPROC)		wglGetProcAddress("glMultiTexCoord4sdARB");
glMultiTexCoord4svARB	= (PFNGLMULTITEXCOORD4SVARBPROC)	wglGetProcAddress("glMultiTexCoord4svARB");
glActiveTextureARB		= (PFNGLACTIVETEXTUREARBPROC)		wglGetProcAddress("glActiveTextureARB");
glClientActiveTextureARB= (PFNGLCLIENTACTIVETEXTUREARBPROC)	wglGetProcAddress("glClientActiveTextureARB");

}


