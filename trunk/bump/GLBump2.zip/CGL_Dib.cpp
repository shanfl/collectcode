/*-------------------------------------------------------------

CGL_Dib.cpp: Dib reader implementation

  			Copyright Diego T�rtara, 1999.
			
		   -  diego_tartara@ciudad.com.ar  -

Comments: Loads almost any bitmap except for compresed ones.
		  Also captures the screen (to a texture) or just 
		  a portion

Known Issues: none that I know.

Improvements: Implement flags for feedback about errors
			  (ERROR_INVALID_FORMAT etc etc).
----------------------------------------------------------------*/

#include "CGL_Dib.h"

/******************************************************
* Constructor: Only initialices members to NULL or 0. *
******************************************************/
CGL_Dib::CGL_Dib()
{
	m_lpImage = NULL;
	m_pGLImage = NULL;
	m_lpvColorTable = NULL;
	m_lpPalette = NULL;
	m_LineWidth = 0;
	m_dwSizeImage = 0;
	m_nColorTableEntries = 0;
	m_Height = 0;
	m_Width = 0;
}


/**************************************************
* Destructor: Only calls Clean().                 *
***************************************************/
CGL_Dib::~CGL_Dib()
{
	Clean();
}

/*********************************************************
* Load(): The big guy. The brain function. The Godfather *
*         Where everything happens.                      *  
**********************************************************/
CGL_Dib::Load(const CHAR* strPathName)
{
	if (m_lpImage!=NULL || m_pGLImage !=NULL || m_lpPalette!=NULL)
		Clean();

	BITMAPFILEHEADER bmfh;
	
	FILE* bm = fopen(strPathName, "rb");
	
	//Test file opened succesfully
	if (bm==NULL)				
		return FALSE;	
	
	int nCount;
	nCount = fread((void*)&bmfh, sizeof(BITMAPFILEHEADER), 1, bm);
	
	//Ensure bmfh carrectly red and "BM" tag present
	if (nCount!=1 || bmfh.bfType != 0x4d42)	{	
		fclose(bm);
		return FALSE;	
	}
	
	//By now the file pointer is at the end of the 
	//BITMAPFILEHEADER structure. the bfOffBits tell
	//us the offset in Bytes from here to the
	//actual bitmap bits

	//read BITMAPINFOHEADER
	nCount = fread((void*)&m_BMIH, sizeof(BITMAPINFOHEADER), 1, bm);
	
	//test for fread error 
	if (nCount != 1)	{
		fclose(bm);
		Clean();
		return FALSE;
	}

	//Compute sizes
	ComputeMetrics();
	ComputePaletteSize();

	//read palette if any
	if (m_BMIH.biBitCount < 16) {
		m_lpvColorTable = new RGBQUAD[m_nColorTableEntries];
		nCount = fread((void*)m_lpvColorTable, sizeof(RGBQUAD), m_nColorTableEntries, bm); 
		//test for fread error 
		if (nCount != m_nColorTableEntries)	{
			fclose(bm);
			Clean();
			return FALSE;
		}
	}

	//read Image bits
	m_lpImage = (LPBYTE) new char[m_dwSizeImage];
	
	nCount = fread((void*)m_lpImage, sizeof(char), m_dwSizeImage, bm); 
	
	//test for fread error 
	if (nCount != (int)m_dwSizeImage)	{
		fclose(bm);
		Clean();
		return FALSE;
	}

	//Close the file
	fclose(bm);

	m_pGLImage = (CGLRGBTRIPLE*) 
				new CGLRGBTRIPLE[m_BMIH.biHeight*m_BMIH.biWidth];
	
	m_Width = m_BMIH.biWidth;
	m_Height = m_BMIH.biHeight;

	switch (m_BMIH.biBitCount)
	{
		
	case 32:
	{
		RGBQUAD* pSrc = (RGBQUAD*) m_lpImage ;
		CGLRGBTRIPLE* pDest = m_pGLImage;
		for(int j = 0 ; j < m_Height ; j++)
		{
			for(int i = 0 ; i <  m_Width ; i++)
			{
				pDest->rgbRed = pSrc->rgbRed ;
                pDest->rgbGreen = pSrc->rgbGreen ;
                pDest->rgbBlue = pSrc->rgbBlue ;
                pDest++ ;
                pSrc++ ;
			}
		}
	}
	break;

	case 24:
	{
		 RGBTRIPLE* pSrc = (RGBTRIPLE*) m_lpImage;
         CGLRGBTRIPLE* pDest = m_pGLImage;
		 //Calculate padding
		 int widthDiff = m_LineWidth - m_Width*sizeof(RGBTRIPLE);
         for(int j = 0 ; j < m_Height ; j++)
         {
            for(int i = 0 ; i <  m_Width ; i++)
            {
               pDest->rgbRed = pSrc->rgbtRed ;
               pDest->rgbGreen = pSrc->rgbtGreen ;
               pDest->rgbBlue = pSrc->rgbtBlue ;
               pDest++ ;
               pSrc++ ;
            }
            pSrc = (RGBTRIPLE*)( (BYTE*)pSrc + widthDiff) ;
         }
      }
      break ;

	case 16:
	{
		WORD* pSrc = (WORD*)m_lpImage;	//WORD = 16 bit uint
		CGLRGBTRIPLE* pDest = m_pGLImage;
		int widthDiff = m_LineWidth - m_Width*sizeof(WORD);
		for(int j = 0 ; j < m_Height ; j++)
		{
            for(int i = 0 ; i <  m_BMIH.biWidth ; i++)
            {
				pDest->rgbRed = (BYTE)((*pSrc & 0x7C00)>>10);
				pDest->rgbGreen = (BYTE)((*pSrc & 0x03E0)>>5);
				pDest->rgbBlue = (BYTE)(*pSrc & 0x001F);
				pDest++ ;
				pSrc++ ;
            }
			pSrc = (WORD*)((BYTE*)pSrc + widthDiff) ;
		}
    }
	break ;
	 
	case 8:
	{
		BYTE* pSrc = m_lpImage;
		CGLRGBTRIPLE* pDest = m_pGLImage;
        int widthDiff =  m_LineWidth - m_Width;
        for(int j = 0 ; j < m_Height ; j++)
        {
           for(int i = 0 ; i < m_Width ; i++)
           {
              pDest->rgbRed = m_lpvColorTable[*pSrc].rgbRed ;
              pDest->rgbGreen = m_lpvColorTable[*pSrc].rgbGreen ;
              pDest->rgbBlue = m_lpvColorTable[*pSrc].rgbBlue ;
              pDest++ ;
              pSrc++ ;
           }
           pSrc += widthDiff ;
        }
      }
      break ;

	case 4:
		BYTE* pSrc = m_lpImage;
		CGLRGBTRIPLE* pDest = m_pGLImage;
		int widthDiff =  m_LineWidth - m_Width/2; 
        for(int j = 0 ; j < m_Height ; j++)
        {
           for(int i = 0; i < m_Width; i++)
		   {
			   int palentry;
			   if (i%2)
				   palentry = (int)(*pSrc & 0xF);
			   else
				   palentry = (int)((*pSrc >> 4) & 0xF);

			   pDest->rgbRed   = m_lpvColorTable[palentry].rgbRed ;
               pDest->rgbGreen = m_lpvColorTable[palentry].rgbGreen ;
               pDest->rgbBlue  = m_lpvColorTable[palentry].rgbBlue ;
				
			   pDest++;
			   if (i%2) pSrc++;
		   }
			pSrc += widthDiff ;
       }

    }
	
	//Make OpenGL compatible (power of 2)
	if (!MakePow2())	{
		Clean();
		return FALSE;
	}
	
	return TRUE;	//We did it, you can uncross your fingers

}


/**************************************************
* LoadBind: Load, bind and clean().               *
***************************************************/

BOOL CGL_Dib::LoadBind(const CHAR* strPathName, const int TexId)
{
	if (Load(strPathName))
	{
		glBindTexture (GL_TEXTURE_2D, TexId); 
		glPixelStorei (GL_UNPACK_ALIGNMENT, 1);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glTexImage2D (GL_TEXTURE_2D, 0, 3, GetWidth(), GetHeight(), 0, GL_RGB, GL_UNSIGNED_BYTE, (GLvoid*)m_pGLImage);
		//As we Uploaded the texture we can clean to free memory
		Clean();
		return TRUE;
	}
	else
		return FALSE;
}


/******************************************************
* ComputeMetrics: Computes several parameters.        *
*                 m_LineWith, m_dwSizeImage and		  *
*                 m_lpvColorTable. All usefull later  *	
*******************************************************/
void CGL_Dib::ComputeMetrics()
{
	//Get the size of a scan line in DWORDS (32 bits)
	DWORD dwBytes = ((DWORD) m_BMIH.biWidth * m_BMIH.biBitCount) / 32;
	
	//if width*bpp not a factor of 32 add 1 to get 4byte padding
	if(((DWORD) m_BMIH.biWidth * m_BMIH.biBitCount) % 32) 
		dwBytes++;
	
	dwBytes *= 4;	//Each DWORD (32 bit uint) has 4 bytes, same as sizeof(DWORD)
	m_LineWidth = (int)dwBytes;
	
	m_dwSizeImage = m_BMIH.biSizeImage;
	
	if(m_dwSizeImage == 0)		//May be set to 0 for BI_RGB bmp's
	{							//Let's do it manually
		m_dwSizeImage = dwBytes * m_BMIH.biHeight; // no compression
	}
}

/******************************************************
* ComputePaletteSize(): Computes m_nColorTableEntries *
*													  *	
*******************************************************/
void CGL_Dib::ComputePaletteSize()
{
	int nBitCount = m_BMIH.biBitCount;

	if (m_BMIH.biClrUsed != 0)	{
		m_nColorTableEntries = m_BMIH.biClrUsed;
		return;
	}

	if (m_BMIH.biBitCount < 16)	{
		m_nColorTableEntries = 1<<m_BMIH.biBitCount;
		return;
	}

	m_nColorTableEntries = 0;
}

/***********************************************************
* MakePow2(): Makes the Image a Power of 2				   *
*			  OpenGL restriction to Upload the image	   *
*														   *	
***********************************************************/
BOOL CGL_Dib::MakePow2(void)
{
	GLint glMaxTexDim;
	double xPow2, yPow2;
	int ixPow2, iyPow2;
	int xSize2, ySize2;

	glGetIntegerv(GL_MAX_TEXTURE_SIZE, &glMaxTexDim);

	const double log2 = log(2.0);

	if (m_Width <= glMaxTexDim)
		xPow2 = log(m_Width) / log2;
	else
		xPow2 = log(glMaxTexDim) / log2;

	if (m_Height <= glMaxTexDim)
		yPow2 = log(m_Height) / log2;
	else
		yPow2 = log(glMaxTexDim) / log2;
	
	//Now check if we are closer to the next or
	//the prev power of two.
	if ( ((1<<(int)(xPow2+1)) - m_Width) <
		 (m_Width - (1<<(int)xPow2))  )
	{
		ixPow2 = (int)xPow2 + 1;
	}
	else 
	{
		ixPow2 = (int)xPow2;
	}
	
	if ( ((1<<(int)(yPow2+1)) - m_Height) <
		 (m_Height - (1<<(int)yPow2)) )
	{
		iyPow2 = (int)yPow2 + 1;
	}
	else 
	{
		iyPow2 = (int)yPow2;
	}
	
	xSize2 = (int)pow(2, ixPow2);
	ySize2 = (int)pow(2, iyPow2);

	//Do we need to scale?
	if (xSize2 == m_Width && ySize2 == m_Height)
		return TRUE;

	CGLRGBTRIPLE* pData = (CGLRGBTRIPLE*) 
				new CGLRGBTRIPLE[xSize2 * ySize2];
   
	if (!pData) return FALSE;

	gluScaleImage(GL_RGB, m_Width, m_Height,
                 GL_UNSIGNED_BYTE, m_pGLImage,
                 xSize2, ySize2, GL_UNSIGNED_BYTE,
                 pData);
	
	delete [] m_pGLImage;
	m_pGLImage = pData; 
	m_Width = xSize2 ;
	m_Height = ySize2 ;

	return TRUE;
}

/***********************************************************
* Clean(): Makes housekeeping and cleans member variables  *
*          plus any dinamically allocated memory.          *
*          Called by the destructor or externally before   *
*		   reusing the class.							   *  
***********************************************************/
void CGL_Dib::Clean()
{
	//Clean the heap
	if (m_lpImage)
		delete [] m_lpImage;
	if (m_pGLImage)
		delete [] m_pGLImage;
	if (m_lpPalette)
		delete [] m_lpPalette;

	//Set everything to NULL or 0.
	m_lpImage = NULL;
	m_pGLImage = NULL;
	m_lpPalette = NULL;
	m_lpvColorTable = NULL;
	m_dwSizeImage = 0;
 	m_nColorTableEntries = 0;
	m_LineWidth = 0;
	m_Height = 0;
	m_Width = 0;
}

/***********************************************************
* CaptureScreen(): Captures the screen portion delimited   *
*			       by the argument rect or the entire 	   *
*				   screen (if lprect == NULL)   		   *	
***********************************************************/
BOOL CGL_Dib::CaptureScreen(LPRECT lpRect)
{
	// How wide, in bytes, would this many bits be, DWORD aligned?
	#define WIDTHBYTES(bits)      ((((bits) + 31)>>5)<<2) 
	
	BITMAPINFOHEADER	bi;				//structures needed
	LPBITMAPINFOHEADER	lpbi;
	BITMAP		bm;						//BITMAP struct
	HDC         hScrDC, hMemDC;			// screen DC and memory DC
    HBITMAP     hBitmap, hOldBitmap;    // handles to deice-dependent bitmaps
	DWORD       dwLen;					// size of memory block     
	int         nX, nY, nX2, nY2;		// coordinates of rectangle to grab
	int         nWidth, nHeight;		// DIB width and height
	int         xScrn, yScrn;			// screen resolution
	

	//Clean if needed
	if (m_lpImage!=NULL || m_pGLImage !=NULL ||
		m_lpPalette!=NULL)
		Clean();

	// check for an empty rectangle 
	if (lpRect!=NULL && IsRectEmpty(lpRect))
		return FALSE;      

	// create a DC for the screen and create 
    // a memory DC compatible to screen DC 
	hScrDC = CreateDC("DISPLAY", NULL, NULL, NULL);
	hMemDC = CreateCompatibleDC(hScrDC);      
	
	// get screen resolution 
	xScrn = GetDeviceCaps(hScrDC, HORZRES);
	yScrn = GetDeviceCaps(hScrDC, VERTRES);
	
	if (lpRect != NULL)
	{
		// get points of rectangle to grab 
		nX = lpRect->left;     
		nY = lpRect->top; 
		nX2 = lpRect->right;
		nY2 = lpRect->bottom;      
	
		//make sure bitmap rectangle is visible 
		if (nX < 0)
			nX = 0;
		if (nY < 0)
			nY = 0;
		if (nX2 > xScrn)
			nX2 = xScrn;
		if (nY2 > yScrn)
			nY2 = yScrn;
		
		nWidth = nX2 - nX;
		nHeight = nY2 - nY;
	}
	else
	{
		nWidth = xScrn;
		nHeight = yScrn;
		nX=0;
		nY=0;
	}
		
	// create a bitmap compatible with the screen DC
	hBitmap = CreateCompatibleBitmap(hScrDC, nWidth, nHeight);
	
	// select new bitmap into memory DC
	hOldBitmap = (HBITMAP)SelectObject(hMemDC, hBitmap);
	
	// bitblt screen DC to memory DC 
    BitBlt(hMemDC, 0, 0, nWidth, nHeight, hScrDC, nX, nY, SRCCOPY);
		
	// select old bitmap back into memory DC and get handle  
    // to bitmap of the screen 
	hBitmap = (HBITMAP) SelectObject(hMemDC, hOldBitmap);
	
	// clean up
	DeleteDC(hScrDC);
	DeleteDC(hMemDC);      
	
	//check valid handle; 
	if (!hBitmap)       
		return FALSE;      
	
	//Fill in BITMAP structure
	if (!GetObject(hBitmap, sizeof(bm), (LPSTR)&bm))
		return FALSE;

	//we only support 16bpp+
	if (bm.bmBitsPixel*bm.bmPlanes < 8)
		return FALSE;
	
	// initialize BITMAPINFOHEADER
	bi.biSize = sizeof(BITMAPINFOHEADER);
	bi.biWidth = bm.bmWidth;
	bi.biHeight = bm.bmHeight;
	bi.biPlanes = 1;
	bi.biBitCount = 24;			//force to 24 bits
	bi.biCompression = BI_RGB;
	bi.biSizeImage = 0;
	bi.biXPelsPerMeter = 0;
	bi.biYPelsPerMeter = 0;
	bi.biClrUsed = 0;
	bi.biClrImportant = 0;

	//calculate size of memory block required to store BITMAPINFO
	dwLen = bi.biSize;//sizeof(BITMAPINFO);//bi.biSize;
	
	// get a DC
	hScrDC = GetDC(NULL);
	
	// alloc memory block to store our bitmap
	lpbi = (LPBITMAPINFOHEADER) malloc(dwLen);

	// if we couldn't get memory block
	if (!lpbi)
	{
		// clean up and return FALSE
 		ReleaseDC(NULL, hScrDC); 
		return FALSE;
	}      

	// use our bitmap info to fill BITMAPINFOHEADER
	*lpbi = bi;
	
	// call GetDIBits with a NULL lpBits param, so it will 
	// calculate the biSizeImage field for us
	GetDIBits(hScrDC, hBitmap, 0, (UINT)bi.biHeight, NULL, 
			(LPBITMAPINFO)lpbi,	DIB_RGB_COLORS);      
	
	// get the info returned by GetDIBits
	bi = *lpbi;

	//Get the size of a scan line in DWORDS (32 bits)
	DWORD dwBytes = ((DWORD) bi.biWidth * bi.biBitCount) / 32;
	
	//if width*bpp not a factor of 32 add 1 to get 4byte padding
	if(((DWORD) bi.biWidth * bi.biBitCount) % 32) 
		dwBytes++;
	
	dwBytes *= 4;	//Each DWORD (32 bit uint) has 4 bytes, same as sizeof(DWORD)
	
	m_LineWidth = (int)dwBytes;
	
	// if the driver did not fill in the biSizeImage field, make one up
	//also take into account padding
	if (bi.biSizeImage == 0)	{
		bi.biSizeImage = m_LineWidth * bm.bmHeight;
	}
	
	// alloc buffer big enough to hold all the bits
	dwLen = bi.biSizeImage;   

	BYTE* lpbits;
	lpbits = (BYTE*) malloc(dwLen);

	if (!lpbits)	{
		// clean up and return FALSE
		free(lpbi);
		free(lpbits);
		ReleaseDC(NULL, hScrDC);		
		return FALSE;
	}      
	
	// call GetDIBits with a NON-NULL lpBits param, 
	// and actualy get the bits this time      
	if ( GetDIBits(hScrDC, hBitmap, 0, (UINT)bi.biHeight,
		lpbits,	(LPBITMAPINFO)lpbi,	DIB_RGB_COLORS) == 0)     
	{ 
        // clean up and return FALSE 
		free(lpbi); 
		free(lpbits);
		ReleaseDC(NULL, hScrDC);
		return FALSE;     
	}      

	bi = *lpbi;
	
	// clean up
	ReleaseDC(NULL, hScrDC);

	//We now have lpbits, the DIB-bits with the screen capture
	//we can poceed as usual
	m_pGLImage = (CGLRGBTRIPLE*) 
				new CGLRGBTRIPLE[bi.biHeight*bi.biWidth];

	RGBTRIPLE* pSrc = (RGBTRIPLE*)(lpbits);
    CGLRGBTRIPLE* pDest = m_pGLImage;
	//Calculate padding
	int widthDiff = m_LineWidth - bi.biWidth*sizeof(RGBTRIPLE);
    
	//The reader loop
	for(int j = 0 ; j < bi.biHeight ; j++)
    {
		for(int i = 0 ; i <  bi.biWidth ; i++)
		{
			pDest->rgbRed = pSrc->rgbtRed ;
			pDest->rgbGreen = pSrc->rgbtGreen ;
			pDest->rgbBlue = pSrc->rgbtBlue ;
			pDest++ ;
			pSrc++ ;
        }
		pSrc = (RGBTRIPLE*)((BYTE*)pSrc + widthDiff) ;
    }
   
	//now we can clean, all we wanted is in m_pGLImage
	free(lpbi);
	free(lpbits);
	DeleteObject(hBitmap);

	//fill class members
	m_Width = bi.biWidth;
	m_Height = bi.biHeight;
	
	//make OpenGL compatible
	if (!MakePow2())	{
		Clean();
		return FALSE;
	}
	
	return TRUE;	//We did it, you can uncross your fingers

}




