/*-------------------------------------------------------------

CGL_Dib.h: Dib reader implementation

  			Copyright Diego T�rtara, 1999.
			
		   -  diego_tartara@ciudad.com.ar  -

Comments: Loads almost any bitmap except for compresed ones.
		  Also captures the screen (to a texture) or just 
		  a portion

Known Issues: none that I know.

Improvements: Implement flags for feedback about errors
			  (ERROR_INVALID_FORMAT etc etc).
----------------------------------------------------------------*/

#ifndef _CUERVO_DIB_MANAGER_FOR_OPENGL_
#define _CUERVO_DIB_MANAGER_FOR_OPENGL_

#include <windows.h>
#include <stdio.h>
#include <gl\gl.h>
#include <GL\glu.h>
#include <math.h>

typedef struct _CGLRGBTRIPLE {
   BYTE rgbRed ;
   BYTE rgbGreen ;
   BYTE rgbBlue ;
} CGLRGBTRIPLE ;

class CGL_Dib
{
public:
	CGL_Dib();		//Construction
	~CGL_Dib();		//Destruction

private:
	LPBYTE m_lpImage;			//starting address of DIB bits
	BITMAPINFOHEADER m_BMIH;	//BITMAPINFOHEADER struct
	DWORD m_dwSizeImage;		//of bytes, just the DIB bits
	int m_LineWidth;			//lenght in bytes of a scan line including padding
	LPRGBQUAD m_lpvColorTable;	//pointer to color table
	int m_nColorTableEntries;	//of pallette
	RGBTRIPLE* m_lpPalette;		//pointer to the palette
	int m_Width;				//width of the image
	int m_Height;				//Height of the image

public:
	CGLRGBTRIPLE* m_pGLImage;	//Pointer to a readable OGL format
	
public:
	BOOL Load(const CHAR* strPathName);
	BOOL LoadBind(const CHAR* strPathName, const int TexId);
	BOOL CaptureScreen (LPRECT lpRect);
	void Clean();
	int GetWidth(){		return m_Width;}; 
	int GetHeight(){	return m_Height;}; 
	
private:
	void ComputePaletteSize();
	void ComputeMetrics();
	BOOL MakePow2();
};

#endif // _CUERVO_DIB_MANAGER_FOR_OPENGL_