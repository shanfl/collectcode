/*************************************************************
* CCam.h: CCam class definition.							 *
*															 *		
*			    ----- Camera by Cuervo  ----				 *	
*	           Copyright Diego A. T�rtara 1999				 *	
*				(diego_tartara@ciudad.com.ar)			     *
*														     *
*************************************************************/

#include "AuxMath.h"
#include <windows.h>

#define TARGET_LOCKED					0x00000001
#define POS_LOCKED					    0x00000002
#define DEBUG_MODE						0x00000004		
#define TARGET_VALID					0x00000008

class CCam
{

private:
	DWORD flags;

	//target/position
	vect target;
	
	//transformation matrix
	mat4 matrix;

public:	
	//Constructor/Destructor
	CCam();
	~CCam() {};

	/******* FUNCTIONS **********/

	//apply transform
	void Apply(void);				//should be called each frame
	//To position sprites (always facing the viewer)
	void UploadInvertRot();	
	
	//movement
	void SetPos(const vect &newpos);//Set absolute position in World coord.
	void LookAt(const vect &point); //Instantly look at there
	void Reset(void);			    //Resets all
	void ResetRot(void);			//Set null rotation, keep position
	void ResetPos(void);			//Move back to origin, keep rotation
	void ResetYaw(void);			//Reset yaw
	void RotateX(const float rad);	//Rotate around X Axis
	void RotateY(const float rad);	//Rotate around Y Axis	
	void RotateZ(const float rad);	//Rotate around Z Axis
	void Rotate(const vect& vdir,	//Rotation around arbitrary vector 
				const float rad);	
	void RotateWX(const float rad);	//Rotate around World X (translated to camera pos)
	void RotateWY(const float rad);	//Rotate around World Y	(translated to camera pos)
	void RotateWZ(const float rad);	//Rotate around World Z	(translated to camera pos)

	void Translate(const vect &v);  //Translation

	void Forward(const float dist);	//Walk forward, parallel to XZ plane
	void Strafe(const float dist);	//Walk sideways parallel to XZ plane
	void Up(const float dist);		//Walk Up parallel to Y axis

	void LockTarget(BOOL lock);		//locks/unlocks lookat point
	void LockPos(BOOL lock);		//locks/unlocks position
	
	vect GetTarget();				//Returns target or a point in the 
									//viewing axis (if there is no valid target)
	vect GetPos(void);				//Get position in World coord.								
	float GetYaw(void);				//Returns deviation from XZ plane
	float GetPitch(void);			//Returns deviation from YZ plane
	float GetRoll(void);			//Returns deviation from XY plane

	//debugging aid activation
	void SetDebugMode(BOOL debug)	{ if (debug) flags |= DEBUG_MODE;
									  else flags &= (~DEBUG_MODE);	};
	//info
	BOOL IsTargetLocked()	{ return (flags & TARGET_LOCKED);};
	BOOL IsPosLocked()		{ return (flags & POS_LOCKED);};
	BOOL IsTargetValid()	{ return (flags & TARGET_VALID);};
	BOOL IsDebugOn()		{ return (flags & DEBUG_MODE);};

	
private:
	void DrawDebug(void);
	void DrawAim(void);
	void MultMatrix(const mat4 &a);
};



